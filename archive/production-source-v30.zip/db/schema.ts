import { sqliteTable, text, integer, index, uniqueIndex,primaryKey } from 'drizzle-orm/sqlite-core';
export const documents=sqliteTable('documents',{id:text('id').primaryKey(),draft:text('draft').notNull(),published:text('published'),revision:integer('revision').notNull().default(1),updatedAt:text('updated_at').notNull()});
export const chapterComments=sqliteTable('chapter_comments',{
 id:integer('id').primaryKey({autoIncrement:true}),chapterId:text('chapter_id').notNull(),ownerKey:text('owner_key').notNull(),
 name:text('name').notNull(),kind:text('kind').notNull().default('visitor'),body:text('body').notNull(),url:text('url').notNull().default(''),
 revision:integer('revision').notNull().default(1),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull(),editedByAuthor:integer('edited_by_author').notNull().default(0),
},table=>[index('idx_comments_chapter_id').on(table.chapterId,table.id),index('idx_comments_owner_created').on(table.ownerKey,table.createdAt)]);
export const glossaryTerms=sqliteTable('glossary_terms',{
 id:text('id').primaryKey(),termKey:text('term_key').notNull(),draft:text('draft').notNull(),published:text('published'),
 revision:integer('revision').notNull().default(1),updatedAt:text('updated_at').notNull(),
},table=>[uniqueIndex('idx_glossary_term_key').on(table.termKey)]);
export const readerDevices=sqliteTable('reader_devices',{
 deviceKey:text('device_key').primaryKey(),lastRead:text('last_read'),bookmark:text('bookmark'),lastReadAt:integer('last_read_at').notNull().default(0),
});
export const chapterEngagement=sqliteTable('chapter_engagement',{
 chapterId:text('chapter_id').notNull(),deviceKey:text('device_key').notNull(),liked:integer('liked').notNull().default(0),viewedAt:text('viewed_at').notNull(),
},table=>[primaryKey({columns:[table.chapterId,table.deviceKey]})]);
