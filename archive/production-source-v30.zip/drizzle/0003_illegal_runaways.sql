CREATE TABLE `chapter_engagement` (
	`chapter_id` text NOT NULL,
	`device_key` text NOT NULL,
	`liked` integer DEFAULT 0 NOT NULL,
	`viewed_at` text NOT NULL,
	PRIMARY KEY(`chapter_id`, `device_key`)
);
--> statement-breakpoint
CREATE TABLE `reader_devices` (
	`device_key` text PRIMARY KEY NOT NULL,
	`last_read` text,
	`bookmark` text,
	`last_read_at` integer DEFAULT 0 NOT NULL
);
