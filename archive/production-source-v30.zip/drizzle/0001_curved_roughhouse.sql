CREATE TABLE `chapter_comments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`chapter_id` text NOT NULL,
	`owner_key` text NOT NULL,
	`name` text NOT NULL,
	`kind` text DEFAULT 'visitor' NOT NULL,
	`body` text NOT NULL,
	`url` text DEFAULT '' NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`edited_by_author` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_comments_chapter_id` ON `chapter_comments` (`chapter_id`,`id`);--> statement-breakpoint
CREATE INDEX `idx_comments_owner_created` ON `chapter_comments` (`owner_key`,`created_at`);
--> statement-breakpoint
PRAGMA optimize;
