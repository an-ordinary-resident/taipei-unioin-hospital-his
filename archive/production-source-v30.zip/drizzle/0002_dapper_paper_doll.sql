CREATE TABLE `glossary_terms` (
	`id` text PRIMARY KEY NOT NULL,
	`term_key` text NOT NULL,
	`draft` text NOT NULL,
	`published` text,
	`revision` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_glossary_term_key` ON `glossary_terms` (`term_key`);