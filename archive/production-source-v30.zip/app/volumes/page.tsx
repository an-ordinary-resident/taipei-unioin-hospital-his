import Shell from '@/components/his-shell';
import VolumeDirectory from '@/components/volume-directory';
import { documents } from '@/lib/content';
export const dynamic = 'force-dynamic';

export default async function Volumes() {
  const all = await documents();
  const volumes = all.filter(d => d.kind === 'volume');
  // The directory needs chapter labels only; story text stays on the reader route.
  const chapters = all.filter(d => d.kind === 'chapter').map(d => ({ ...d, body: '', image: '', notes: [], cast: [], summary: '', readingMinutes: '', details: '', background: '', profileSections: [] }));
  return <Shell active="volumes" title="病程紀錄">
    <div className="page-heading"><div><span className="eyebrow">CLINICAL RECORDS</span><h1>病程紀錄</h1><p>點選卷名，展開章節、附錄與番外篇。</p></div><span className="outlined-label">{volumes.length} 卷已建檔</span></div>
    <VolumeDirectory volumes={volumes} chapters={chapters}/>
    {!volumes.length && <div className="panel empty-state">尚無已刊載卷數，請稍後再來。</div>}
    <p className="index-footer">連載持續更新中。下一份病歷，等待作者簽核。</p>
  </Shell>;
}
