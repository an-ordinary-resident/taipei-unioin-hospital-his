import Shell from '@/components/his-shell';
import DashboardView from '@/components/dashboard-view';
import { documents } from '@/lib/content';
import { presentation } from '@/lib/presentation-store';
import { dashboardRecords } from '@/lib/presentation-config';
export const dynamic='force-dynamic';
export default async function Dashboard(){const [all,settings]=await Promise.all([documents(),presentation('dashboard')]);const people=all.filter(d=>d.kind==='character');const recommendedId=people.find(p=>p.id===settings.value.featuredCharacterId)?.id||people[Math.floor(Math.random()*people.length)]?.id||'';return <Shell active="dashboard" title="值班主控台"><DashboardView all={dashboardRecords(all)} config={settings.value} initialRecommendedId={recommendedId}/></Shell>}
