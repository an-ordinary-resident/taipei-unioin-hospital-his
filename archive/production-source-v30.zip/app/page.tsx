import Login from './login';
import { announcement } from '@/lib/site-settings';
import { documents } from '@/lib/content';
export const dynamic='force-dynamic';
export default async function Home() { const all=await documents();const volume=all.find(d=>d.kind==='volume');return <Login announcement={await announcement()} volumeTitle={volume?.title||'下一份病歷，等待作者簽核'} volumeSubtitle={volume?.subtitle||'ADMISSION NOTE'} volumeNumber={volume?.order||1} chapters={all.filter(d=>d.kind==='chapter'&&d.volume===volume?.id).length} people={all.filter(d=>d.kind==='character').length}/>; }
