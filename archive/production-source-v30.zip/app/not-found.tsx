export default function NotFound(){return <main className="error-page panel"><h1>查無這份病歷</h1><p>內容可能尚未刊載，或已由作者下架。</p><a href="/dashboard" className="primary-btn">回到閱讀主控台</a></main>}
