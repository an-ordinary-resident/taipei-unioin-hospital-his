import Shell from '@/components/his-shell';
import CampusGuide from '@/components/campus-guide';
import {parseCampusLocation} from '@/lib/campus';
export default async function CampusPage({searchParams}:{searchParams:Promise<Record<string,string|string[]|undefined>>}){
 const values=await searchParams;const query=new URLSearchParams();
 for(const key of ['building','floor','ward','space']){const v=values?.[key];if(typeof v==='string')query.set(key,v);}
 return <Shell active="campus" title="院區導覽"><CampusGuide initial={parseCampusLocation(query.toString())}/></Shell>;
}
