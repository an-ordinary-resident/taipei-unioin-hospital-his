import Shell from '@/components/his-shell';
import Prose from '@/components/prose';
import { presentation } from '@/lib/presentation-store';
export const dynamic='force-dynamic';
export default async function About(){const {value}=await presentation('about');return <Shell active="about" title="系統聲明"><div className="page-heading"><div><span className="eyebrow">SYSTEM NOTICE</span><h1>{value.title}</h1><p>{value.subtitle}</p></div></div><article className="panel about-prose"><Prose text={value.body} notes={value.notes}/></article></Shell>}
