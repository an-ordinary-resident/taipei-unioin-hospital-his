import { cookies } from 'next/headers';
import { getChatGPTUser } from '@/app/chatgpt-auth';
import { database,documents,isAuthor } from '@/lib/content';
import { cleanComment,mayEditComment,publicComment,type CommentRecord } from '@/lib/comment-policy';

const COOKIE='his-comment-owner';
async function hash(value:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(b=>b.toString(16).padStart(2,'0')).join('');}
async function actor(){
 const [jar,user,author]=await Promise.all([cookies(),getChatGPTUser(),isAuthor()]);
 const old=jar.get(COOKIE)?.value,valid=old&&/^[a-f0-9]{64}$/.test(old);
 const token=valid?old:Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b=>b.toString(16).padStart(2,'0')).join('');
 const guestKey='guest:'+await hash(token),keys=user?['user:'+await hash(user.userId),guestKey]:[guestKey];
 let name='VISITOR-001';try{name=decodeURIComponent(jar.get('his-visitor')?.value||name).slice(0,80);}catch{}
 return {keys,author,token,fresh:!valid,name:author?'一個平凡的住院醫師':name};
}
function reply(req:Request,who:Awaited<ReturnType<typeof actor>>,data:unknown,status=200){
 const headers=new Headers({'Cache-Control':'no-store'});
 if(who.fresh)headers.set('Set-Cookie',COOKIE+'='+who.token+'; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000'+(new URL(req.url).protocol==='https:'?'; Secure':''));
 return Response.json(data,{status,headers});
}
async function chapterAccess(id:unknown){
 if(typeof id!=='string'||!/^[-a-z0-9]{1,80}$/.test(id))return false;
 const chapter=(await documents()).find(d=>d.kind==='chapter'&&d.id===id);return !!chapter&&!chapter.locked;
}
export async function GET(req:Request){try{
 const params=new URL(req.url).searchParams,chapterId=params.get('chapterId');
 if(!await chapterAccess(chapterId))return Response.json({error:'此章節目前無法閱覽。'},{status:403});
 const who=await actor(),kind=params.get('kind')||'all',before=Number(params.get('before')||Number.MAX_SAFE_INTEGER);
 if(!['all','visitor','author','reference'].includes(kind)||!Number.isSafeInteger(before)||before<1)return Response.json({error:'查詢格式錯誤。'},{status:400});
 const {results}=await database().prepare('SELECT * FROM chapter_comments WHERE chapter_id=? AND id<? AND (?=\'all\' OR kind=?) ORDER BY id DESC LIMIT 31').bind(chapterId,before,kind,kind).all<CommentRecord>();
 const rows=results.slice(0,30);
 return reply(req,who,{comments:rows.map(row=>publicComment(row,who.keys,who.author)),nextCursor:results.length>30?rows[rows.length-1].id:null,isAuthor:who.author,name:who.name});
 }catch(error){console.error('Comment loading failed',error);return Response.json({error:'留言暫時無法載入，請稍後再試。'},{status:503});}}

export async function POST(req:Request){try{
 if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'請由本站病歷評論操作。'},{status:403});
 if(Number(req.headers.get('content-length'))>32000)return Response.json({error:'留言內容過長。'},{status:413});
 const raw=await req.text();if(raw.length>32000)return Response.json({error:'留言內容過長。'},{status:413});
 let payload;try{payload=JSON.parse(raw);}catch{return Response.json({error:'留言格式錯誤。'},{status:400});}
 if(!payload||!['create','update','delete'].includes(payload.action)||!await chapterAccess(payload.chapterId))return Response.json({error:'此章節或操作無法使用。'},{status:403});
 const who=await actor(),db=database();
 let existing:CommentRecord|null=null;
 if(payload.action!=='create'){
  if(!Number.isSafeInteger(payload.id)||payload.id<1)return Response.json({error:'留言格式錯誤。'},{status:400});
  existing=await db.prepare('SELECT * FROM chapter_comments WHERE id=? AND chapter_id=?').bind(payload.id,payload.chapterId).first<CommentRecord>();
  if(!existing)return reply(req,who,{error:'這則留言已不存在。'},404);
  if(!mayEditComment(existing,who.keys,who.author))return reply(req,who,{error:'只能修改自己的留言。'},403);
  if(existing.revision!==payload.revision)return reply(req,who,{error:'留言已更新，請重新載入後再編輯。'},409);
 }
 if(payload.action==='delete'){
  const result=await db.prepare('DELETE FROM chapter_comments WHERE id=? AND revision=?').bind(existing!.id,payload.revision).run();
  return reply(req,who,result.meta.changes?{ok:true}:{error:'留言已更新，請重新載入。'},result.meta.changes?200:409);
 }
 const draft=cleanComment(payload,who.author);
 if(!draft)return reply(req,who,{error:'請填寫名稱與留言（最多 5,000 字），參考資料需附完整網址。'},400);
 if(existing&&existing.kind==='visitor'&&draft.kind!=='visitor')return reply(req,who,{error:'訪客留言的分類不可變更。'},400);
 const now=new Date().toISOString();
 if(payload.action==='create'){
  const since=new Date(Date.now()-60000).toISOString();
  const result=await db.prepare('INSERT INTO chapter_comments (chapter_id,owner_key,name,kind,body,url,revision,created_at,updated_at,edited_by_author) SELECT ?,?,?,?,?,?,1,?,?,0 WHERE ?=1 OR (SELECT COUNT(*) FROM chapter_comments WHERE owner_key=? AND created_at>?)<5').bind(payload.chapterId,who.keys[0],who.author?'一個平凡的住院醫師':draft.name,draft.kind,draft.body,draft.url,now,now,who.author?1:0,who.keys[0],since).run();
  return reply(req,who,result.meta.changes?{ok:true}:{error:'留言太頻繁，請稍候一分鐘再送出。'},result.meta.changes?200:429);
 }
 const result=await db.prepare('UPDATE chapter_comments SET name=?,kind=?,body=?,url=?,revision=revision+1,updated_at=?,edited_by_author=? WHERE id=? AND revision=?').bind(existing!.name,draft.kind,draft.body,draft.url,now,who.author?1:0,existing!.id,payload.revision).run();
 return reply(req,who,result.meta.changes?{ok:true}:{error:'留言已更新，請重新載入。'},result.meta.changes?200:409);
 }catch(error){console.error('Comment mutation failed',error);return Response.json({error:'留言未能儲存，內容仍保留，請稍後再試。'},{status:503});}}
