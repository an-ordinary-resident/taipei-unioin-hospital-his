import { database,isAuthor,mutationGuard } from '@/lib/content';
import { cleanTerm,cleanTags,normalizeTerm } from '@/lib/glossary';
const headers={'Cache-Control':'no-store'};
type Snapshot={total:number;revisionSum:number;pending:number};
async function snapshot(){return (await database().prepare('SELECT COUNT(*) AS total,COALESCE(SUM(revision),0) AS revisionSum,COALESCE(SUM(CASE WHEN published IS NULL OR published<>draft THEN 1 ELSE 0 END),0) AS pending FROM glossary_terms').first<Snapshot>())!;}
export async function GET(){try{
 if(!await isAuthor())return Response.json({error:'只有作者可以管理辭典。'},{status:403,headers});
 return Response.json(await snapshot(),{headers});
 }catch{return Response.json({error:'無法讀取待刊載詞條，請重試。'},{status:503,headers});}}
export async function POST(req:Request){try{
 const denied=await mutationGuard(req);if(denied)return denied;
 if(Number(req.headers.get('content-length'))>1600000)return Response.json({error:'一次最多儲存 200 則註釋。'},{status:413});
 const raw=await req.text();if(raw.length>1500000)return Response.json({error:'註釋內容過長。'},{status:413});
 let input;try{input=JSON.parse(raw);}catch{return Response.json({error:'格式錯誤。'},{status:400});}
 const db=database();
 if(input?.action==='publish-all'){
  const s=input.snapshot as Snapshot;
  if(!s||![s.total,s.revisionSum,s.pending].every(n=>Number.isSafeInteger(n)&&n>=0))return Response.json({error:'請重新確認待刊載詞條。'},{status:400});
  const current=await snapshot();
  if(current.total!==s.total||current.revisionSum!==s.revisionSum||current.pending!==s.pending)return Response.json({error:'詞條已更新，請重新開啟全部發布並確認數量。'},{status:409});
  if(!s.pending)return Response.json({published:0},{headers});
  const result=await db.prepare('UPDATE glossary_terms SET published=draft,revision=revision+1,updated_at=? WHERE (published IS NULL OR published<>draft) AND (SELECT COUNT(*) FROM glossary_terms)=? AND (SELECT COALESCE(SUM(revision),0) FROM glossary_terms)=?').bind(new Date().toISOString(),s.total,s.revisionSum).run();
  if(!result.meta.changes)return Response.json({error:'詞條已更新，請重新確認後再發布。'},{status:409});
  return Response.json({published:result.meta.changes},{headers});
 }
 if(input?.action!=='import-drafts'||!Array.isArray(input.notes)||!input.notes.length||input.notes.length>200)return Response.json({error:'請選擇 1–200 則用詞註釋。'},{status:400});
 const terms=input.notes.map((note:unknown)=>cleanTerm({...((note&&typeof note==='object')?note:{}),id:crypto.randomUUID(),revision:0}));
 if(terms.some((t:ReturnType<typeof cleanTerm>)=>!t))return Response.json({error:'請確認全部註釋都有名詞、解說與有效標籤。'},{status:400});
 type Term=NonNullable<ReturnType<typeof cleanTerm>>;
 const unique=new Map<string,Term>(),conflicts=new Set<string>();
 const same=(a:{text:string;tags?:unknown},b:{text:string;tags?:unknown})=>a.text.trim()===b.text.trim()&&JSON.stringify((cleanTags(a.tags)||[]).sort())===JSON.stringify((cleanTags(b.tags)||[]).sort());
 for(const term of terms as Term[]){const key=normalizeTerm(term.term),previous=unique.get(key);if(previous&&!same(previous,term))conflicts.add(term.term);else unique.set(key,term);}
 const conflictedKeys=new Set([...conflicts].map(normalizeTerm));
 const {results}=await db.prepare('SELECT term_key,draft FROM glossary_terms WHERE term_key IN (SELECT value FROM json_each(?))').bind(JSON.stringify([...unique.keys()])).all<{term_key:string;draft:string}>();
 const existing=new Map(results.map(r=>[r.term_key,JSON.parse(r.draft)]));
 let skipped=0,added=0;const insert:Term[]=[];
 for(const [key,term] of unique){if(conflictedKeys.has(key))continue;const old=existing.get(key);if(old){if(same(old,term))skipped++;else conflicts.add(term.term);}else insert.push(term);}
 for(let start=0;start<insert.length;start+=50){
  const results=await db.batch(insert.slice(start,start+50).map(term=>db.prepare('INSERT INTO glossary_terms(id,term_key,draft,published,revision,updated_at) VALUES(?,?,?,NULL,1,?) ON CONFLICT(term_key) DO NOTHING').bind(term.id,normalizeTerm(term.term),JSON.stringify({term:term.term,text:term.text,tags:term.tags}),new Date().toISOString())));
  for(let i=0;i<results.length;i++){if(results[i].meta.changes)added++;else conflicts.add(insert[start+i].term);}
 }
 return Response.json({added,existing:skipped,conflicts:[...conflicts]},{headers});
 }catch(error){console.error('Glossary batch failed',error);return Response.json({error:'批次操作未完成，原註釋仍保留；請重試。'},{status:503,headers});}}
