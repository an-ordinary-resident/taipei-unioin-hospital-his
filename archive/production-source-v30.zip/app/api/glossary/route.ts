import { database,isAuthor,mutationGuard } from '@/lib/content';
import { cleanTerm,cleanTags,normalizeTerm,type GlossaryTerm } from '@/lib/glossary';
type Row={id:string;draft:string;published:string|null;revision:number};
const noStore={'Cache-Control':'no-store'};
function termFromRow(row:Row,author:boolean):GlossaryTerm{
 const value=JSON.parse((author?row.draft:row.published)!);
 return {...value,tags:cleanTags(value.tags)||[],id:row.id,revision:author?row.revision:0,isPublished:!!row.published,hasDraft:author&&row.draft!==row.published};
}
export async function GET(req:Request){
 try{
  const url=new URL(req.url),author=url.searchParams.get('scope')==='author';
  if(author&&!await isAuthor())return Response.json({error:'只有作者可以查看辭典草稿。'},{status:403,headers:noStore});
  const id=url.searchParams.get('id');
  if(id){
   if(!/^[-a-z0-9]{1,80}$/.test(id))return Response.json({error:'詞條代碼格式錯誤。'},{status:400,headers:noStore});
   const row=await database().prepare('SELECT id,draft,published,revision FROM glossary_terms WHERE id=?').bind(id).first<Row>();
   if(!row||(!author&&!row.published))return Response.json({error:'找不到這個詞條，可解除連結保留本章解說。'},{status:404,headers:noStore});
   return Response.json({term:termFromRow(row,author)},{headers:noStore});
  }
  const q=(url.searchParams.get('q')||'').trim().slice(0,200),offset=Number(url.searchParams.get('offset')||0);
  if(!Number.isSafeInteger(offset)||offset<0)return Response.json({error:'頁碼格式錯誤。'},{status:400});
  const column=author?'draft':'published',like='%'+q.replace(/[\\%_]/g,'\\$&')+'%';
  const tag=(url.searchParams.get('tag')||'').normalize('NFKC').trim().slice(0,40);
  const tagSource=`json_each(COALESCE(json_extract(${column},'$.tags'),'[]'))`;
  const where=`${column} IS NOT NULL AND (json_extract(${column},'$.term') LIKE ? ESCAPE '\\' OR json_extract(${column},'$.text') LIKE ? ESCAPE '\\' OR EXISTS(SELECT 1 FROM ${tagSource} WHERE value LIKE ? ESCAPE '\\')) AND (?='' OR EXISTS(SELECT 1 FROM ${tagSource} WHERE value=?))`;
  const db=database();
  const [{results},count,facets]=await Promise.all([
   db.prepare(`SELECT id,draft,published,revision FROM glossary_terms WHERE ${where} ORDER BY json_extract(${column},'$.term') COLLATE NOCASE,id LIMIT 31 OFFSET ?`).bind(like,like,like,tag,tag,offset).all<Row>(),
   db.prepare(`SELECT count(*) AS total FROM glossary_terms WHERE ${where}`).bind(like,like,like,tag,tag).first<{total:number}>(),
   db.prepare(`SELECT DISTINCT value AS tag FROM glossary_terms,${tagSource} WHERE ${column} IS NOT NULL AND type='text' ORDER BY value`).all<{tag:string}>(),
  ]);
  return Response.json({terms:results.slice(0,30).map(r=>termFromRow(r,author)),nextOffset:results.length>30?offset+30:null,total:count?.total||0,tags:facets.results.map(r=>r.tag)},{headers:noStore});
 }catch(error){console.error('Glossary read failed',error);return Response.json({error:'辭典暫時無法載入，請稍後重試。'},{status:503,headers:noStore});}
}
export async function POST(req:Request){
 try{
  const denied=await mutationGuard(req);if(denied)return denied;
  const raw=await req.text();if(raw.length>15000)return Response.json({error:'詞條內容過長。'},{status:413});
  let input;try{input=JSON.parse(raw);}catch{return Response.json({error:'詞條格式錯誤。'},{status:400});}
  const term=cleanTerm(input.term),action=input.action;
  if(!term||!['draft','publish','unpublish'].includes(action))return Response.json({error:'請填寫名詞與解說，並確認內容長度。'},{status:400});
  const db=database(),key=normalizeTerm(term.term);
  const duplicate=await db.prepare('SELECT id FROM glossary_terms WHERE term_key=? AND id<>?').bind(key,term.id).first();
  if(duplicate)return Response.json({error:'辭典已有同名詞條，請搜尋後引用或編輯原詞條。'},{status:409});
  const current=await db.prepare('SELECT id,draft,published,revision FROM glossary_terms WHERE id=?').bind(term.id).first<Row>();
  if((current?.revision||0)!==term.revision)return Response.json({error:'詞條已在其他視窗更新，請重新載入後再編輯。'},{status:409});
  const draft=JSON.stringify({term:term.term,text:term.text,tags:term.tags});
  const published=action==='publish'?draft:action==='unpublish'?null:current?.published||null;
  const result=await db.prepare('INSERT INTO glossary_terms(id,term_key,draft,published,revision,updated_at) VALUES(?,?,?,?,1,?) ON CONFLICT(id) DO UPDATE SET term_key=excluded.term_key,draft=excluded.draft,published=excluded.published,revision=glossary_terms.revision+1,updated_at=excluded.updated_at WHERE glossary_terms.revision=?').bind(term.id,key,draft,published,new Date().toISOString(),term.revision).run();
  if(!result.meta.changes)return Response.json({error:'詞條已更新，請重新載入。'},{status:409});
  return Response.json({term:{...term,revision:term.revision+1,isPublished:!!published,hasDraft:draft!==published}},{headers:noStore});
 }catch(error){
  if(String(error).includes('UNIQUE constraint'))return Response.json({error:'辭典已有同名詞條，請搜尋後引用。'},{status:409});
  console.error('Glossary save failed',error);return Response.json({error:'詞條未能儲存，輸入內容已保留，請稍後重試。'},{status:503});
 }
}
