import { env } from 'cloudflare:workers';
import { mutationGuard } from '@/lib/content';
export async function POST(req:Request){const denied=await mutationGuard(req);if(denied)return denied;
 const limit=8*1024*1024;if(Number(req.headers.get('content-length'))>limit+65536)return Response.json({error:'圖片上限為 8 MB。'},{status:413});
 let data:FormData;try{data=await req.formData();}catch{return Response.json({error:'無法讀取圖片。'},{status:400});}
 const file=data.get('file');if(!(file instanceof File)||file.size===0||file.size>limit)return Response.json({error:'請選擇 8 MB 以下的 PNG、JPEG 或 WebP 圖片。'},{status:400});
 const bytes=new Uint8Array(await file.arrayBuffer());const signature=String.fromCharCode(...bytes.slice(0,12));
 const mime=bytes[0]===137&&signature.slice(1,4)==='PNG'?'image/png':bytes[0]===255&&bytes[1]===216&&bytes[2]===255?'image/jpeg':signature.startsWith('RIFF')&&signature.slice(8,12)==='WEBP'?'image/webp':null;
 if(!mime)return Response.json({error:'僅支援 PNG、JPEG、WebP 圖片。'},{status:415});
 const id=crypto.randomUUID();await env.FILES.put(id,bytes,{httpMetadata:{contentType:mime}});return Response.json({url:'/api/media/'+id});
}
