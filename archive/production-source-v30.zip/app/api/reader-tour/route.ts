import { documents } from '@/lib/content';
import { firstReadableChapter } from '@/lib/reading-history';
export async function GET(){
 const all=await documents(),chapter=firstReadableChapter(all);
 const character=all.find(d=>d.kind==='character'&&d.id==='person-1')||all.find(d=>d.kind==='character'&&d.title==='陳屏帆');
 return Response.json({readPath:chapter?'/read/'+chapter.id:null,characterPath:character?'/characters/'+character.id:null},{headers:{'Cache-Control':'no-store'}});
}
