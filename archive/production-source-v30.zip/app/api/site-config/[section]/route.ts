import { database,isAuthor,mutationGuard } from '@/lib/content';
import { presentation,cleanPresentation,type PresentationSection } from '@/lib/presentation-store';
import { referenceIds } from '@/lib/rich-text';
import type { AboutConfig } from '@/lib/presentation-config';
type Params={params:Promise<{section:string}>};
export async function GET(req:Request,{params}:Params){const {section}=await params;if(!['dashboard','about','tour'].includes(section))return Response.json({error:'找不到設定'},{status:404});const author=new URL(req.url).searchParams.get('scope')==='author';if(author&&!await isAuthor())return Response.json({error:'無作者權限'},{status:403});return Response.json(await presentation(section as PresentationSection,author),{headers:{'Cache-Control':'no-store'}})}
export async function POST(req:Request,{params}:Params){
 const denied=await mutationGuard(req);if(denied)return denied;const {section}=await params;if(!['dashboard','about','tour'].includes(section))return Response.json({error:'找不到設定'},{status:404});
 let p;try{const text=await req.text();if(text.length>800000)return Response.json({error:'內容過長'},{status:413});p=JSON.parse(text)}catch{return Response.json({error:'格式錯誤'},{status:400})}
 const name=section as PresentationSection,value=cleanPresentation(name,p.value);if(!value||!Number.isInteger(p.revision)||p.revision<0||!['draft','publish'].includes(p.action))return Response.json({error:name==='tour'?'請填妥每一段教學標題與內文，並確認字數未超過上限。':'請檢查文字長度、名言、小道消息及排版設定。名言與消息內文不可留白。'},{status:400});
 if(name==='about'&&p.action==='publish'){const about=value as AboutConfig;if(referenceIds(about.body).some(id=>!about.notes.some(n=>n.id===id)))return Response.json({error:'請補齊系統聲明中的註解。'},{status:400})}
 const current=await presentation(name,true);if(current.revision!==p.revision)return Response.json({error:'設定已在其他視窗更新，請重新載入後編輯。'},{status:409});
 const draft=JSON.stringify(value),before=JSON.stringify((await presentation(name)).value);
 const result=await database().prepare('INSERT INTO documents (id,draft,published,revision,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET draft=excluded.draft,published=excluded.published,revision=documents.revision+1,updated_at=excluded.updated_at WHERE documents.revision=?').bind('site-'+name,draft,p.action==='publish'?draft:before,1,new Date().toISOString(),p.revision).run();
 if(!result.meta.changes)return Response.json({error:'設定已更新，請重新載入。'},{status:409});return Response.json(await presentation(name,true));
}
