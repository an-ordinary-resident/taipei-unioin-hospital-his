import { env } from 'cloudflare:workers';
import { documents,isAuthor } from '@/lib/content';
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){const {id}=await params;if(!/^[a-f0-9-]{36}$/.test(id))return new Response(null,{status:404});const path='/api/media/'+id;
 if(!await isAuthor()&&!(await documents()).some(d=>d.image===path||[d.body,d.details||'',d.background||''].some(text=>text.includes('[image:'+path+']'))))return new Response(null,{status:404});
 const file=await env.FILES.get(id);if(!file)return new Response(null,{status:404});return new Response(file.body,{headers:{'Content-Type':file.httpMetadata?.contentType||'application/octet-stream','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",'Cache-Control':'private, no-store'}});}
