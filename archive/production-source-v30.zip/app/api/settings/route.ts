import { announcement,SETTINGS_ID } from '@/lib/site-settings';
import { database,isAuthor,mutationGuard } from '@/lib/content';
export async function GET(req:Request){const author=new URL(req.url).searchParams.get('scope')==='author';if(author&&!await isAuthor())return Response.json({error:'無作者權限'},{status:403});return Response.json(await announcement(author),{headers:{'Cache-Control':'no-store'}})}
export async function POST(req:Request){
 const denied=await mutationGuard(req);if(denied)return denied;
 let p;try{const raw=await req.text();if(raw.length>12000)return Response.json({error:'公告內容過長'},{status:400});p=JSON.parse(raw)}catch{return Response.json({error:'格式錯誤'},{status:400})}
 if(typeof p.text!=='string'||p.text.length>1000||typeof p.enabled!=='boolean'||!Number.isInteger(p.revision)||p.revision<0||!['draft','publish'].includes(p.action)||(p.enabled&&!p.text.trim()))return Response.json({error:'請填寫公告文字（上限 1,000 字元）'},{status:400});
 const current=await announcement(true);if(current.revision!==p.revision)return Response.json({error:'公告已在其他視窗更新，請重新載入'},{status:409});
 const value=JSON.stringify({text:p.text.trim(),enabled:p.enabled});
 const old=await database().prepare('SELECT published FROM documents WHERE id=?').bind(SETTINGS_ID).first<{published:string|null}>();
 const published=p.action==='publish'?value:old?old.published:JSON.stringify({text:(await announcement()).text,enabled:(await announcement()).enabled});
 const result=await database().prepare('INSERT INTO documents (id,draft,published,revision,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET draft=excluded.draft,published=excluded.published,revision=documents.revision+1,updated_at=excluded.updated_at WHERE documents.revision=?').bind(SETTINGS_ID,value,published,1,new Date().toISOString(),p.revision).run();
 if(!result.meta.changes)return Response.json({error:'公告已更新，請重新載入'},{status:409});
 return Response.json(await announcement(true));
}
