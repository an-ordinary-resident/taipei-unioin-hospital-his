import { cookies } from 'next/headers';
import { database,documents } from '@/lib/content';
import { cleanReadingPoint,type ReadingPoint } from '@/lib/reading-history';
const COOKIE='his-reader-device';
const noStore={'Cache-Control':'no-store'};
async function identity(create=false){
 const old=(await cookies()).get(COOKIE)?.value,valid=!!old&&/^[a-f0-9]{64}$/.test(old);
 if(!valid&&!create)return null;
 const token=valid?old!:Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b=>b.toString(16).padStart(2,'0')).join('');
 const key=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token)))).map(b=>b.toString(16).padStart(2,'0')).join('');
 return {key,token,fresh:!valid};
}
function reply(req:Request,who:NonNullable<Awaited<ReturnType<typeof identity>>>,data:unknown){
 const headers=new Headers(noStore);
 headers.set('Set-Cookie',COOKIE+'='+who.token+'; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000'+(new URL(req.url).protocol==='https:'?'; Secure':''));
 return Response.json(data,{headers});
}
async function stats(chapterId:string,key:string){
 const value=await database().prepare('SELECT COUNT(*) AS views,COALESCE(SUM(liked),0) AS likes,COALESCE(MAX(CASE WHEN device_key=? THEN liked ELSE 0 END),0) AS liked FROM chapter_engagement WHERE chapter_id=?').bind(key,chapterId).first<{views:number;likes:number;liked:number}>();
 return {views:value?.views||0,likes:value?.likes||0,liked:!!value?.liked};
}
export async function GET(req:Request){try{
 const who=(await identity(true))!,all=await documents();
 const row=await database().prepare('SELECT last_read,bookmark FROM reader_devices WHERE device_key=?').bind(who.key).first<{last_read:string|null;bookmark:string|null}>();
 function visible(raw?:string|null){if(!raw)return null;try{const p=JSON.parse(raw) as ReadingPoint;return all.some(d=>d.kind==='chapter'&&d.id===p.chapterId&&!d.locked)?p:null;}catch{return null;}}
 return reply(req,who,{lastRead:visible(row?.last_read),bookmark:visible(row?.bookmark)});
 }catch(error){console.error('Reader history failed',error);return Response.json({error:'閱讀紀錄暫時無法載入，請稍後重試。'},{status:503,headers:noStore});}}
export async function POST(req:Request){try{
 if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'請由本站操作閱讀紀錄。'},{status:403,headers:noStore});
 const raw=await req.text();if(raw.length>3000)return Response.json({error:'紀錄格式過長。'},{status:413,headers:noStore});
 let input;try{input=JSON.parse(raw);}catch{return Response.json({error:'紀錄格式錯誤。'},{status:400,headers:noStore});}
 if(!input||!['view','progress','bookmark','clear-bookmark','like'].includes(input.action))return Response.json({error:'操作格式錯誤。'},{status:400,headers:noStore});
 const who=await identity();if(!who)return Response.json({error:'請重新整理以啟用此瀏覽器的閱讀紀錄。'},{status:409,headers:noStore});
 const db=database();
 if(input.action==='clear-bookmark'){await db.prepare('UPDATE reader_devices SET bookmark=NULL WHERE device_key=?').bind(who.key).run();return reply(req,who,{ok:true});}
 const chapter=(await documents()).find(d=>d.kind==='chapter'&&d.id===input.chapterId&&!d.locked);
 if(!chapter)return Response.json({error:'這一話目前無法閱覽。'},{status:403,headers:noStore});
 if(input.action==='view'||input.action==='like'){
  if(input.action==='like'&&typeof input.liked!=='boolean')return Response.json({error:'按讚格式錯誤。'},{status:400,headers:noStore});
  if(input.action==='view')await db.prepare('INSERT INTO chapter_engagement(chapter_id,device_key,liked,viewed_at) VALUES(?,?,0,?) ON CONFLICT(chapter_id,device_key) DO NOTHING').bind(chapter.id,who.key,new Date().toISOString()).run();
  else await db.prepare('INSERT INTO chapter_engagement(chapter_id,device_key,liked,viewed_at) VALUES(?,?,?,?) ON CONFLICT(chapter_id,device_key) DO UPDATE SET liked=excluded.liked').bind(chapter.id,who.key,input.liked?1:0,new Date().toISOString()).run();
  return reply(req,who,{stats:await stats(chapter.id,who.key)});
 }
 const point=cleanReadingPoint(input.point,chapter);if(!point)return Response.json({error:'閱讀位置已變更，請重新整理本章後再儲存。'},{status:400,headers:noStore});
 if(input.action==='bookmark')await db.prepare('INSERT INTO reader_devices(device_key,bookmark) VALUES(?,?) ON CONFLICT(device_key) DO UPDATE SET bookmark=excluded.bookmark').bind(who.key,JSON.stringify(point)).run();
 else await db.prepare('INSERT INTO reader_devices(device_key,last_read,last_read_at) VALUES(?,?,?) ON CONFLICT(device_key) DO UPDATE SET last_read=excluded.last_read,last_read_at=excluded.last_read_at WHERE excluded.last_read_at>=reader_devices.last_read_at').bind(who.key,JSON.stringify(point),point.updatedAt).run();
 return reply(req,who,{ok:true});
 }catch(error){console.error('Reader state update failed',error);return Response.json({error:'閱讀紀錄未能儲存，請稍後重試。'},{status:503,headers:noStore});}}
