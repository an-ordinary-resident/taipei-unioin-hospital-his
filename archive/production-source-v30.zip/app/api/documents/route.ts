import { linkedTermRows,publicationNotes } from '@/lib/annotation-links';
import { referenceIds } from '@/lib/rich-text';
import { documents,isAuthor,mutationGuard,cleanDocument,database } from '@/lib/content';
export async function GET(req:Request){const author=new URL(req.url).searchParams.get('scope')==='author';if(author&&!await isAuthor())return Response.json({error:'無作者權限'},{status:403});return Response.json(await documents(author),{headers:{'Cache-Control':'no-store'}});}
export async function POST(req:Request){
 const denied=await mutationGuard(req);if(denied)return denied;
 if(Number(req.headers.get('content-length'))>1500000)return Response.json({error:'內容過大。'},{status:413});
 let payload;try{const raw=await req.text();if(raw.length>1000000)return Response.json({error:'內容過大。'},{status:413});payload=JSON.parse(raw);}catch{return Response.json({error:'資料格式錯誤。'},{status:400});}
 const doc=cleanDocument(payload.document);const action=payload.action;
 if(!doc||!['draft','publish','unpublish'].includes(action))return Response.json({error:'請確認標題、內容、卷別與排序格式。'},{status:400});
 if(action==='publish'&&(doc.notes?.length||referenceIds(doc.body+'\n'+(doc.details||'')+'\n'+(doc.background||'')).length)){const missing=referenceIds(doc.body+'\n'+(doc.details||'')+'\n'+(doc.background||'')).filter(id=>!doc.notes?.some(n=>n.id===id));if(missing.length)return Response.json({error:'以下編號尚未填寫註解：'+missing.map(id=>'['+id+']').join('、')},{status:400});}
 if(action==='publish'){try{doc.notes=publicationNotes(doc.notes||[],await linkedTermRows(database(),doc.notes||[]));}catch(error){return Response.json({error:error instanceof Error?error.message:'共用詞條尚未刊登。'},{status:400});}}
 const current=(await documents(true)).find(d=>d.id===doc.id);if(current&&current.revision!==doc.revision)return Response.json({error:'內容已在其他視窗更新，請重新載入後再編輯。'},{status:409});
 const before=(await documents(false,false)).find(d=>d.id===doc.id);
 const draft=JSON.stringify({...doc,revision:0});
 const published=action==='publish'?draft:action==='unpublish'?null:before?JSON.stringify({...before,revision:0,isPublished:undefined,hasDraft:undefined}):null;
 const result=await database().prepare('INSERT INTO documents (id,draft,published,revision,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET draft=excluded.draft,published=excluded.published,revision=documents.revision+1,updated_at=excluded.updated_at WHERE documents.revision=?').bind(doc.id,draft,published,1,new Date().toISOString(),doc.revision).run();
 if(!result.meta.changes)return Response.json({error:'內容已更新，請重新載入。'},{status:409});
 return Response.json({ok:true,document:(await documents(true)).find(d=>d.id===doc.id)});
}
