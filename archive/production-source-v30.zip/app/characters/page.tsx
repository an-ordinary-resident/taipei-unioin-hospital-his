import Shell from '@/components/his-shell';
import Protected from '@/components/protected-content';
import CharacterDirectory from '@/components/character-directory';
import { documents } from '@/lib/content';
import { ArrowUpRight,UserRound } from 'lucide-react';
export const dynamic='force-dynamic';
export default async function Characters(){const people=(await documents()).filter(d=>d.kind==='character').map(d=>({id:d.id,title:d.title,subtitle:d.subtitle,role:d.role||'',age:d.age,gender:d.gender,image:d.image,feature:d.feature||d.subtitle,category:d.category||'未分類',department:d.department,position:d.position,body:d.body}));return <Shell active="characters" title="人員檔案"><div className="page-heading"><div><span className="eyebrow">PERSONNEL DIRECTORY</span><h1>人員檔案</h1><p>醫術值得信任。生活常識，另當別論。</p></div><span className="outlined-label">{people.length} 份檔案</span></div><Protected><CharacterDirectory people={people}/></Protected>{!people.length&&<p className="panel empty-state">人員資料尚未刊載。</p>}</Shell>}
