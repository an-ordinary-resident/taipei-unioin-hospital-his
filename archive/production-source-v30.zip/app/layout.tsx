import type { Metadata } from 'next';
import './globals.css';
import './author-workspace.css';
import './volume-records.css';
import './dashboard-media.css';
import './sidebar-scroll.css';
import './glossary-tools.css';
import './reader-journey.css';
import './reader-tour.css';
import './campus.css';
import { ReadingPreferences } from '@/components/reading-preferences';
import { SitePresentation } from '@/components/site-presentation';
import { isAuthor } from '@/lib/content';
import { tourContent } from '@/lib/tour-content';
import { presentation } from '@/lib/presentation-store';
export const metadata: Metadata = {title:'內科住院醫師：崩壞實戰指引｜慈愛院區 HIS',description:'一個平凡的住院醫師的原創醫療小說。進入臺北市立聯邦醫院慈愛院區，閱讀全員異常的病程紀錄。',robots:{index:false,follow:false}};
export default async function RootLayout({children}:{children:React.ReactNode}) {const [{value},tour,author]=await Promise.all([presentation('dashboard'),presentation('tour'),isAuthor()]);return <html lang="zh-Hant" suppressHydrationWarning><body><ReadingPreferences><SitePresentation quotes={value.quotes} isAuthor={author} tour={tourContent(tour.value)}>{children}</SitePresentation></ReadingPreferences></body></html>}
