import { requireChatGPTUser } from '@/app/chatgpt-auth';
import { isAuthor,documents } from '@/lib/content';
import { presentation } from '@/lib/presentation-store';
import { AUTHOR_SECTIONS,dashboardRecords } from '@/lib/presentation-config';
import Shell from '@/components/his-shell';
import AuthorEditor from '@/components/author-editor';
import GlossaryEditor from '@/components/glossary-editor';
import TourEditor from '@/components/tour-editor';
import PresentationEditor from '@/components/presentation-editor';
export const dynamic='force-dynamic';
export default async function AuthorPage({searchParams}:{searchParams:Promise<{section?:string}>}){
 const requested=(await searchParams).section;const section=AUTHOR_SECTIONS.find(s=>s.id===requested)||AUTHOR_SECTIONS[0];
 await requireChatGPTUser('/author?section='+section.id);if(!await isAuthor())return <Shell active="author" title="作者工作台"><section className="panel denied"><h1>此帳號沒有編輯權限</h1><p>僅作品作者的指定帳號可以新增、修改與刊載內容。</p><a className="primary-btn" href="/dashboard">返回閱讀主控台</a></section></Shell>;
 return <Shell active="author" title={'作者工作台 · '+section.label}><div className="page-heading"><div><span className="eyebrow">AUTHOR WORKSPACE</span><h1>{section.label}</h1><p>作者工作台</p></div><span className="author-verified">作者權限已驗證</span></div><nav className="author-section-tabs" aria-label="作者工作台分類">{AUTHOR_SECTIONS.map(s=><a href={'/author?section='+s.id} key={s.id} aria-current={section.id===s.id?'page':undefined}>{s.label}</a>)}</nav>{section.id==='tour'?<TourEditor initial={await presentation('tour',true)}/>:section.id==='glossary'?<GlossaryEditor/>:section.id==='dashboard'||section.id==='about'?<PresentationEditor key={section.id} section={section.id} initial={await presentation(section.id,true)} all={section.id==='dashboard'?dashboardRecords(await documents()):[]}/>:<AuthorEditor key={section.id} mode={section.id} initial={(await documents(true)).filter(d=>section.id==='characters'?d.kind==='character':d.kind!=='character')}/>}</Shell>
}
