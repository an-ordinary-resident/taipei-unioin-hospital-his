import Shell from '@/components/his-shell';
import GlossaryList from '@/components/glossary-list';
export default function GlossaryPage(){
 return <Shell active="glossary" title="註釋辭典庫"><div className="page-heading"><div><span className="eyebrow">MEDICAL GLOSSARY</span><h1>註釋辭典庫</h1><p>查閱故事中的醫學名詞與作者解說。</p></div></div><GlossaryList/></Shell>;
}
