"use client";
export default function ErrorPage({reset}:{reset:()=>void}){return <main className="error-page panel"><h1>病歷暫時讀取失敗</h1><p>請稍後重試。尚未送出的編輯內容請先保留。</p><button className="primary-btn" onClick={reset}>重新讀取</button><a href="/">回登入頁</a></main>}
