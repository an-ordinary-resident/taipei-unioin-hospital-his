const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const {DatabaseSync}=require('node:sqlite');
function load(file,mocks={}){const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const mod={exports:{}};new Function('require','module','exports',code)(id=>{if(Object.hasOwn(mocks,id))return mocks[id];throw Error(id);},mod,mod.exports);return mod.exports;}
function harness(){
 const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync(path.join(__dirname,'../drizzle/0002_dapper_paper_doll.sql'),'utf8'));
 const state={author:true};
 const db={prepare(query){let params=[];return {bind(...v){params=v;return this;},async first(){return sql.prepare(query).get(...params)||null;},async all(){return {results:sql.prepare(query).all(...params)};},async run(){return {meta:{changes:Number(sql.prepare(query).run(...params).changes)}};}};},async batch(statements){sql.exec('BEGIN');try{const results=await Promise.all(statements.map(s=>s.run()));sql.exec('COMMIT');return results;}catch(e){sql.exec('ROLLBACK');throw e;}}};
 const route=load('app/api/glossary/batch/route.ts',{'@/lib/glossary':load('lib/glossary.ts'),'@/lib/content':{database:()=>db,isAuthor:async()=>state.author,mutationGuard:async req=>state.author&&req.headers.get('origin')==='https://his.test'?null:Response.json({error:'denied'},{status:403})}});
 const get=async()=>{const r=await route.GET();return {status:r.status,data:await r.json()};};
 const post=async(payload,origin='https://his.test')=>{const r=await route.POST(new Request('https://his.test/api/glossary/batch',{method:'POST',headers:{origin},body:JSON.stringify(payload)}));return {status:r.status,data:await r.json()};};
 return {state,get,post,sql,close:()=>sql.close()};
}
test('bulk import deduplicates notes, keeps conflicts intact and never publishes',async()=>{
 const h=harness();try{
  const a={term:'PGY',text:'- 第一點\n- [spoiler]吐槽[/spoiler]',tags:['行政職級']};
  assert.deepEqual((await h.post({action:'import-drafts',notes:[a,a,{term:'醫護',text:'解說'}]})).data,{added:2,existing:0,conflicts:[]});
  const result=await h.post({action:'import-drafts',notes:[a,{...a,term:'ｐｇｙ',text:'不同解說'},{term:'醫護',text:'解說'}]});
  assert.equal(result.data.added,0);assert.equal(result.data.existing,1);assert.equal(result.data.conflicts.length,1);
  const rows=h.sql.prepare('SELECT draft,published FROM glossary_terms').all();assert(rows.every(r=>r.published===null));assert(rows.some(r=>JSON.parse(r.draft).text===a.text));
 }finally{h.close();}
});
test('publish-all is atomic across all pending rows and rejects a stale review',async()=>{
 const h=harness();try{
  await h.post({action:'import-drafts',notes:Array.from({length:4},(_,i)=>({term:'名詞'+i,text:'解說'+i}))});
  const snapshot=(await h.get()).data;assert.equal(snapshot.pending,4);
  assert.deepEqual((await h.post({action:'publish-all',snapshot})).data,{published:4});
  assert(h.sql.prepare('SELECT draft,published,revision FROM glossary_terms').all().every(r=>r.draft===r.published&&r.revision===2));
  assert.equal((await h.get()).data.pending,0);
  const prior=(await h.get()).data;await h.post({action:'import-drafts',notes:[{term:'新詞條',text:'尚未確認的解說'}]});
  assert.equal((await h.post({action:'publish-all',snapshot:prior})).status,409);
  assert.equal(h.sql.prepare("SELECT published FROM glossary_terms WHERE term_key='新詞條'").get().published,null);
 }finally{h.close();}
});
test('batch routes enforce author access and validate the entire import before writes',async()=>{
 const h=harness();try{
  h.state.author=false;assert.equal((await h.get()).status,403);assert.equal((await h.post({action:'publish-all',snapshot:{total:0,pending:0,revisionSum:0}})).status,403);
  h.state.author=true;assert.equal((await h.post({action:'import-drafts',notes:[{term:'x',text:'y'}]},'https://evil.test')).status,403);
  assert.equal((await h.post({action:'import-drafts',notes:[{term:'完整',text:'解說'},{term:'不完整'}]})).status,400);assert.equal((await h.get()).data.total,0);
  assert.equal((await h.post({action:'import-drafts',notes:Array(201).fill({term:'x',text:'y'})})).status,400);
 }finally{h.close();}
});
