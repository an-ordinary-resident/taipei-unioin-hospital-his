const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
const cache=new Map();
function load(file){
 if(cache.has(file))return cache.get(file);
 const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const mod={exports:{}};
 new Function('require','module','exports',code)(id=>id.startsWith('.')?load(path.posix.join(path.posix.dirname(file),id+'.ts')):require(id),mod,mod.exports);
 cache.set(file,mod.exports);return mod.exports;
}
const {editorDocument,storedProse}=load('lib/editor-document.ts');
const {INKS,inlineNodes,plainText,referenceIds,safeLink,proseBlocks}=load('lib/prose-format.ts');
const {parseAnnotatedText,wordCount}=load('lib/rich-text.ts');
const {getSchema}=require('@tiptap/core');
const {proseEditorExtensions}=load('lib/editor-extensions.ts');
const schema=getSchema(proseEditorExtensions());
const roundTrip=source=>storedProse(schema.nodeFromJSON(editorDocument(source)).toJSON());

test('spoilers round-trip alongside nested styles and remain masked in reader headings',()=>{
 const {proseHeadings}=load('lib/prose-format.ts');
 const source='- 正常解說\n- [spoiler][color=red]**不該說的大實話**[/color][/spoiler]\n# [spoiler]劇透標題[/spoiler]';
 assert.equal(roundTrip(source),source);
 assert.equal(plainText(source),'正常解說\n不該說的大實話\n劇透標題');
 assert.equal(plainText(source,true),'正常解說\n▇▇▇\n▇▇▇');
 assert.equal(proseHeadings(source,'x')[0].title,'▇▇▇');
 const notes=[{id:7,term:'PGY',text:'[spoiler]保留註釋[/spoiler]',tags:['行政職級']}];
 const {reorderAnnotations}=load('lib/annotation-order.ts');
 const result=reorderAnnotations(editorDocument('[spoiler]秘密[7][/spoiler]'),notes);
 assert.deepEqual(result.notes,[{...notes[0],id:1}]);
 assert.equal(storedProse(result.doc),'[spoiler]秘密[/spoiler][spoiler][1][/spoiler]');
});

test('chapter backup exports unsaved body, chapter information, all notes and portable rich formats',()=>{
 const {chapterBackup,exportProse}=load('lib/chapter-backup.ts');
 const volume={id:'v1',kind:'volume',volume:'v1',title:'第一卷',order:1};
 const old={id:'c1',kind:'chapter',volume:'v1',title:'舊標題',order:1,body:'舊內文',subtitle:'',notes:[]};
 const doc={...old,title:'新標題',subtitle:'住院病程',cast:['陳屏帆','江柏川'],readingMinutes:'15–20 分鐘',summary:'未儲存的大綱',body:'# 大標題\n## 中標題\n### 小標題\n**重點** [i]斜體[/i] [s]刪除[/s] [u]底線[/u]\n- 列點[7]\n[color=green]吐槽綠[/color]\n[align=center]置中[/align]\n[link=https%3A%2F%2Fexample.com]參考[/link]\n---',notes:[{id:7,term:'PGY',text:'- 第一點\n- [spoiler]大實話[/spoiler]',tags:['行政職級']},{id:9,term:'未引用名詞',text:'也需完整保留'}]};
 const result=chapterBackup(doc,[volume,old],'https://his.test',new Date('2026-09-28T00:00:00Z'));
 for(const text of ['新標題','未儲存的大綱','陳屏帆、江柏川','15–20 分鐘','Log 1','第一卷','PGY','未引用名詞','也需完整保留','行政職級']){assert(result.markdown.includes(text),text);assert(result.html.includes(text),text);}
 assert(!result.markdown.includes('舊內文'));
 assert(result.markdown.includes('# 大標題'));
 assert(result.markdown.includes('**重點** *斜體* ~~刪除~~ <u>底線</u>'));
 assert(result.markdown.includes('color:#2ecc71'));
 assert(result.markdown.includes('text-align:center'));
 assert(result.markdown.includes('- 第一點'));
 assert(result.markdown.includes('data-spoiler="true"'));
 assert(result.html.includes('<li>列點<sup>'));
 assert(result.html.includes('<h3>小標題</h3>'));
 assert.equal(exportProse('[image:/api/media/00000000-0000-4000-8000-000000000001]','markdown','https://his.test'),'![作品插圖](<https://his.test/api/media/00000000-0000-4000-8000-000000000001>)');
});

test('backup escapes executable HTML, rejects unsafe links and keeps literal formatting characters',()=>{
 const {chapterBackup,exportProse}=load('lib/chapter-backup.ts');
 const text='<script>alert("x")</script>\n[link=javascript%3Aalert(1)]危險連結[/link]\n\\*普通文字\\*';
 const html=exportProse(text,'html');
 assert(!html.includes('<script>'));assert(html.includes('&lt;script&gt;'));assert(!html.includes('href="javascript:'));
 assert(html.includes('<p>*普通文字*</p>'));
 const result=chapterBackup({id:'c1',kind:'chapter',title:'../<img onerror="x">',body:text,volume:'v',subtitle:'',notes:[]},[],'https://his.test');
 assert(!/[\\/:*?"<>|]/.test(result.filename));
 assert(!result.html.includes('<img onerror'));
 assert.equal(exportProse('\\# 字面標題','markdown'),'\\# 字面標題');
});

test('reader section anchors match actual prose block positions and strip inline formatting',()=>{
 const {proseHeadings}=load('lib/prose-format.ts');
 assert.deepEqual(proseHeadings('開場\n# **大標題**\n內文\n## 中標題\n### 小標題','chapter-one'),[
  {id:'chapter-one-2',level:1,title:'大標題'},{id:'chapter-one-4',level:2,title:'中標題'},{id:'chapter-one-5',level:3,title:'小標題'},
 ]);
});

test('empty headings and empty list items keep their format when switching tabs',()=>{
 for(const source of ['# ','## ','### ','- 項目\n- '])assert.equal(roundTrip(source),source);
});

test('legacy formats, annotations, blank lines and uploaded images survive the visual editor',()=>{
 const source='【人物簡介】\n**陳屏帆**：只想準時下班。\n\n- [u]PGY[/u][1]\n- [color=blue]值班中[/color]\n\n---\n[image:/api/media/00000000-0000-4000-8000-000000000001]';
 const result=roundTrip(source);
 assert.equal(result,source);
 assert.deepEqual(referenceIds(result),[1]);
 assert.equal(plainText(result),plainText(source));
});
test('new headings and all overlapping marks round-trip to visible text without exposing markup',()=>{
 const source='# 大標題\n## 中標題\n### 小標題\n[link=https%3A%2F%2Fexample.com%2F%3Fid%3D%5B2%5D][color=green]**[i][s][u]重點文字[/u][/s][/i]**[/color][/link][1]';
 assert.equal(roundTrip(source),source);
 assert.equal(plainText(source),'大標題\n中標題\n小標題\n重點文字');
 assert.equal(wordCount(source),13);
 assert.deepEqual(referenceIds(source),[1]);
 assert.deepEqual(proseBlocks(source).slice(0,3).map(b=>b.level),[1,2,3]);
});
test('literal brackets, asterisks, bullet symbols and heading prefixes stay literal after editing',()=>{
 const lines=['**不是粗體** [1] [u]原樣[/u]','*原樣* ~~原樣~~','兩人 • 對話','- 原樣','# 原樣','---','C:\\temp\\new'];
 const doc={type:'doc',content:lines.map(text=>({type:'paragraph',content:[{type:'text',text}]}))};
 const stored=storedProse(doc);
 assert.equal(plainText(stored),lines.join('\n'));
 assert.deepEqual(referenceIds(stored),[]);
 assert.equal(storedProse(editorDocument(stored)),stored);
});
test('five author colors keep exact names and hex in both storage and rendered schema',()=>{
 assert.deepEqual(INKS.map(i=>[i.name,i.hex]),[['吐槽綠','#2ecc71'],['笨蛋藍','#3498db'],['中二紅','#e74c3c'],['被虐橘','#f39c12'],['自戀紫','#9b59b6']]);
 for(const ink of INKS){
  const doc=editorDocument('[color='+ink.id+']文字[/color]');
  assert.equal(doc.content[0].content[0].marks[0].attrs.color,ink.hex);
  assert.equal(roundTrip('[color='+ink.id+']文字[/color]'),'[color='+ink.id+']文字[/color]');
 }
});
test('links reject executable, protocol-relative and disguised URLs while preserving labels',()=>{
 for(const value of ['javascript:alert(1)','data:text/html,test','//example.com','https://a.com\\evil','https://a.com\nbad'])assert.equal(safeLink(value),null);
 for(const value of ['https://example.com/?q=中文#term','http://example.com','mailto:author@example.com','/volumes'])assert.equal(safeLink(value),value);
 assert.deepEqual(inlineNodes('[link=javascript%3Aalert(1)]原文字[/link]'),[{kind:'text',text:'原文字'}]);
});
test('pasted story and numbered explanations remain recognizable after a visual editing round trip',()=>{
 const source='【故事內文】\n**R3**看著PGY[1]。\n【用詞註釋】\n[1] PGY：畢業後一般醫學訓練。';
 const parsed=parseAnnotatedText(roundTrip(source));
 assert.ok(parsed);assert.equal(parsed.notes[0].term,'PGY');assert.equal(parsed.notes[0].text,'畢業後一般醫學訓練。');
 assert.equal(plainText(parsed.body),'R3看著PGY。');
});
test('annotation reordering preserves repeated references, formatting, literal numbers and unreferenced notes',()=>{
 const {reorderAnnotations,removeAnnotation}=load('lib/annotation-order.ts');
 const notes=[{id:8,term:'A',text:'第一則 [2]'},{id:2,term:'B',text:'第二則'},{id:9,term:'保留',text:'尚未引用'}];
 const body='# 標題\n**先B[2]**再A[8]又B[2]，原字\\[2\\]。\n[link=https%3A%2F%2Fexample.com%2F%3Fq%3D%5B8%5D]網址[/link]';
 const initial=editorDocument(body),result=reorderAnnotations(initial,notes);
 assert.deepEqual(result.notes.map(n=>[n.id,n.term]),[[1,'B'],[2,'A'],[3,'保留']]);
 assert.equal(result.notes[1].text,'第一則 [2]');
 assert.deepEqual(result.doc,editorDocument('# 標題\n**先B[1]**再A[2]又B[1]，原字\\[2\\]。\n[link=https%3A%2F%2Fexample.com%2F%3Fq%3D%5B8%5D]網址[/link]'));
 const swapped=reorderAnnotations(result.doc,result.notes,[2,1,3]);
 assert.deepEqual(swapped.notes.map(n=>n.term),['A','B','保留']);
 assert.deepEqual(referenceIds(storedProse(swapped.doc)),[2,1]);
 assert.deepEqual(initial,editorDocument(body));
 assert.deepEqual(referenceIds(storedProse(removeAnnotation(swapped.doc,2))),[1]);
 assert.throws(()=>reorderAnnotations(editorDocument('未定義[99]'),notes),/99/);
});

test('undo and redo keep annotation definitions paired with renumbered references',()=>{
 const {reorderAnnotations}=load('lib/annotation-order.ts');
 const {EditorState}=require('@tiptap/pm/state');
 const {history,closeHistory,undo,redo}=require('@tiptap/pm/history');
 const notes=[{id:1,term:'甲',text:'解說甲'},{id:2,term:'乙',text:'解說乙'}];
 const source={...editorDocument('先乙[2]後甲[1]'),attrs:{annotations:notes}};
 let state=EditorState.create({schema,doc:schema.nodeFromJSON(source),plugins:[history()]});
 const result=reorderAnnotations(state.doc.toJSON(),notes);
 const next=schema.nodeFromJSON(result.doc);
 state=state.apply(closeHistory(state.tr.replaceWith(0,state.doc.content.size,next.content).setDocAttribute('annotations',result.notes)));
 state=state.apply(closeHistory(state.tr));
 assert.equal(storedProse(state.doc.toJSON()),'先乙[1]後甲[2]');
 assert.deepEqual(state.doc.attrs.annotations.map(n=>n.term),['乙','甲']);
 assert(undo(state,tr=>{state=state.apply(tr);}));
 assert.equal(storedProse(state.doc.toJSON()),'先乙[2]後甲[1]');
 assert.deepEqual(state.doc.attrs.annotations,notes);
 assert(redo(state,tr=>{state=state.apply(tr);}));
 assert.equal(storedProse(state.doc.toJSON()),'先乙[1]後甲[2]');
 assert.deepEqual(state.doc.attrs.annotations,result.notes);
});
test('alignment survives editing, annotation renumbering, headings and list items',()=>{
 const source='[align=center]# **置中標題**[/align]\n[align=right]說明[2][/align]\n[align=left]- 項目一[/align]\n[align=center]- 項目二[/align]';
 assert.equal(roundTrip(source),source);
 assert.equal(plainText(source),'置中標題\n說明\n項目一\n項目二');
 assert.deepEqual(proseBlocks(source).map(b=>b.alignment),['center','right','left','center']);
 const {reorderAnnotations}=load('lib/annotation-order.ts');
 const sorted=reorderAnnotations(editorDocument(source),[{id:2,term:'說明',text:'解說'}]);
 assert.equal(storedProse(sorted.doc),source.replace('[2]','[1]'));
 assert.deepEqual(load('lib/prose-format.ts').proseHeadings(source,'chapter'),[{id:'chapter-1',level:1,title:'置中標題'}]);
});

test('every requested symbol inserts as literal text without creating emphasis or list markup',()=>{
 const {EDITOR_SYMBOLS}=load('lib/editor-symbols.ts');
 for(const symbol of EDITOR_SYMBOLS){
  const doc={type:'doc',content:[{type:'paragraph',content:[{type:'text',text:symbol}]}]};
  const stored=storedProse(doc);
  assert.equal(plainText(roundTrip(stored)),symbol,symbol);
  assert.deepEqual(referenceIds(stored),[]);
 }
});
