const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'../lib/reader-profile.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText;
const mod={exports:{}};new Function('module','exports',code)(mod,mod.exports);
const {checkedProfile,initialProfile,readerAvatars}=mod.exports;
test('old profiles retain their uploaded avatar and use the existing dashboard sanity default',()=>{
 const old={name:'夜班小醫師',role:'R2',motto:'平安交班',avatar:'data:image/jpeg;base64,YWJj'};
 const next=checkedProfile(old,{...initialProfile,sanity:42});
 assert.deepEqual(next,{...old,sanity:42});
});
test('all hospital avatars survive save/reload and map to existing supplied assets',()=>{
 for(const avatar of readerAvatars){const input={...initialProfile,avatar:avatar.id,sanity:0};assert.deepEqual(checkedProfile(JSON.parse(JSON.stringify(input)),initialProfile),input);assert.ok(fs.statSync(path.join(__dirname,'../public',avatar.src)).size>0);}
});
test('untrusted saved preferences cannot introduce arbitrary avatar URLs or invalid percentages',()=>{
 assert.equal(checkedProfile({avatar:'https://example.com/tracker.jpg',sanity:Infinity},initialProfile).avatar,'doctor');
 assert.equal(checkedProfile({sanity:Infinity},initialProfile).sanity,initialProfile.sanity);
 assert.equal(checkedProfile({sanity:-9},initialProfile).sanity,0);
 assert.equal(checkedProfile({sanity:199},initialProfile).sanity,100);
 assert.equal(checkedProfile({sanity:52.7},initialProfile).sanity,53);
});
