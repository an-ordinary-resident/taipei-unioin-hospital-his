const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');

function load(file, mocks = {}) {
  const filename = path.join(__dirname, '..', file);
  const code = ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true } }).outputText;
  const module = { exports: {} };
  new Function('require', 'module', 'exports', code)(id => {
    if (Object.hasOwn(mocks, id)) return mocks[id];
    throw Error('Unexpected dependency: ' + id);
  }, module, module.exports);
  return module.exports;
}
const access = load('lib/story-access.ts');
const base = { id: 'vol-test', kind: 'volume', volume: 'vol-test', title: 'Test', subtitle: '', body: 'Public synopsis', image: '', order: 1, revision: 0 };
const chapter = { ...base, id: 'chapter-test', kind: 'chapter', body: 'PRIVATE STORY', summary: 'PRIVATE SUMMARY', image: '/api/media/00000000-0000-4000-8000-000000000000', notes: [{ id: 1, term: 'term', text: 'PRIVATE NOTE' }], cast: ['PRIVATE CAST'] };

function content(rows, rank = 0) {
  return load('lib/content.ts', {
    'cloudflare:workers': { env: { DB: { prepare: () => ({ all: async () => ({ results: rows }) }) } } },
    '@/data/seed.json': [], '@/data/chapter-updates.json': { id: 'unused', expectedBodies: [] },
    '@/data/personnel-import.json': { records: [] },
    './rich-text': { referenceIds: () => [] },
    './glossary': load('lib/glossary.ts'),
    './annotation-links': load('lib/annotation-links.ts', {'./glossary': load('lib/glossary.ts')}),
    './story-access': access, './reader-access': { readerIdentity: async () => ({ rank }) },
    '@/app/chatgpt-auth': { getChatGPTUser: async () => null },
  });
}
const stored = (published, draft = published) => ({ id: (published || draft).id, published: published ? JSON.stringify(published) : null, draft: JSON.stringify(draft), revision: 2 });

test('formal chapters number across volumes while interludes, appendices, afterwords and bonuses stay outside the count',()=>{
 const volumes=[{...base,id:'v1',order:1},{...base,id:'v2',order:2},{...base,id:'vb',order:3,volumeType:'bonus'}];
 const records=volumes.flatMap(v=>Array.from({length:15},(_,i)=>({...chapter,id:v.id+'-'+i,volume:v.id,order:i+1,chapterType:'main'})));
 records.push({...chapter,id:'interlude',volume:'v1',order:5,chapterType:'interlude'},{...chapter,id:'attachment-01',volume:'v1',order:16},{...chapter,id:'afterword',volume:'v1',order:17},{...chapter,id:'music',volume:'v1',order:18});
 const labeled=access.chapterLabels([...volumes,...records].reverse());const label=id=>labeled.find(d=>d.id===id).chapterLabel;
 assert.equal(label('v1-0'),'1');assert.equal(label('v1-14'),'15');assert.equal(label('v2-0'),'16');assert.equal(label('v2-14'),'30');
 assert.equal(label('interlude'),'間章');assert.equal(label('attachment-01'),'附錄');assert.equal(label('afterword'),'後記');assert.equal(label('music'),'附錄');assert.equal(label('vb-0'),'番外篇');
});

test('new chapter categories validate and stay public inside a main volume',async()=>{
 for(const chapterType of ['interlude','afterword']){
  const mod=content([stored(base),stored({...chapter,chapterType})]);
  assert.equal(mod.cleanDocument({...chapter,chapterType}).chapterType,chapterType);
  assert.equal((await mod.documents()).find(d=>d.id===chapter.id).locked,false);
 }
});

test('bonus volume locks every chapter type for visitors and students', async () => {
  for (const rank of [0, 1]) for (const chapterType of ['main', 'appendix', 'bonus']) {
    const mod = content([stored({ ...base, volumeType: 'bonus' }), stored({ ...chapter, chapterType })], rank);
    const docs = await mod.documents();
    assert.equal(docs.find(d => d.id === base.id).locked, true);
    const result = docs.find(d => d.id === chapter.id);
    assert.equal(result.locked, true);
    assert.equal(result.body, '');
    assert.equal(result.image, '');
    assert.ok(!JSON.stringify(result).includes('PRIVATE'));
  }
});
test('resident and attending can read bonus volume chapters', async () => {
  for (const rank of [2, 3]) {
    const docs = await content([stored({ ...base, volumeType: 'bonus' }), stored(chapter)], rank).documents();
    assert.equal(docs.find(d => d.id === chapter.id).body, chapter.body);
    assert.equal(docs.find(d => d.id === chapter.id).locked, false);
  }
});
test('legacy main volumes keep main chapters and appendices public', async () => {
  for (const chapterType of ['main', 'appendix']) {
    const docs = await content([stored(base), stored({ ...chapter, chapterType })]).documents();
    assert.equal(docs.find(d => d.id === chapter.id).body, chapter.body);
  }
});
test('individual bonus chapter is still locked inside a main volume', async () => {
  const docs = await content([stored(base), stored({ ...chapter, chapterType: 'bonus' })]).documents();
  assert.equal(docs.find(d => d.id === chapter.id).locked, true);
});
test('draft volume classification does not change published reader access', async () => {
  for (const [publishedType, draftType, locked] of [['main', 'bonus', false], ['bonus', 'main', true]]) {
    const mod = content([stored({ ...base, volumeType: publishedType }, { ...base, volumeType: draftType }), stored(chapter)]);
    assert.equal((await mod.documents()).find(d => d.id === chapter.id).locked, locked);
    const authorDocs = await mod.documents(true);
    assert.equal(authorDocs.find(d => d.id === base.id).volumeType, draftType);
    assert.equal(authorDocs.find(d => d.id === chapter.id).body, chapter.body);
  }
});
test('unpublished volumes cannot expose their chapters', async () => {
  const docs = await content([stored(null, { ...base, volumeType: 'bonus' }), stored(chapter)], 3).documents();
  assert.ok(!docs.some(d => d.id === chapter.id));
});
test('volume classification and supplied cover survive validation; removal stays empty', () => {
  const { cleanDocument } = content([]);
  assert.equal(cleanDocument({ ...base, volumeType: 'bonus', image: '/covers/vol-1.png' }).volumeType, 'bonus');
  assert.equal(cleanDocument({ ...base, image: '/covers/vol-1.png' }).image, '/covers/vol-1.png');
  assert.equal(cleanDocument({ ...base, image: '' }).image, '');
  assert.equal(cleanDocument(base).volumeType, 'main');
  assert.equal(cleanDocument({ ...base, volumeType: 'invalid' }), null);
  assert.equal(cleanDocument({ ...base, image: 'https://untrusted.example/cover.png' }), null);
});
