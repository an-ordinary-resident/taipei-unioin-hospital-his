const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
function load(file, mocks = {}) {
  const code = ts.transpileModule(fs.readFileSync(path.join(__dirname, '..', file), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  const module = { exports: {} };
  new Function('require', 'module', 'exports', code)(id => { if (Object.hasOwn(mocks, id)) return mocks[id]; if(id.startsWith('.'))return load(path.posix.join(path.posix.dirname(file),id+'.ts')); throw Error(id); }, module, module.exports);
  return module.exports;
}
const config = load('lib/presentation-config.ts', { './rich-text': load('lib/rich-text.ts', { './prose-format': load('lib/prose-format.ts') }) });
const portrait = '/api/media/00000000-0000-4000-8000-000000000001';
const original = '/api/media/00000000-0000-4000-8000-000000000002';
const person = { id: 'person-1', kind: 'character', image: original };
test('custom header portrait belongs to its character and does not replace recommendation photo', () => {
  const settings = { ...config.DEFAULT_DASHBOARD, dutyPortraits: { 'person-1': portrait } };
  assert.equal(config.dutyPortrait(settings, person), portrait);
  assert.equal(config.dutyPortrait(settings, { ...person, id: 'person-2' }), original);
  assert.equal(config.dutyPortrait({ ...settings, dutyPortraits: {} }, person), original);
  assert.equal(config.dutyPortrait(config.DEFAULT_DASHBOARD, { ...person, image: '' }), '');
  assert.equal(config.dashboardRecords([person])[0].image, original);
});
test('portrait settings validate uploaded URLs and retain compatibility with older settings', () => {
  const store = load('lib/presentation-store.ts', { './content': {}, './presentation-config': config });
  const old = { ...config.DEFAULT_DASHBOARD }; delete old.dutyPortraits;
  assert.deepEqual(store.cleanPresentation('dashboard', old).dutyPortraits, {});
  assert.deepEqual(store.cleanPresentation('dashboard', { ...old, dutyPortraits: { 'person-1': portrait } }).dutyPortraits, { 'person-1': portrait });
  for (const dutyPortraits of [null, [], { '../person': portrait }, { 'person-1': 'javascript:alert(1)' }, { 'person-1': 'https://example.com/photo.png' }]) {
    assert.equal(store.cleanPresentation('dashboard', { ...old, dutyPortraits }), null);
  }
});
test('draft portrait does not change the reader-facing settings until published', async () => {
  const published = config.DEFAULT_DASHBOARD;
  const draft = { ...published, dutyPortraits: { 'person-1': portrait } };
  const row = { published: JSON.stringify(published), draft: JSON.stringify(draft), revision: 3 };
  const store = load('lib/presentation-store.ts', { './content': { database: () => ({ prepare: () => ({ bind: () => ({ first: async () => row }) }) }) }, './presentation-config': config });
  assert.equal(config.dutyPortrait((await store.presentation('dashboard')).value, person), original);
  assert.equal(config.dutyPortrait((await store.presentation('dashboard', true)).value, person), portrait);
  row.published = row.draft;
  assert.equal(config.dutyPortrait((await store.presentation('dashboard')).value, person), portrait);
});
