const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
function load(file,mocks={}){const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const mod={exports:{}};new Function('require','module','exports',code)(id=>{if(id in mocks)return mocks[id];throw Error(id)},mod,mod.exports);return mod.exports;}
const policy=load('lib/reader-tour.ts');
test('tour cookie distinguishes completion, skip and resumable steps without trusting corrupt values',()=>{
 assert.deepEqual(policy.parseTourCookie('1.active.7'),{status:'active',step:7});
 assert.deepEqual(policy.parseTourCookie('1.done.15'),{status:'done',step:15});
 assert.deepEqual(policy.parseTourCookie('1.skipped.0'),{status:'skipped',step:0});
 for(const raw of ['','2.done.0','1.active.-1','1.active.17','1.active.99','1.missing.0','1.done.0;another=1'])assert.equal(policy.parseTourCookie(raw),null);
});
test('tour return URLs are limited to local reader pages and preserve reading anchors',()=>{
 assert.equal(policy.safeTourPath('/read/log-01?his-tour=1&resume=bookmark#chapter-2'),'/read/log-01?resume=bookmark#chapter-2');
 for(const raw of ['https://evil.test','//evil.test','/author','/api/documents','/dashboard/../author','javascript:alert(1)',null])assert.equal(policy.safeTourPath(raw),null);
});
test('guided previews never write views/progress; explicit bookmark actions still work',async()=>{
 const originalFetch=global.fetch;let preview=true,calls=[];
 global.fetch=async(url,options)=>{calls.push(JSON.parse(options.body));return {ok:true,json:async()=>({ok:true})};};
 const client=load('lib/reader-client.ts',{'./reader-tour':{tourPreviewActive:()=>preview}});
 try{
  await client.readerMutation({action:'view',chapterId:'log-01'});
  await client.readerMutation({action:'progress',chapterId:'log-01'});
  assert.equal(calls.length,0);
  await client.readerMutation({action:'bookmark',chapterId:'log-01'});assert.equal(calls[0].action,'bookmark');
  preview=false;await client.readerMutation({action:'view',chapterId:'log-01'});assert.equal(calls[1].action,'view');
 }finally{global.fetch=originalFetch;}
});
