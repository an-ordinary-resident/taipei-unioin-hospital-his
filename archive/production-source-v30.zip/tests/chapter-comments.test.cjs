const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const {DatabaseSync}=require('node:sqlite');
function load(file,mocks={}){const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const m={exports:{}};new Function('require','module','exports',code)(id=>{if(Object.hasOwn(mocks,id))return mocks[id];throw Error(id);},m,m.exports);return m.exports;}
const prose=load('lib/prose-format.ts'),policy=load('lib/comment-policy.ts',{'./prose-format':prose});
function harness(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(fs.readFileSync(path.join(__dirname,'../drizzle/0001_curved_roughhouse.sql'),'utf8'));
 const state={jar:new Map(),author:false,user:null,locked:false};
 const db={prepare(sql){let params=[];return {bind(...values){params=values;return this;},async first(){return sqlite.prepare(sql).get(...params)||null;},async all(){return {results:sqlite.prepare(sql).all(...params)};},async run(){const r=sqlite.prepare(sql).run(...params);return {meta:{changes:Number(r.changes)}};}};}};
 const route=load('app/api/chapter-comments/route.ts',{
  'next/headers':{cookies:async()=>({get:name=>state.jar.has(name)?{value:state.jar.get(name)}:undefined})},
  '@/app/chatgpt-auth':{getChatGPTUser:async()=>state.user},
  '@/lib/content':{database:()=>db,documents:async()=>[{id:'chapter-one',kind:'chapter',locked:state.locked}],isAuthor:async()=>state.author},
  '@/lib/comment-policy':policy,
 });
 async function get(query=''){const r=await route.GET(new Request('https://hospital.test/api/chapter-comments?chapterId=chapter-one'+query));const cookie=r.headers.get('set-cookie');if(cookie)state.jar.set('his-comment-owner',cookie.split(';')[0].split('=')[1]);return {status:r.status,data:await r.json()};}
 async function post(patch,origin='https://hospital.test'){const r=await route.POST(new Request('https://hospital.test/api/chapter-comments',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({action:'create',chapterId:'chapter-one',kind:'visitor',name:'訪客',body:'閱讀心得',url:'',...patch})}));const cookie=r.headers.get('set-cookie');if(cookie)state.jar.set('his-comment-owner',cookie.split(';')[0].split('=')[1]);return {status:r.status,data:await r.json()};}
 return {state,get,post,close:()=>sqlite.close()};
}
test('guest ownership survives reload, blocks other browsers, and never exposes edit credentials',async()=>{
 const h=harness();try{
  await h.get();const token=h.state.jar.get('his-comment-owner');
  assert.equal((await h.post({})).status,200);
  let data=(await h.get()).data;const row=data.comments[0];assert.equal(row.canEdit,true);assert.equal(row.kind,'visitor');
  assert.ok(!JSON.stringify(data).includes('owner_key'));assert.ok(!JSON.stringify(data).includes(token));
  h.state.jar.clear();await h.get();assert.equal((await h.get()).data.comments[0].canEdit,false);
  assert.equal((await h.post({action:'update',id:row.id,revision:1})).status,403);
  assert.equal((await h.post({action:'delete',id:row.id,revision:1})).status,403);
  h.state.jar.set('his-comment-owner',token);
  assert.equal((await h.post({action:'update',id:row.id,revision:1,body:'修改後的心得'})).status,200);
  assert.equal((await h.get()).data.comments[0].body,'修改後的心得');
  assert.equal((await h.post({action:'update',id:row.id,revision:1})).status,409);
  assert.equal((await h.post({action:'delete',id:row.id,revision:2})).status,200);
  assert.equal((await h.get()).data.comments.length,0);
 }finally{h.close();}
});
test('author can manage guest comments and publish reference material; guests cannot claim author status',async()=>{
 const h=harness();try{
  await h.get();assert.equal((await h.post({kind:'author',isAuthor:true})).status,400);
  await h.post({});const row=(await h.get()).data.comments[0];
  h.state.jar.clear();h.state.author=true;h.state.user={userId:'verified-author'};
  assert.equal((await h.post({action:'update',id:row.id,revision:1,body:'作者補充',name:'替換名稱'})).status,200);
  const updated=(await h.get()).data.comments[0];assert.equal(updated.name,'訪客');assert.equal(updated.edited_by_author,1);
  assert.equal((await h.post({kind:'reference',url:'https://example.com/paper',body:'參考資料'})).status,200);
  assert.equal((await h.get('&kind=reference')).data.comments.length,1);
  assert.equal((await h.post({kind:'reference',url:'javascript:alert(1)'})).status,400);
 }finally{h.close();}
});
test('comment API enforces chapter access, origin, input limits and posting rate',async()=>{
 const h=harness();try{
  await h.get();assert.equal((await h.post({},'https://other.test')).status,403);
  assert.equal((await h.post({body:'x'.repeat(5001)})).status,400);
  for(let i=0;i<5;i++)assert.equal((await h.post({})).status,200);
  assert.equal((await h.post({})).status,429);
  h.state.locked=true;assert.equal((await h.get()).status,403);assert.equal((await h.post({})).status,403);
  assert.equal((await h.post({chapterId:'missing'})).status,403);
 }finally{h.close();}
});
test('pagination returns older comments once and filters author references independently',async()=>{
 const h=harness();try{
  h.state.author=true;h.state.user={userId:'author'};await h.get();
  for(let i=0;i<33;i++)await h.post({kind:'author',body:'評論 '+i});
  const first=(await h.get()).data,second=(await h.get('&before='+first.nextCursor)).data;
  assert.equal(first.comments.length,30);assert.equal(second.comments.length,3);assert.equal(second.nextCursor,null);
  assert.equal(new Set([...first.comments,...second.comments].map(x=>x.id)).size,33);
  assert.equal((await h.get('&kind=reference')).data.comments.length,0);
 }finally{h.close();}
});

