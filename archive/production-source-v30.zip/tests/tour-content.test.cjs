const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const {DatabaseSync}=require('node:sqlite');
function load(file,mocks={}){const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;const mod={exports:{}};new Function('require','module','exports',code)(id=>{if(Object.hasOwn(mocks,id))return mocks[id];if(id.startsWith('.'))return load(path.posix.join(path.posix.dirname(file),id+'.ts'));throw Error(id);},mod,mod.exports);return mod.exports;}
const copy=load('lib/tour-content.ts');
function harness(){
 const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync(path.join(__dirname,'../drizzle/0000_orange_gideon.sql'),'utf8'));
 const state={user:null};
 const db={prepare(query){let params=[];return {bind(...p){params=p;return this;},async first(){return sql.prepare(query).get(...params)||null;},async all(){return {results:sql.prepare(query).all(...params)};},async run(){return {meta:{changes:Number(sql.prepare(query).run(...params).changes)}};}};}};
 const content=load('lib/content.ts',{'cloudflare:workers':{env:{DB:db,AUTHOR_EMAIL:'author@example.test'}},'@/app/chatgpt-auth':{getChatGPTUser:async()=>state.user},'@/data/seed.json':[],'@/data/chapter-updates.json':{id:'none',expectedBodies:[]},'@/data/personnel-import.json':{records:[]},'./reader-access':{readerIdentity:async()=>({rank:3})}});
 const store=load('lib/presentation-store.ts',{'./content':content});
 const route=load('app/api/site-config/[section]/route.ts',{'@/lib/content':content,'@/lib/presentation-store':store,'@/lib/rich-text':{referenceIds:()=>[]}});
 const params={params:Promise.resolve({section:'tour'})};
 const get=scope=>route.GET(new Request('https://his.test/api/site-config/tour'+(scope?'?scope=author':'')),params);
 const post=(value,revision,action='draft',origin='https://his.test')=>route.POST(new Request('https://his.test/api/site-config/tour',{method:'POST',headers:{origin,cookie:'his-reader-role=attending'},body:JSON.stringify({value,revision,action})}),params);
 return {state,content,store,get,post,close:()=>sql.close()};
}
test('only the verified author account can read drafts or change tutorial copy',async()=>{
 const h=harness();try{
  for(const user of [null,{email:'reader@example.test'}]){h.state.user=user;assert.equal(await h.content.isAuthor(),false);assert.equal((await h.get(true)).status,403);assert.equal((await h.post(copy.DEFAULT_TOUR,0)).status,403);}
  h.state.user={email:'author@example.test'};assert.equal(await h.content.isAuthor(),true);assert.equal((await h.get(true)).status,200);assert.equal((await h.post(copy.DEFAULT_TOUR,0,'draft','https://other.test')).status,403);
 }finally{h.close();}
});
test('tutorial drafts remain private, publish is atomic, and stale saves cannot overwrite newer text',async()=>{
 const h=harness();try{
  h.state.user={email:'author@example.test'};const draft=structuredClone(copy.DEFAULT_TOUR);draft.welcome.title='新報到文案';draft.steps.character.body='新的角色介紹';
  assert.equal((await h.post(draft,0)).status,200);
  const author=await (await h.get(true)).json(),reader=await (await h.get(false)).json();
  assert.equal(author.value.welcome.title,'新報到文案');assert.equal(author.revision,1);assert.equal(author.hasDraft,true);assert.equal(reader.value.welcome.title,copy.DEFAULT_TOUR.welcome.title);
  assert.equal((await h.post(draft,0,'publish')).status,409);
  assert.equal((await h.post(draft,1,'publish')).status,200);
  assert.equal((await (await h.get(false)).json()).value.steps.character.body,'新的角色介紹');
  assert.equal((await (await h.get(true)).json()).hasDraft,false);
  assert.deepEqual(await h.content.documents(true),[]);assert.deepEqual(await h.content.documents(),[]);
  assert.equal(h.content.cleanDocument({id:'site-tour',kind:'chapter',title:'x',body:'x',volume:'vol-1',order:1,revision:0}),null);
 }finally{h.close();}
});
test('copy validation rejects invalid lengths and missing text, strips control fields, and supplies future step defaults',()=>{
 const draft=structuredClone(copy.DEFAULT_TOUR);draft.steps.character.route='/author';draft.steps.character.target='body';
 const cleaned=copy.cleanTourContent(draft);assert(!('route' in cleaned.steps.character));assert(!('target' in cleaned.steps.character));
 for(const patch of [{title:''},{body:' '},{body:'x'.repeat(1501)},{hint:null}]){const bad=structuredClone(draft);Object.assign(bad.welcome,patch);assert.equal(copy.cleanTourContent(bad),null);}
 delete draft.steps.character;assert.equal(copy.cleanTourContent(draft),null);assert.deepEqual(copy.tourContent(draft).steps.character,copy.DEFAULT_TOUR.steps.character);
});
