const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const {DatabaseSync}=require('node:sqlite');
function load(file,mocks={}){const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;const mod={exports:{}};new Function('require','module','exports',code)(id=>{if(Object.hasOwn(mocks,id))return mocks[id];if(id.startsWith('.'))return load(path.posix.join(path.posix.dirname(file),id+'.ts'));throw Error(id);},mod,mod.exports);return mod.exports;}
const links=load('lib/annotation-links.ts'),glossary=load('lib/glossary.ts'),rich=load('lib/rich-text.ts');
const volume={id:'vol-1',kind:'volume',title:'第一卷',volume:'vol-1',order:1,body:'',revision:0};
const term={id:'shared-pgy',term:'PGY',text:'公開解說',tags:['行政職級'],revision:0};
const note={id:1,term:'PGY',text:'舊章節快照',glossaryId:term.id};
const chapter=id=>({id,kind:'chapter',title:id,volume:'vol-1',order:1,body:'PGY[1]',notes:[note],revision:0});
function harness(){
 const sql=new DatabaseSync(':memory:');for(const f of ['0000_orange_gideon.sql','0002_dapper_paper_doll.sql'])sql.exec(fs.readFileSync(path.join(__dirname,'../drizzle',f),'utf8'));
 const state={user:{email:'author@example.test'},rank:3};
 const db={prepare(query){let params=[];return {bind(...p){params=p;return this;},async first(){return sql.prepare(query).get(...params)||null;},async all(){return {results:sql.prepare(query).all(...params)};},async run(){return {meta:{changes:Number(sql.prepare(query).run(...params).changes)}};}};}};
 const content=load('lib/content.ts',{'cloudflare:workers':{env:{DB:db,AUTHOR_EMAIL:'author@example.test'}},'@/app/chatgpt-auth':{getChatGPTUser:async()=>state.user},'@/data/seed.json':[volume],'@/data/chapter-updates.json':{id:'none',expectedBodies:[]},'@/data/personnel-import.json':{records:[]},'./reader-access':{readerIdentity:async()=>({rank:state.rank})}});
 const route=load('app/api/documents/route.ts',{'@/lib/content':content,'@/lib/rich-text':rich,'@/lib/annotation-links':links});
 const terms=load('app/api/glossary/route.ts',{'@/lib/content':content,'@/lib/glossary':glossary});
 const batch=load('app/api/glossary/batch/route.ts',{'@/lib/content':content,'@/lib/glossary':glossary});
 async function post(route,payload,origin='https://his.test'){const r=await route.POST(new Request('https://his.test/api/test',{method:'POST',headers:{origin},body:JSON.stringify(payload)}));return {status:r.status,data:await r.json()};}
 return {sql,state,content,save:(document,action='publish')=>post(route,{document,action}),term:(value,action='publish')=>post(terms,{term:value,action}),termGet:async(query)=>{const r=await terms.GET(new Request('https://his.test/api/glossary'+query));return {status:r.status,data:await r.json()};},batchPost:payload=>post(batch,payload),batchGet:async()=>await (await batch.GET()).json(),docs:async(author=false)=>await content.documents(author),close:()=>sql.close()};
}

test('shared edits remain drafts until published; every linked chapter updates by ID including a renamed term',async()=>{
 const h=harness();try{
  assert.equal((await h.term(term)).status,200);
  for(const id of ['chapter-a','chapter-b'])assert.equal((await h.save(chapter(id))).status,200);
  assert.equal((await h.term({...term,revision:1,term:'新的 PGY 名稱',text:'未公開的新解說',tags:['秘密標籤']},'draft')).status,200);
  const reader=(await h.docs()).filter(d=>d.kind==='chapter');assert(reader.every(d=>d.notes[0].text==='公開解說'));assert(reader.every(d=>!('glossaryRevision' in d.notes[0])));
  assert((await h.docs(true)).filter(d=>d.kind==='chapter').every(d=>d.notes[0].text==='未公開的新解說'));
  assert.equal((await h.term({...term,revision:2,term:'新的 PGY 名稱',text:'未公開的新解說',tags:['新標籤']})).status,200);
  assert((await h.docs()).filter(d=>d.kind==='chapter').every(d=>d.notes[0].text==='未公開的新解說'&&d.notes[0].term==='新的 PGY 名稱'));
 }finally{h.close();}
});

test('saving and publishing a chapter cannot leak shared drafts through its fallback snapshot',async()=>{
 const h=harness();try{
  await h.term(term);await h.save(chapter('chapter-a'));
  await h.term({...term,revision:1,text:'秘密草稿'},'draft');
  let draft=(await h.docs(true)).find(d=>d.id==='chapter-a');assert.equal(draft.notes[0].text,'秘密草稿');
  assert.equal((await h.save(draft,'draft')).status,200);
  assert.equal((await h.docs()).find(d=>d.id==='chapter-a').notes[0].text,'公開解說');
  draft=(await h.docs(true)).find(d=>d.id==='chapter-a');assert.equal((await h.save(draft)).status,200);
  const persisted=JSON.parse(h.sql.prepare('SELECT published FROM documents WHERE id=?').get('chapter-a').published);
  assert.equal(persisted.notes[0].text,'公開解說');assert(!('glossaryRevision' in persisted.notes[0]));
  await h.term({...term,revision:2,text:'秘密草稿'},'unpublish');
  assert.equal((await h.docs()).find(d=>d.id==='chapter-a').notes[0].text,'公開解說');
  h.sql.prepare('DELETE FROM glossary_terms WHERE id=?').run(term.id);
  assert.equal((await h.docs()).find(d=>d.id==='chapter-a').notes[0].text,'公開解說');
 }finally{h.close();}
});

test('detaching is local, is staged until chapter publication, and same-name legacy notes never link',async()=>{
 const h=harness();try{
  await h.term(term);await h.save(chapter('chapter-a'));await h.save(chapter('chapter-b'));
  await h.save({...chapter('chapter-old'),notes:[{id:1,term:'PGY',text:'舊有獨立吐槽'}]});
  let doc=(await h.docs(true)).find(d=>d.id==='chapter-a');doc.notes=[{id:1,term:'PGY',text:'本章限定吐槽'}];await h.save(doc,'draft');
  await h.term({...term,revision:1,text:'第二版公開解說'});
  assert.equal((await h.docs()).find(d=>d.id==='chapter-a').notes[0].text,'第二版公開解說');
  doc=(await h.docs(true)).find(d=>d.id==='chapter-a');await h.save(doc);
  await h.term({...term,revision:2,text:'第三版公開解說'});
  const docs=await h.docs();assert.equal(docs.find(d=>d.id==='chapter-a').notes[0].text,'本章限定吐槽');assert.equal(docs.find(d=>d.id==='chapter-b').notes[0].text,'第三版公開解說');assert.equal(docs.find(d=>d.id==='chapter-old').notes[0].text,'舊有獨立吐槽');
 }finally{h.close();}
});

test('unpublished or missing links cannot be published; independent snapshots can',async()=>{
 const h=harness();try{
  await h.term(term,'draft');assert.equal((await h.save(chapter('chapter-a'),'draft')).status,200);
  let doc=(await h.docs(true)).find(d=>d.id==='chapter-a');assert.equal((await h.save(doc)).status,400);
  assert.equal((await h.save({...chapter('missing'),notes:[{...note,glossaryId:'missing'}]})).status,400);
  delete doc.notes[0].glossaryId;assert.equal((await h.save(doc)).status,200);
  assert.equal((await h.docs()).find(d=>d.id==='chapter-a').notes[0].text,term.text);
 }finally{h.close();}
});

test('direct term lookup, author writes, invalid link IDs and stale revisions are protected',async()=>{
 const h=harness();try{
  await h.term(term);await h.term({...term,revision:1,text:'最新草稿'},'draft');
  assert.equal((await h.term({...term,revision:1,text:'過期覆寫'})).status,409);
  assert.equal((await h.termGet('?id='+term.id)).data.term.text,'公開解說');
  assert.equal((await h.termGet('?scope=author&id='+term.id)).data.term.text,'最新草稿');
  h.state.user=null;assert.equal((await h.termGet('?scope=author&id='+term.id)).status,403);assert.equal((await h.term(term)).status,403);assert.equal((await h.save(chapter('unauthorized'))).status,403);
  h.state.user={email:'author@example.test'};
  for(const id of [null,1,'',{},'../bad','x'.repeat(81)])assert.equal((await h.save({...chapter('invalid'),notes:[{...note,glossaryId:id}]})).status,400);
  const clean=h.content.cleanDocument({...chapter('valid'),notes:[{...note,glossaryRevision:999,glossaryHasDraft:true}]});assert.equal(clean.notes[0].glossaryId,term.id);assert(!('glossaryRevision' in clean.notes[0]));
 }finally{h.close();}
});

test('glossary batch publication updates linked chapters; restricted chapters do not expose notes',async()=>{
 const h=harness();try{
  await h.term(term);await h.save(chapter('normal'));await h.save({...chapter('bonus'),chapterType:'bonus'});
  await h.term({...term,revision:1,text:'批次公開解說'},'draft');
  const snapshot=await h.batchGet();assert.equal((await h.batchPost({action:'publish-all',snapshot})).status,200);
  assert((await h.docs()).filter(d=>d.kind==='chapter').every(d=>d.notes[0].text==='批次公開解說'));
  h.state.rank=0;assert.deepEqual((await h.docs()).find(d=>d.id==='bonus').notes,[]);
 }finally{h.close();}
});

test('annotation reordering preserves explicit shared IDs and independent chapter jokes',()=>{
 const {reorderAnnotations}=load('lib/annotation-order.ts');
 const result=reorderAnnotations({type:'doc',content:[{type:'annotation',attrs:{id:9}},{type:'annotation',attrs:{id:1}}]},[note,{id:9,term:'PGY',text:'獨立吐槽'}]);
 assert.deepEqual(result.notes.map(n=>[n.id,n.glossaryId,n.text]),[[1,undefined,'獨立吐槽'],[2,term.id,'舊章節快照']]);
});
