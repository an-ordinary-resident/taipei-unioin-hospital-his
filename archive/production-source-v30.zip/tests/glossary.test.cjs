const {test}=require('node:test');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const {DatabaseSync}=require('node:sqlite');
function load(file,mocks={}){const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const mod={exports:{}};new Function('require','module','exports',code)(id=>{if(Object.hasOwn(mocks,id))return mocks[id];throw Error(id);},mod,mod.exports);return mod.exports;}
function harness(){
 const sqlite=new DatabaseSync(':memory:');sqlite.exec(fs.readFileSync(path.join(__dirname,'../drizzle/0002_dapper_paper_doll.sql'),'utf8'));
 const state={author:true};
 const db={prepare(sql){let params=[];return {bind(...v){params=v;return this;},async first(){return sqlite.prepare(sql).get(...params)||null;},async all(){return {results:sqlite.prepare(sql).all(...params)};},async run(){return {meta:{changes:Number(sqlite.prepare(sql).run(...params).changes)}};}};}};
 const route=load('app/api/glossary/route.ts',{'@/lib/glossary':load('lib/glossary.ts'),'@/lib/content':{database:()=>db,isAuthor:async()=>state.author,mutationGuard:async req=>state.author&&req.headers.get('origin')==='https://his.test'?null:Response.json({error:'denied'},{status:403})}});
 async function get(query=''){const r=await route.GET(new Request('https://his.test/api/glossary'+query));return {status:r.status,data:await r.json()};}
 async function post(term,action='draft',origin='https://his.test'){const r=await route.POST(new Request('https://his.test/api/glossary',{method:'POST',headers:{origin},body:JSON.stringify({term,action})}));return {status:r.status,data:await r.json()};}
 return {state,get,post,close:()=>sqlite.close()};
}
const term={id:'term-one',term:'PGY',text:'- 一般醫學訓練\n- 畢業後訓練',revision:0};

test('term tags normalize, filter with search and expose only published facets',async()=>{
 const h=harness();try{
  const first=await h.post({...term,tags:[' 行政職級 ','行政職級','自訂吐槽']},'publish');
  assert.deepEqual(first.data.term.tags,['行政職級','自訂吐槽']);
  assert.equal((await h.get('?tag='+encodeURIComponent('行政職級')+'&q=PGY')).data.total,1);
  assert.equal((await h.get('?q='+encodeURIComponent('自訂吐槽'))).data.total,1);
  assert.equal((await h.get('?tag='+encodeURIComponent('疾病症狀'))).data.total,0);
  await h.post({...term,revision:1,tags:['秘密草稿標籤']});
  const visible=(await h.get()).data,author=(await h.get('?scope=author')).data;
  assert.deepEqual(visible.terms[0].tags,['行政職級','自訂吐槽']);
  assert(!visible.tags.includes('秘密草稿標籤'));
  assert(author.tags.includes('秘密草稿標籤'));
  assert.equal((await h.get('?q='+encodeURIComponent('秘密草稿標籤'))).data.total,0);
  assert.equal((await h.get('?tag='+encodeURIComponent('秘密草稿標籤'))).data.total,0);
  await h.post({...term,revision:2,tags:['秘密草稿標籤']},'publish');
  assert.deepEqual((await h.get()).data.tags,['秘密草稿標籤']);
  await h.post({...term,revision:3,tags:['秘密草稿標籤']},'unpublish');
  assert.deepEqual((await h.get()).data.tags,[]);
 }finally{h.close();}
});

test('legacy terms have empty tags and invalid tags cannot be stored',async()=>{
 const h=harness();try{
  assert.deepEqual((await h.post(term,'publish')).data.term.tags,[]);
  for(const tags of [null,'行政職級',[3],[''],[' '.repeat(5)],['字'.repeat(41)],Array(21).fill('分類')]){
   assert.equal((await h.post({...term,id:'invalid',tags})).status,400);
  }
  assert.equal((await h.get('?q=%25')).data.total,0);
 }finally{h.close();}
});
test('glossary drafts, publication and unpublication stay isolated from public search',async()=>{
 const h=harness();try{
  assert.equal((await h.post(term)).status,200);
  assert.equal((await h.get()).data.total,0);
  assert.equal((await h.get('?scope=author')).data.total,1);
  assert.equal((await h.post({...term,revision:1},'publish')).status,200);
  assert.equal((await h.get('?q=pgy')).data.terms[0].text,term.text);
  assert.equal((await h.post({...term,revision:2,text:'尚未刊載的新解說'})).status,200);
  assert.equal((await h.get()).data.terms[0].text,term.text);
  assert.equal((await h.get('?q=尚未刊載')).data.total,0);
  assert.equal((await h.get('?scope=author')).data.terms[0].text,'尚未刊載的新解說');
  assert.equal((await h.post({...term,revision:3},'unpublish')).status,200);
  assert.equal((await h.get()).data.total,0);
 }finally{h.close();}
});
test('glossary rejects unauthorized writes, stale edits and normalized duplicates',async()=>{
 const h=harness();try{
  h.state.author=false;assert.equal((await h.post(term)).status,403);assert.equal((await h.get('?scope=author')).status,403);
  h.state.author=true;assert.equal((await h.post(term,'draft','https://other.test')).status,403);
  assert.equal((await h.post(term,'publish')).status,200);
  assert.equal((await h.post({...term,id:'duplicate',term:' ｐｇｙ '})).status,409);
  assert.equal((await h.post({...term,text:'過期修改'})).status,409);
  assert.equal((await h.post({...term,id:'empty',term:' '})).status,400);
  assert.equal((await h.get('?offset=-1')).status,400);
  assert.equal((await h.get('?q=%25')).data.total,0);
 }finally{h.close();}
});
test('glossary search paginates without dropping terms or exposing draft text',async()=>{
 const h=harness();try{
  for(let i=0;i<32;i++)assert.equal((await h.post({...term,id:'term-'+i,term:'名詞 '+String(i).padStart(2,'0')},'publish')).status,200);
  const first=(await h.get()).data,second=(await h.get('?offset='+first.nextOffset)).data;
  assert.equal(first.terms.length,30);assert.equal(second.terms.length,2);assert.equal(second.nextOffset,null);
  assert.equal(new Set([...first.terms,...second.terms].map(t=>t.id)).size,32);
 }finally{h.close();}
});
