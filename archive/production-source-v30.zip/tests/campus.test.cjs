const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'../lib/campus.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText;
const m={exports:{}};new Function('module','exports',code)(m,m.exports);
const {campusFloors,wardSpaces,parseCampusLocation,campusHref}=m.exports;
test('source plan preserves all floors, room numbers and 32 beds without filling skipped numbers',()=>{
 assert.equal(campusFloors.length,17);assert.equal(new Set(campusFloors.map(f=>f.id)).size,17);
 assert.deepEqual(campusFloors.map(f=>f.id),['RF','13F','12F','11F','10F','9F','8F','7F','6F','5F','4F','3F','2F','1F','B1F','B2F','B3F']);
 const rooms=wardSpaces.filter(s=>s.beds);assert.equal(rooms.length,13);assert.equal(rooms.reduce((n,s)=>n+s.beds,0),32);
 assert.deepEqual(rooms.map(s=>s.id),['01','02','03','05','06','07','08','09','10','11','12','15','16'].map(n=>'10A-'+n));
 assert.equal(new Set(wardSpaces.map(s=>s.id)).size,wardSpaces.length);
 assert.equal(campusFloors.find(f=>f.id==='12F').beds.reduce((a,b)=>a+b),76);
});
test('deep links preserve ward and room; invalid and contradictory URLs cannot open nonexistent rooms',()=>{
 const location={building:'inpatient',floor:'10F',ward:true,space:'10A-16'};
 assert.deepEqual(parseCampusLocation(campusHref(location).split('?')[1]),location);
 assert.equal(parseCampusLocation('building=inpatient&floor=B3F&ward=10A').floor,'10F');
 assert.equal(parseCampusLocation('building=outpatient&ward=10A&space=10A-16').space,null);
 assert.equal(parseCampusLocation('building=inpatient&ward=10A&space=10A-04').space,null);
 assert.equal(parseCampusLocation('building=inpatient&floor=99F').floor,'10F');
 assert.equal(campusHref({building:'campus',floor:'10F',ward:false,space:null}),'/campus');
});
