const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const React=require('react'),{renderToStaticMarkup}=require('react-dom/server');
function load(file){
 const mod={exports:{}};
 const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}}).outputText;
 new Function('require','module','exports',code)(id=>{
  if(id==='./tour-events')return {useTourDismiss:()=>{}};
  if(id.includes('ui/popover')||id==='./term-tags')return {};
  if(id.includes('protected-content'))return {default:({children})=>children};
  if(id.startsWith('@/'))return load(id.slice(2)+'.ts');
  if(id.startsWith('.'))return load(path.posix.join(path.posix.dirname(file),id+'.ts'));
  return require(id);
 },mod,mod.exports);return mod.exports;
}
const Prose=load('components/prose.tsx').default;
const {proseHeadings,proseBlocks}=load('lib/prose-format.ts');
const {editorDocument,storedProse}=load('lib/editor-document.ts');
const {cleanReadingPoint}=load('lib/reading-history.ts');
const {passagePosition}=load('lib/reading-position.ts');
test('chapter Enter pauses survive editor round-trip and render, without changing section links or tracking blanks',()=>{
 const body='\n第一句。\n\n\n**第二句。**\n\n# 分段\n- 第一點\n\n- 第二點\n\n尾聲。\n';
 assert.equal(storedProse(editorDocument(body)),body);
 const html=renderToStaticMarkup(React.createElement(Prose,{text:body,trackPassages:true,headingPrefix:'chapter'}));
 assert.equal((html.match(/class="prose-blank-line"/g)||[]).length,7);
 assert.match(html,/<strong>第二句。<\/strong>/);
 for(const heading of proseHeadings(body,'chapter'))assert(html.includes('id="'+heading.id+'"'));
 const keys=[...html.matchAll(/data-reader-block="([^"]+)"/g)].map(m=>m[1]);
 assert.equal(keys.length,proseBlocks(body,true).filter(b=>b.kind!=='paragraph'||b.lines[0].trim()).length);
 for(const block of keys)assert(cleanReadingPoint({chapterId:'c',block,offset:0,percent:0,updatedAt:1},{id:'c',body},2));
 const normal=renderToStaticMarkup(React.createElement(Prose,{text:body}));
 assert(!normal.includes('prose-blank-line'),'other Prose consumers retain their existing layout');
 const preview=renderToStaticMarkup(React.createElement(Prose,{text:body,preserveBlank:true}));
 assert.equal((preview.match(/class="prose-blank-line"/g)||[]).length,7);
 assert(!preview.includes('data-reader-block'));
});
test('progress stays constant through blank space and reaches 100 when the final content is visible',()=>{
 const blocks=[{top:0,bottom:100,height:100},{top:1000,bottom:1100,height:100},{top:2000,bottom:2100,height:100}];
 assert.equal(passagePosition(blocks,-100,0).percent,0);
 assert.equal(passagePosition(blocks,200,500).percent,1/3*100);
 assert.equal(passagePosition(blocks,800,1100).percent,1/3*100);
 assert.equal(passagePosition(blocks,1050,1350).percent,50);
 assert.equal(passagePosition(blocks,1800,2100).percent,100);
 assert.equal(passagePosition([],100,400).percent,0);
 assert.equal(passagePosition([{top:0,bottom:100,height:100}],0,400).percent,100);
});
