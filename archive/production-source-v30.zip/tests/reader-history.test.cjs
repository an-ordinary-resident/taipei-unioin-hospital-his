const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript');
const {DatabaseSync}=require('node:sqlite');
function load(file,mocks={}){const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const mod={exports:{}};new Function('require','module','exports',code)(id=>{if(Object.hasOwn(mocks,id))return mocks[id];if(id.startsWith('.'))return load(path.posix.join(path.posix.dirname(file),id+'.ts'));throw Error(id);},mod,mod.exports);return mod.exports;}
const policy=load('lib/reading-history.ts'),prose=load('lib/prose-format.ts');
const volume={id:'v1',kind:'volume',volume:'v1',order:1,title:'第一卷'};
const chapter={id:'chapter-one',kind:'chapter',volume:'v1',chapterType:'main',order:1,body:'開場\n# 第一段\n正文\n- 說明一\n- 說明二'};
function point(id=chapter.id){return {chapterId:id,block:policy.passageKeys(prose.proseBlocks(chapter.body))[2],offset:.35,percent:48,updatedAt:Date.now()-100};}
function harness(){
 const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync(path.join(__dirname,'../drizzle/0003_illegal_runaways.sql'),'utf8'));
 const state={jar:new Map(),locked:false};
 const db={prepare(query){let params=[];return {bind(...v){params=v;return this;},async first(){return sql.prepare(query).get(...params)||null;},async all(){return {results:sql.prepare(query).all(...params)};},async run(){return {meta:{changes:Number(sql.prepare(query).run(...params).changes)}};}};}};
 const route=load('app/api/reader-state/route.ts',{'next/headers':{cookies:async()=>({get:name=>state.jar.has(name)?{value:state.jar.get(name)}:undefined})},'@/lib/content':{database:()=>db,documents:async()=>[volume,{...chapter,locked:state.locked},{...chapter,id:'chapter-two',order:2}]},'@/lib/reading-history':policy});
 async function unpack(response){const cookie=response.headers.get('set-cookie');if(cookie)state.jar.set('his-reader-device',cookie.split(';')[0].split('=')[1]);return {status:response.status,data:await response.json(),cookie};}
 const get=async()=>unpack(await route.GET(new Request('https://his.test/api/reader-state')));
 const post=async(patch,origin='https://his.test')=>unpack(await route.POST(new Request('https://his.test/api/reader-state',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify({chapterId:chapter.id,...patch})})));
 return {state,get,post,close:()=>sql.close()};
}
test('views and likes are idempotent per cookie, including concurrent requests',async()=>{
 const h=harness();try{
  assert.equal((await h.post({action:'view'})).status,409);
  const initial=await h.get();assert.match(initial.cookie,/HttpOnly/);assert.match(initial.cookie,/Secure/);assert.match(initial.cookie,/SameSite=Lax/);
  const results=await Promise.all(Array.from({length:8},()=>h.post({action:'view'})));
  for(const r of results)assert.equal(r.data.stats.views,1);
  for(let i=0;i<3;i++)assert.deepEqual((await h.post({action:'like',liked:true})).data.stats,{views:1,likes:1,liked:true});
  assert.deepEqual((await h.post({action:'like',liked:false})).data.stats,{views:1,likes:0,liked:false});
  const token=h.state.jar.get('his-reader-device');h.state.jar.clear();await h.get();
  assert.deepEqual((await h.post({action:'view'})).data.stats,{views:2,likes:0,liked:false});
  h.state.jar.set('his-reader-device',token);assert.equal((await h.post({action:'view'})).data.stats.views,2);
 }finally{h.close();}
});
test('bookmarks persist independently of last read and isolate browsers; stale progress cannot overwrite newer reading',async()=>{
 const h=harness();try{
  await h.get();const token=h.state.jar.get('his-reader-device'),p=point();
  assert.equal((await h.post({action:'bookmark',point:p})).status,200);
  const last={...p,chapterId:'chapter-two',updatedAt:p.updatedAt+20};
  await h.post({action:'progress',chapterId:'chapter-two',point:last});
  await h.post({action:'progress',point:{...p,updatedAt:p.updatedAt-500}});
  const data=(await h.get()).data;
  assert.deepEqual(data.bookmark,p);assert.deepEqual(data.lastRead,last);assert(!JSON.stringify(data).includes(token));assert(!JSON.stringify(data).includes('device_key'));
  h.state.jar.clear();await h.get();assert.deepEqual((await h.get()).data,{lastRead:null,bookmark:null});
  h.state.jar.set('his-reader-device',token);await h.post({action:'clear-bookmark'});assert.equal((await h.get()).data.bookmark,null);assert.deepEqual((await h.get()).data.lastRead,last);
 }finally{h.close();}
});
test('reader writes enforce chapter access, same origin and valid paragraph coordinates',async()=>{
 const h=harness();try{
  await h.get();assert.equal((await h.post({action:'view'},'https://evil.test')).status,403);
  assert.equal((await h.post({action:'like',liked:'true'})).status,400);
  for(const patch of [{block:'b-nonexistent-1'},{offset:1.5},{percent:-1},{updatedAt:null}])assert.equal((await h.post({action:'bookmark',point:{...point(),...patch}})).status,400);
  assert.equal((await h.post({action:'bookmark',point:point()})).status,200);
  h.state.locked=true;assert.equal((await h.post({action:'view'})).status,403);assert.equal((await h.post({action:'like',liked:true})).status,403);assert.equal((await h.post({action:'progress',point:point()})).status,403);assert.equal((await h.get()).data.bookmark,null);
  assert.equal((await h.post({action:'view',chapterId:'missing'})).status,403);
 }finally{h.close();}
});
test('resume priority is bookmark, last read, then the first formal chapter of volume one',()=>{
 const all=[{...chapter,id:'appendix',chapterType:'appendix',order:0},{...chapter,id:'second',volume:'v2'},{...volume,id:'v2',order:2},chapter,volume,{...chapter,id:'bonus',locked:true}];
 assert.equal(policy.resumeRecord(all,{bookmark:point('second'),lastRead:point()}).chapter.id,'second');
 assert.equal(policy.resumeRecord(all,{bookmark:point('bonus'),lastRead:point()}).chapter.id,chapter.id);
 assert.equal(policy.resumeRecord(all,{bookmark:point('deleted'),lastRead:null}).chapter.id,chapter.id);
 assert.equal(policy.resumeRecord(all,{bookmark:null,lastRead:null}).source,'first');
});
test('paragraph IDs survive inserted paragraphs and styling edits',()=>{
 const source=prose.proseBlocks('前文\n重要段落\n後文');
 const updated=prose.proseBlocks('新增段落\n前文\n**重要段落**\n後文');
 assert.equal(policy.passageKeys(source)[1],policy.passageKeys(updated)[2]);
 const repeated=policy.passageKeys(prose.proseBlocks('重複\n重複'));assert.notEqual(repeated[0],repeated[1]);
});
