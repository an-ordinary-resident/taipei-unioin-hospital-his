'use client';
import { useEffect,useRef,useState,useMemo } from 'react';
import TourPreview from './tour-preview';
import { useTourContent } from './site-presentation';
import { TOUR_DISMISS,TOUR_MODE } from './tour-events';
import { createPortal } from 'react-dom';
import { ArrowRight,ArrowLeft,Stethoscope,GraduationCap,Check,Pause,X } from 'lucide-react';
import { useSidebar } from './ui/sidebar';
import { readerHistory } from '@/lib/reader-client';
import { TOUR_COOKIE,TOUR_RUN,TOUR_RETURN,tourSteps,tourStations,parseTourCookie,safeTourPath,type TourStatus } from '@/lib/reader-tour';

type Origin={url:string;y:number;block?:string;offset?:number};
type Run={step:number;mode:'teach'|'practice';origin:Origin;readPath:string|null;characterPath:string|null;resumePath:string;updated:number};
type View='closed'|'welcome'|'teach'|'practice'|'complete';
const SNOOZE='his-onboarding-snoozed';
function snoozed(){try{return sessionStorage.getItem(SNOOZE)==='1';}catch{return false;}}
function cookieStatus(){try{return parseTourCookie(document.cookie.split('; ').find(v=>v.startsWith(TOUR_COOKIE+'='))?.split('=')[1]||'');}catch{return null;}}
function remember(status:TourStatus['status'],step:number){document.cookie=TOUR_COOKIE+'=1.'+status+'.'+Math.min(step,tourSteps.length-1)+'; Path=/; SameSite=Lax; Max-Age=31536000'+(location.protocol==='https:'?'; Secure':'');}
function readRun():Run|null{try{const r=JSON.parse(sessionStorage.getItem(TOUR_RUN)||'null');return r&&Number.isInteger(r.step)&&r.step>=0&&r.step<=tourSteps.length&&['teach','practice'].includes(r.mode)&&safeTourPath(r.origin?.url)&&Number.isFinite(r.origin.y)&&Date.now()-r.updated<30*60*1000?{...r,readPath:safeTourPath(r.readPath),characterPath:safeTourPath(r.characterPath),resumePath:safeTourPath(r.resumePath)||'/dashboard'}:null;}catch{return null;}}
function captureOrigin():Origin{
 const line=(document.querySelector('.topbar')?.getBoundingClientRect().bottom||0)+24;
 const blocks=Array.from(document.querySelectorAll<HTMLElement>('[data-reader-block]'));
 const block=blocks.filter(n=>n.getBoundingClientRect().top<=line).at(-1);
 return {url:safeTourPath(location.pathname+location.search+location.hash)||'/dashboard',y:scrollY,block:block?.dataset.readerBlock,offset:block?line-block.getBoundingClientRect().top:0};
}
export default function ReaderTour(){
 const [view,setView]=useState<View>('closed'),[run,setRun]=useState<Run|null>(null),[status,setStatus]=useState<TourStatus|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const card=useRef<HTMLDivElement>(null),origin=useRef<Origin|null>(null),previousFocus=useRef<HTMLElement|null>(null),requestId=useRef(0),transition=useRef<ReturnType<typeof setTimeout>|undefined>(undefined),practiceTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined),layer=useRef<HTMLDivElement>(null);
 const {isMobile,setOpenMobile,setOpen}=useSidebar();
 const content=useTourContent();
 const definition=run&&run.step<tourSteps.length?tourSteps[run.step]:null;
 const step=useMemo(()=>definition?{...definition,...content.steps[definition.id]}:null,[definition,content]);
 function persist(next:Run){sessionStorage.setItem(TOUR_RUN,JSON.stringify({...next,updated:Date.now()}));remember('active',next.step);setRun(next);}
 function routeFor(next:Run){const s=tourSteps[next.step];return s?.route==='character'?next.characterPath||'/characters':s?.route==='read'?next.readPath||'/volumes':s?'/'+s.route:'/glossary';}
 function move(next:Run){
  setError('');clearTimeout(practiceTimer.current);
  try{persist(next);}catch{setError('瀏覽器未允許暫存教學進度，請允許網站儲存資料後再試。');return;}
  const path=routeFor(next);
  if(location.pathname!==path){setBusy(true);location.assign(path+'?his-tour=1');return;}
  // Close every controlled feature panel before restoring the tutorial focus trap.
  setView('closed');setOpenMobile(false);
  window.dispatchEvent(new Event(TOUR_DISMISS));
  window.dispatchEvent(new CustomEvent(TOUR_MODE,{detail:next.mode}));
  clearTimeout(transition.current);
  transition.current=setTimeout(()=>setView(next.step===tourSteps.length?'complete':next.mode),220);
 }
 useEffect(()=>{
  let disposed=false;
  // Restore the exact page/paragraph that was visible before the tour.
  try{const raw=sessionStorage.getItem(TOUR_RETURN);if(raw){sessionStorage.removeItem(TOUR_RETURN);const saved=JSON.parse(raw) as Origin;if(safeTourPath(saved.url)?.split(/[?#]/)[0]===location.pathname){
   void Promise.race([Promise.allSettled([document.fonts.ready,...Array.from(document.querySelectorAll<HTMLImageElement>('.reader-paper img')).map(i=>i.decode())]),new Promise(resolve=>setTimeout(resolve,2000))]).then(()=>requestAnimationFrame(()=>{if(disposed)return;const node=Array.from(document.querySelectorAll<HTMLElement>('[data-reader-block]')).find(n=>n.dataset.readerBlock===saved.block);const top=node?scrollY+node.getBoundingClientRect().top+(saved.offset||0)-(document.querySelector('.topbar')?.getBoundingClientRect().bottom||0)-24:saved.y;window.scrollTo({top:Math.max(0,top),behavior:'instant'});}));
  }}}catch{}
  const saved=cookieStatus();setStatus(saved);
  const active=readRun();
  if(active){setRun(active);origin.current=active.origin;setView(active.step===tourSteps.length?'complete':active.mode);}
  else {try{sessionStorage.removeItem(TOUR_RUN);}catch{}if(!saved||(saved.status==='active'&&!snoozed())){origin.current=captureOrigin();setView('welcome');}}
  const reopen=()=>{previousFocus.current=document.activeElement as HTMLElement;origin.current=captureOrigin();setStatus(cookieStatus());setError('');setBusy(false);setOpenMobile(false);setView('welcome');};
  window.addEventListener('his-start-tour',reopen);
  return()=>{disposed=true;requestId.current++;clearTimeout(transition.current);clearTimeout(practiceTimer.current);window.removeEventListener('his-start-tour',reopen);};
 },[setOpenMobile]);
 async function begin(resume=false){
  const request=++requestId.current;setBusy(true);setError('');
  try{
   const response=await fetch('/api/reader-tour',{cache:'no-store',signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error('教學資料暫時無法載入，請再試一次。');
   const meta=await response.json() as {readPath?:string|null;characterPath?:string|null};
   let resumePath='/dashboard';
   try{const h=await Promise.race([readerHistory(),new Promise<never>((_,reject)=>setTimeout(()=>reject(Error('timeout')),2000))]);const point=h.bookmark||h.lastRead;if(point)resumePath='/read/'+point.chapterId+'?resume='+(h.bookmark?'bookmark':'last');}catch{}
   const readPath=safeTourPath(meta.readPath);
   const next:Run={step:resume?status?.step||0:0,mode:'teach',origin:origin.current||captureOrigin(),readPath,characterPath:safeTourPath(meta.characterPath),resumePath:resumePath==='/dashboard'?readPath||resumePath:resumePath,updated:Date.now()};
   if(request===requestId.current){try{sessionStorage.removeItem(SNOOZE);}catch{}move(next);}
  }catch{if(request===requestId.current)setError('教學資料暫時無法載入，請重試或先略過教學。');}
  finally{if(request===requestId.current)setBusy(false);}
 }
 function exit(kind:'done'|'skipped'|'pause',destination:'origin'|'read'='origin'){
  requestId.current++;const saved=run?.origin||origin.current||captureOrigin();
  remember(kind==='pause'?'active':kind,run?.step||0);
  try{sessionStorage.removeItem(TOUR_RUN);if(kind==='pause')sessionStorage.setItem(SNOOZE,'1');else sessionStorage.removeItem(SNOOZE);}catch{}
  const url=destination==='read'?(run?.resumePath||'/dashboard'):saved.url;
  if(destination==='origin')try{sessionStorage.setItem(TOUR_RETURN,JSON.stringify(saved));}catch{}
  clearTimeout(transition.current);clearTimeout(practiceTimer.current);window.dispatchEvent(new Event(TOUR_DISMISS));window.dispatchEvent(new CustomEvent(TOUR_MODE,{detail:'closed'}));
  setView('closed');setOpenMobile(false);
  // Reload also removes the preview marker and re-enables normal reading tracking.
  if(run||location.search.includes('his-tour')){const destinationUrl=new URL(safeTourPath(url)||'/dashboard',location.origin);if(destination==='origin')destinationUrl.searchParams.delete('resume');location.assign(destinationUrl.pathname+destinationUrl.search+destinationUrl.hash);}
  else {try{sessionStorage.removeItem(TOUR_RETURN);}catch{}previousFocus.current?.focus();}
 }
 function advance(delta:number){if(run)move({...run,step:Math.max(0,Math.min(tourSteps.length,run.step+delta)),mode:'teach'});}
 function practice(){
  if(!run||!step)return;const next={...run,mode:'practice' as const};
  try{persist(next);}catch{setError('無法暫存進度，請檢查瀏覽器儲存設定。');return;}
  setView('practice');window.dispatchEvent(new CustomEvent(TOUR_MODE,{detail:'practice'}));
  practiceTimer.current=setTimeout(()=>{
   const target=document.querySelector<HTMLElement>(step.target);if(target&&step.station!==0)target.scrollIntoView({block:'center',behavior:'instant'});
   const action=step.action;if(action==='sidebar'){if(isMobile)setOpenMobile(true);else setOpen(true);}
   else if(action==='character')document.querySelector('.character-detail')?.scrollIntoView({block:'start',behavior:'smooth'});
   else if(action==='scroll')window.scrollBy({top:window.innerHeight*.75,behavior:'smooth'});
   else if(action&&['settings','info','bookmark','sections','comments','chapters'].includes(action))window.dispatchEvent(new CustomEvent('his-tour-tool',{detail:action}));
   else if(action){const target=document.querySelector<HTMLElement>(action);if(target instanceof HTMLInputElement)target.focus();else target?.click();}
  },80);
 }
 useEffect(()=>{document.body.toggleAttribute('data-his-tour-practice',view==='practice');return()=>{document.body.removeAttribute('data-his-tour-practice');};},[view]);
 useEffect(()=>{
  if(!['welcome','teach','complete'].includes(view))return;
  const node=layer.current;if(!node)return;
  const oldOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
  const root=document.querySelector<HTMLElement>('[data-slot=sidebar-wrapper]');const wasInert=root?.inert;if(root)root.inert=true;
  card.current?.focus({preventScroll:true});
  if(card.current)card.current.scrollTop=0;
  const trap=(e:KeyboardEvent)=>{
   if(e.key==='Escape'){e.preventDefault();exit('pause');return;}
   if(e.key==='Tab'){const controls=Array.from(node.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input:not(:disabled),[tabindex="0"]')).filter(n=>n.tabIndex>=0&&n.getClientRects().length);const first=controls[0],last=controls.at(-1);if(e.shiftKey&&(document.activeElement===first||document.activeElement===card.current)){e.preventDefault();last?.focus();}else if(!e.shiftKey&&(document.activeElement===last||document.activeElement===card.current)){e.preventDefault();first?.focus();}}
  };
  node.addEventListener('keydown',trap);
  return()=>{document.body.style.overflow=oldOverflow;if(root)root.inert=wasInert||false;node.removeEventListener('keydown',trap);};
 },[view,run?.step]);
 if(view==='closed')return null;
 if(view==='practice')return createPortal(<aside className="tour-practice" aria-label="教學暫停，正在試用"><GraduationCap size={19}/><span>自由試用中<small>繼續或下一步會自動關閉視窗。</small></span><button type="button" onClick={()=>run&&move({...run,mode:'teach'})}>繼續教學</button><button type="button" onClick={()=>advance(1)}>下一步<ArrowRight size={15}/></button><button type="button" aria-label="暫停並返回原頁面" onClick={()=>exit('pause')}><X size={17}/></button></aside>,document.body);
 const isWelcome=view==='welcome',complete=view==='complete',station=complete?5:step?.station||0;
 return createPortal(<div ref={layer} className="tour-layer" role="dialog" aria-modal="true" aria-labelledby="tour-title" aria-describedby="tour-description">
  <div className="tour-shade"/>
  <div className={view==='teach'?'tour-frame':'tour-centered-frame'}>
  {view==='teach'&&step&&<TourPreview step={step}/>}
  <div ref={card} tabIndex={-1} className={'tour-card '+(view==='teach'?'tour-card-step':'tour-card-center')}>
   <div className="tour-brand"><span><Stethoscope size={19}/></span><div>慈愛院區・新進人員報到<small>帶路醫師 · 一個平凡的住院醫師</small></div><button type="button" aria-label="稍後繼續教學並返回原頁面" onClick={()=>exit('pause')}><X size={17}/></button></div>
   {!isWelcome&&<><div className="tour-stations" aria-label={'第 '+(station+1)+' 站，共 6 站'}>{tourStations.map((s,i)=><span key={s} title={s} className={i<=station?'is-reached':''}/>)}</div><div className="tour-step-label">{complete?'06 / 完成報到':String(station+1).padStart(2,'0')+' / '+tourStations[station]}{!complete&&<span>{(run?.step||0)+1} / {tourSteps.length}</span>}</div></>}
   <div className="tour-copy" key={run?.step} tabIndex={view==='teach'?0:undefined} role="region" aria-label="教學說明，可上下捲動"><h2 id="tour-title">{isWelcome?content.welcome.title:complete?content.complete.title:step?.title}</h2>
   <p id="tour-description">{isWelcome?content.welcome.body:complete?content.complete.body:step?.body}</p>
   {isWelcome?<div className="tour-overview">{['側欄動線','值班主控台','病程閱讀工具','人員檔案','註釋辭典庫'].map(s=><span key={s}><Check size={13}/>{s}</span>)}</div>:step?.hint&&!complete?<p className="tour-hint">{step.hint}</p>:null}
   {view==='teach'&&step?.route==='read'&&!run?.readPath&&<p className="tour-hint">目前沒有可閱讀的章節，先認識操作方式；刊載後即可使用。</p>}
   {complete&&content.complete.hint&&<p className="tour-hint">{content.complete.hint}</p>}
   {error&&<p role="alert" className="tour-error">{error}</p>}
   </div><div className="tour-controls">
   {isWelcome?<div className="tour-welcome-actions"><button className="primary-btn" type="button" disabled={busy} onClick={()=>void begin(status?.status==='active')}>{busy?'正在準備…':status?.status==='active'?'接續報到教學':'開始報到教學'}<ArrowRight size={16}/></button>{status?.status==='active'&&<button className="secondary-btn" disabled={busy} type="button" onClick={()=>void begin(false)}>重新從第一站開始</button>}<button type="button" className="tour-text-button" onClick={()=>exit('skipped')}>我已熟悉，直接進入</button><small>{content.welcome.hint}</small></div>:complete?<div className="tour-welcome-actions"><button className="primary-btn" type="button" onClick={()=>exit('done','read')}>{run?.resumePath.includes('resume=')?'繼續閱讀':'開始閱讀'}<ArrowRight size={16}/></button><button type="button" className="secondary-btn" onClick={()=>exit('done')}>返回原本頁面</button></div>:<>
   {step?.action&&<button type="button" className="secondary-btn tour-try" disabled={busy||(step.route==='read'&&!run?.readPath)||(step.action.startsWith('.')&&!document.querySelector('[data-slot=sidebar-wrapper] '+step.action))} onClick={practice}>{step.actionLabel}<ArrowRight size={15}/></button>}
   <div className="tour-navigation"><button type="button" className="secondary-btn" disabled={!run?.step||busy} onClick={()=>advance(-1)}><ArrowLeft size={15}/>上一步</button><button type="button" className="primary-btn" disabled={busy} onClick={()=>advance(1)}>{run?.step===tourSteps.length-1?'完成報到':'下一步'}<ArrowRight size={15}/></button></div>
   <div className="tour-exit-actions"><button type="button" onClick={()=>exit('pause')}><Pause size={12}/>稍後繼續</button><button type="button" onClick={()=>exit('skipped')}>略過教學</button></div>
  </>}
 </div></div></div>
</div>,document.body);
}

