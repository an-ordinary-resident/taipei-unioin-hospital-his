"use client";
import {createContext,useContext,useEffect,useState} from 'react';
export type Preferences={size:'small'|'medium'|'large';font:'serif'|'sans'|'kai';theme:'light'|'dark'};
const defaults:Preferences={size:'medium',font:'serif',theme:'light'};
const Context=createContext({preferences:defaults,setPreferences:(_p:Partial<Preferences>)=>{}});
function checked(value:unknown):Preferences{const p=(value&&typeof value==='object'?value:{}) as Partial<Preferences>;return{size:['small','medium','large'].includes(p.size||'')?p.size!:defaults.size,font:['serif','sans','kai'].includes(p.font||'')?p.font!:defaults.font,theme:p.theme==='dark'?'dark':'light'}}
function apply(p:Preferences){document.documentElement.dataset.readingSize=p.size;document.documentElement.dataset.readingFont=p.font;document.documentElement.classList.toggle('dark',p.theme==='dark')}
export function ReadingPreferences({children}:{children:React.ReactNode}){const [preferences,set]=useState(defaults);useEffect(()=>{try{const p=checked(JSON.parse(localStorage.getItem('ciai-reading-v1')||'{}'));set(p);apply(p)}catch{apply(defaults)}},[]);function setPreferences(value:Partial<Preferences>){set(previous=>{const next=checked({...previous,...value});apply(next);try{localStorage.setItem('ciai-reading-v1',JSON.stringify(next))}catch{}return next})}return <Context.Provider value={{preferences,setPreferences}}>{children}</Context.Provider>}
export function useReadingPreferences(){return useContext(Context)}
