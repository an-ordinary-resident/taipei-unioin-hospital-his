'use client';
import type { NovelDoc } from '@/lib/content';
import { volumeLabel,chapterLabels } from '@/lib/story-access';
import Choice from './editor-choice';
export default function StoryPicker({docs,doc,choose,create}:{docs:NovelDoc[];doc:NovelDoc;choose:(id:string)=>void;create:(kind:NovelDoc['kind'],volume?:string)=>void}){
 const labeled=chapterLabels(docs);const volumes=docs.filter(d=>d.kind==='volume'),items=docs.filter(d=>d.kind===doc.kind&&(doc.kind!=='chapter'||d.volume===doc.volume));if(!items.some(d=>d.id===doc.id))items.push(doc);
 function kind(value:string){const target=docs.find(d=>d.kind===value&&(value!=='chapter'||d.volume===(doc.kind==='volume'?doc.id:doc.volume)))||docs.find(d=>d.kind===value);if(target)choose(target.id);else create(value as NovelDoc['kind'],doc.kind==='volume'?doc.id:doc.volume)}
 return <div className="story-picker"><label>編輯類型<Choice label="編輯卷或章節" value={doc.kind} onChange={kind} items={[{value:'volume',label:'卷別資料'},{value:'chapter',label:'章節內文'}]}/></label>{doc.kind==='chapter'&&<label>選擇卷別<Choice label="篩選所屬卷別" value={doc.volume} onChange={v=>{const target=docs.find(d=>d.kind==='chapter'&&d.volume===v);if(target)choose(target.id);else create('chapter',v)}} items={volumes.length?volumes.map(d=>({value:d.id,label:volumeLabel(d)+' · '+d.title})):[{value:doc.volume,label:'尚無卷別，請先新增卷別'}]}/></label>}<label>{doc.kind==='volume'?'選擇卷':'選擇章節'}<Choice label="選擇編輯內容" value={doc.id} onChange={choose} items={items.map(d=>({value:d.id,label:(d.kind==='volume'?volumeLabel(d)+' · ':(labeled.find(c=>c.id===d.id)?.chapterLabel||'待編號')+' · ')+(d.title||'尚未命名')}))}/></label></div>
}
