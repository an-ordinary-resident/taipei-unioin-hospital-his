'use client';
import { useEffect,useState } from 'react';
import { currentReadingPosition } from '@/lib/reading-position';

export default function ReadingProgress(){
 const [percent,setPercent]=useState(0),[visible,setVisible]=useState(false);
 useEffect(()=>{
  let frame=0,timer:ReturnType<typeof setTimeout>|undefined;
  function measure(){
   setPercent(Math.round(currentReadingPosition().percent));
  }
  function scroll(){cancelAnimationFrame(frame);frame=requestAnimationFrame(measure);setVisible(true);clearTimeout(timer);timer=setTimeout(()=>setVisible(false),1000);}
  function resize(){cancelAnimationFrame(frame);frame=requestAnimationFrame(measure);}
  window.addEventListener('scroll',scroll,{passive:true});window.addEventListener('resize',resize);
  return()=>{cancelAnimationFrame(frame);clearTimeout(timer);window.removeEventListener('scroll',scroll);window.removeEventListener('resize',resize);};
 },[]);
 return <div className="reading-progress" data-visible={visible} role="progressbar" aria-label="本章閱讀進度" aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent} aria-hidden={!visible}><strong>{percent}<small>%</small></strong><span>閱讀進度</span></div>;
}
