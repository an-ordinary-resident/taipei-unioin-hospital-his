'use client';
import { useId,useState } from 'react';
import { Plus,X } from 'lucide-react';
import { DEFAULT_TERM_TAGS } from '@/lib/glossary';
export function TermTags({tags=[]}:{tags?:string[]}){return tags.length?<div className="term-tags" aria-label="屬性標籤">{tags.map(tag=><span className="term-tag" key={tag}>{tag}</span>)}</div>:null;}
export default function TermTagEditor({value,onChange,disabled=false}:{value:string[];onChange:(tags:string[])=>void;disabled?:boolean}){
 const id=useId(),[custom,setCustom]=useState(''),[error,setError]=useState('');
 function add(raw:string){const tag=raw.normalize('NFKC').trim();if(!tag)return;if(value.includes(tag)){setCustom('');setError('');return;}if(value.length>=20){setError('每個詞條最多 20 個標籤。');return;}if(tag.length>40){setError('每個標籤最多 40 字。');return;}onChange([...value,tag]);setCustom('');setError('');}
 return <fieldset className="term-tag-editor" disabled={disabled}><legend>屬性標籤</legend><p className="config-help">可複選基本分類，或新增自己的標籤。</p><div className="term-tag-choices">{DEFAULT_TERM_TAGS.map(tag=><button type="button" key={tag} aria-pressed={value.includes(tag)} onClick={()=>value.includes(tag)?onChange(value.filter(t=>t!==tag)):add(tag)}>{tag}</button>)}</div>{value.length>0&&<div className="term-tags">{value.map(tag=><button type="button" key={tag} className="term-tag" aria-label={'移除標籤：'+tag} onClick={()=>onChange(value.filter(t=>t!==tag))}>{tag}<X size={12}/></button>)}</div>}<div className="term-tag-add"><label htmlFor={id} className="sr-only">自訂標籤</label><input id={id} value={custom} maxLength={80} placeholder="自訂標籤…" onChange={e=>setCustom(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.nativeEvent.isComposing){e.preventDefault();add(custom);}}}/><button type="button" className="secondary-btn" disabled={!custom.trim()} onClick={()=>add(custom)}><Plus size={15}/>加入</button></div>{error&&<p className="editor-message is-error" role="alert">{error}</p>}</fieldset>;
}
