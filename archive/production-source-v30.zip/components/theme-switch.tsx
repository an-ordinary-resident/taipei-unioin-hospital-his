'use client';
import { Sun,Moon } from 'lucide-react';
import { useReadingPreferences } from './reading-preferences';
export default function ThemeSwitch(){const {preferences,setPreferences}=useReadingPreferences();const dark=preferences.theme==='dark';return <button type="button" className="theme-switch" aria-label={dark?'切換淺色模式':'切換深色模式'} aria-pressed={dark} onClick={()=>setPreferences({theme:dark?'light':'dark'})}>{dark?<Moon size={17}/>:<Sun size={17}/>}<span>{dark?'深色模式':'淺色模式'}</span></button>}
