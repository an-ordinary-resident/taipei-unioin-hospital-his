'use client';
import { useEffect,useRef } from 'react';
import { BookOpen,Files,LayoutDashboard,UsersRound,ShieldCheck,MoveVertical } from 'lucide-react';
import type { TourStep } from '@/lib/reader-tour';

export default function TourPreview({step}:{step:TourStep}){
 const host=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  const container=host.current;if(!container||step.id==='navigation')return;
  // A read-only copy keeps large regions independently scrollable without moving
  // React-owned page nodes. "實際操作" always opens the original live interface.
  const target=document.querySelector<HTMLElement>(step.target);
  const source=step.id==='annotations'?target?.closest('p,li')||target:target;
  if(!source){container.textContent='目前沒有可預覽的內容，仍可依說明認識這個功能。';return;}
  function refresh(){if(!container||!source)return;const position=container.parentElement?.scrollTop||0;
  const clone=source.cloneNode(true) as HTMLElement;
  for(const element of [clone,...Array.from(clone.querySelectorAll<HTMLElement>('*'))]){
   for(const attribute of Array.from(element.attributes))if(attribute.name==='id'||attribute.name==='href'||attribute.name==='for'||attribute.name==='autofocus'||attribute.name.startsWith('data-reader-')||attribute.name.startsWith('aria-')||attribute.name.startsWith('on'))element.removeAttribute(attribute.name);
   if(element.matches('a,button,input,select,textarea,summary,[tabindex]'))element.tabIndex=-1;
   if(element instanceof HTMLImageElement)element.loading='eager';
  }
  const label=({settings:'閱讀設定',info:'本章資訊',bookmark:'病歷暫存',sections:'章節分段',comments:'病歷評論',chapters:'同卷目錄'} as Record<string,string>)[step.action||''];
  if(label)for(const button of Array.from(clone.querySelectorAll('button')))if(button.textContent?.trim()===label)button.classList.add('tour-preview-focus');
  clone.classList.add('tour-preview-copy');container.replaceChildren(clone);container.parentElement?.scrollTo(0,position);}
  container.parentElement?.scrollTo(0,0);refresh();
  const observer=new MutationObserver(refresh);observer.observe(source,{subtree:true,childList:true,characterData:true,attributes:true});
  return()=>{observer.disconnect();container.replaceChildren();};
 },[step]);
 return <section className="tour-preview" aria-label="教學區塊預覽">
  <div className="tour-preview-label"><span>畫面導覽</span><small><MoveVertical size={13}/>可上下捲動查看</small></div>
  <div className="tour-preview-scroll" tabIndex={0} role="region" aria-label="區塊預覽內容，可上下捲動">
   {step.id==='navigation'?<div className="tour-navigation-preview"><span className="eyebrow">HOSPITAL INFORMATION</span>{[[LayoutDashboard,'值班主控台'],[Files,'病程紀錄'],[UsersRound,'人員檔案'],[BookOpen,'註釋辭典庫'],[ShieldCheck,'系統聲明']].map(([Icon,label])=>{const Symbol=Icon as typeof BookOpen;return <div key={String(label)}><Symbol size={18}/>{String(label)}</div>})}<p>登入身分在選單上方；淺色／深色模式與教學入口在下方。</p></div>:<div ref={host} className="tour-preview-content" onClickCapture={e=>{e.preventDefault();e.stopPropagation();}}/>}
  </div>
  <p className="tour-preview-caption">{step.action?'按下方試用按鈕，進入實際操作。':'依原頁內容呈現；可隨時暫停教學查看。'}</p>
 </section>;
}
