'use client';
import { useEffect,useRef,useState } from 'react';
import { TOUR_RUN } from '@/lib/reader-tour';
export const TOUR_DISMISS='his-tour-dismiss';
export const TOUR_MODE='his-tour-mode';
export function useTourDismiss(close:()=>void){
 const callback=useRef(close);callback.current=close;
 useEffect(()=>{const dismiss=()=>callback.current();window.addEventListener(TOUR_DISMISS,dismiss);return()=>window.removeEventListener(TOUR_DISMISS,dismiss);},[]);
}
export function useTourPractice(){
 const [practice,setPractice]=useState(false);
 useEffect(()=>{
  try{setPractice(JSON.parse(sessionStorage.getItem(TOUR_RUN)||'null')?.mode==='practice');}catch{}
  const mode=(event:Event)=>setPractice((event as CustomEvent).detail==='practice');
  window.addEventListener(TOUR_MODE,mode);return()=>window.removeEventListener(TOUR_MODE,mode);
 },[]);
 return practice;
}
