'use client';
import { useState } from 'react';
import { Radio,Pause,Play } from 'lucide-react';
export default function Announcement({text,enabled=true}:{text:string;enabled?:boolean}){
 const [paused,setPaused]=useState(false);if(!enabled||!text)return null;
 return <aside className={'announcement-strip '+(paused?'is-paused':'')} aria-label="院內公告"><span className="announcement-label"><Radio size={15}/>院內公告</span><div className="announcement-window"><div className="announcement-track" style={{animationDuration:Math.max(25,text.length*.3)+'s'}}><span>{text}</span><span aria-hidden="true">{text}</span></div></div><button type="button" className="announcement-pause" aria-label={paused?'繼續播放公告':'暫停公告'} aria-pressed={paused} onClick={()=>setPaused(!paused)}>{paused?<Play size={14}/>:<Pause size={14}/>}</button></aside>
}
