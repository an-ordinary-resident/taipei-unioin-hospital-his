'use client';

import { useRef, useState } from 'react';
import { ImagePlus } from 'lucide-react';

export default function DutyPortraitEditor({ name, image, custom, disabled, onChange, onBusyChange }: {
  name: string; image: string; custom: boolean; disabled: boolean;
  onChange: (image: string) => void; onBusyChange: (busy: boolean) => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState(false);
  const [uploading, setUploading] = useState(false);

  async function upload(file?: File) {
    if (!file) return;
    setMessage(''); setError(false);
    if (file.size > 8 * 1024 * 1024 || !['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      setError(true); setMessage('請選擇 8 MB 以下的 PNG、JPEG 或 WebP 圖片。');
      if (input.current) input.current.value = '';
      return;
    }
    setUploading(true); onBusyChange(true);
    try {
      const form = new FormData(); form.set('file', file);
      const response = await fetch('/api/upload', { method: 'POST', body: form });
      const data = await response.json() as { url?: string; error?: string };
      if (!response.ok || !data.url) throw Error(data.error || '圖片上傳失敗，請稍後再試。');
      onChange(data.url);
      setMessage('圖片已上傳，請儲存草稿或刊登設定。');
    } catch (e) {
      setError(true); setMessage(e instanceof Error ? e.message : '圖片上傳失敗，請稍後再試。');
    } finally {
      setUploading(false); onBusyChange(false);
      if (input.current) input.current.value = '';
    }
  }

  return <div className="duty-portrait-editor">
    <span className="duty-portrait-preview">{image ? <img src={image} alt={name + '的大頭貼預覽'}/> : name.slice(0, 1) || '—'}</span>
    <div className="duty-portrait-controls">
      <h3>標題人物大頭貼 <span>1:1</span></h3>
      <p>可為{name || '值班角色'}上傳專用大頭貼；未設定時使用人員檔案照片。</p>
      <div className="button-row">
        <button type="button" className="secondary-btn" disabled={disabled || uploading} onClick={() => input.current?.click()}><ImagePlus size={16}/>{uploading ? '上傳中…' : '上傳大頭貼'}</button>
        {custom && <button type="button" className="text-btn" disabled={disabled || uploading} onClick={() => { onChange(''); setMessage('已改用人員檔案照片，請儲存草稿或刊登設定。'); setError(false); }}>改用人員檔案照片</button>}
      </div>
      <input ref={input} type="file" hidden accept="image/png,image/jpeg,image/webp" disabled={disabled || uploading} onChange={e => upload(e.target.files?.[0])}/>
      <small>PNG、JPEG、WebP · 上限 8 MB · 建議使用正方形照片</small>
      {message && <p role={error ? 'alert' : 'status'} className={error ? 'portrait-feedback danger' : 'portrait-feedback'}>{message}</p>}
    </div>
  </div>;
}
