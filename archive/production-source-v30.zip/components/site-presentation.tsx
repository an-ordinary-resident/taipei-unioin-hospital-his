'use client';
import { createContext,useContext } from 'react';
import { DEFAULT_DASHBOARD,type Quote } from '@/lib/presentation-config';
import { DEFAULT_TOUR,type TourContent } from '@/lib/tour-content';
const Context=createContext({quotes:DEFAULT_DASHBOARD.quotes,isAuthor:false,tour:DEFAULT_TOUR});
export function SitePresentation({quotes,isAuthor,tour,children}:{quotes:Quote[];isAuthor:boolean;tour:TourContent;children:React.ReactNode}){return <Context.Provider value={{quotes,isAuthor,tour}}>{children}</Context.Provider>}
export function useSidebarQuotes(){return useContext(Context).quotes}
export function useAuthorAccess(){return useContext(Context).isAuthor}
export function useTourContent(){return useContext(Context).tour}
