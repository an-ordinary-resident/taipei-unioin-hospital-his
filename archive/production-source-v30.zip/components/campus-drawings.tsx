'use client';
import type { ReactNode } from 'react';
import type { CampusFloor, WardSpace } from '@/lib/campus';

function Hotspot({label,onClick,children,selected=false,className=''}:{label:string;onClick:()=>void;children:ReactNode;selected?:boolean;className?:string}){
 return <g role="button" tabIndex={0} aria-label={label} aria-pressed={selected} className={'campus-hotspot '+className} onClick={onClick} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onClick();}}}><title>{label}</title>{children}</g>;
}
function North({x=1270,y=35}:{x?:number;y?:number}){return <g transform={`translate(${x} ${y})`} className="plan-compass"><text y="-8" textAnchor="middle">N</text><path d="M0 0 L-10 27 L0 21 L10 27 Z"/><line x1="0" y1="21" x2="0" y2="38"/></g>;}
function InpatientMass(){
 const points=[[560,110],[690,65],[975,135],[845,180]];
 const edges=points.map((p,i)=>({p,q:points[(i+1)%points.length]})).filter(({p,q})=>q[0]<p[0]).sort((a,b)=>(a.p[1]+a.q[1])-(b.p[1]+b.q[1]));
 return <g>
  <path d="M480 275L625 195 1015 280 870 360Z" className="mass-roof"/>
  <path d="M480 275V345L870 430V360Z" className="mass-front"/><path d="M870 360V430L1015 350V280Z" className="mass-side"/>
  {[0,1,2,3,4].map(i=><path key={i} d={`M485 ${281+i*14}L870 ${365+i*14}L1010 ${287+i*14}`} className="mass-floor"/>)}
  {edges.map(({p,q},i)=><g key={i}><polygon points={`${p} ${q} ${q[0]},${q[1]+140} ${p[0]},${p[1]+140}`} className={q[1]>p[1]?'mass-side':'mass-front'}/>{Array.from({length:8},(_,n)=><path key={n} d={`M${p[0]} ${p[1]+8+n*17.5}L${q[0]} ${q[1]+8+n*17.5}`} className={n===3?'mass-floor-story':'mass-floor'}/>)}{[.2,.4,.6,.8].map(t=><path key={t} d={`M${p[0]+(q[0]-p[0])*t} ${p[1]+(q[1]-p[1])*t}v140`} className="mass-floor"/>)}</g>)}
  <polygon points={points.map(p=>p.join(',')).join(' ')} className="mass-roof"/>
  <path d="M620 113L700 85 915 138 835 166Z" className="roof-walk"/>
  {[[675,97],[710,105],[750,115],[868,124],[896,135],[795,145],[835,153]].map(([x,y])=><ellipse key={x} cx={x} cy={y} rx="12" ry="5" className="roof-tree"/>)}
  <path d="M660 333V384L715 396V345Z" className="mass-glass"/><path d="M686 340V390" className="plan-wall"/>
 </g>;
}
export function CampusArtwork({onChoose}:{onChoose:(b:'inpatient'|'outpatient')=>void}){
 return <svg viewBox="0 0 1100 470" className="campus-artwork" aria-label="慈愛院區建築量體示意，左側門診大樓，右側住院大樓">
  <defs><pattern id="campus-brick" width="18" height="10" patternUnits="userSpaceOnUse"><path d="M0 0H18M0 10H18M9 0V5M0 5H18M0 5V10M18 5V10" fill="none" stroke="currentColor" strokeWidth=".5" opacity=".22"/></pattern></defs>
  <path d="M510 70 Q700 -25 860 55 T1120 80 L1120 365 L500 365Z" className="campus-hill"/><path d="M0 400L600 300 1100 370 450 470Z" className="campus-ground"/>
  {[60,105,980,1030,1000,450,485].map((x,i)=><g key={x} transform={`translate(${x} ${320+(i%3)*16})`} className="campus-tree"><path d="M0 0V32"/><circle cy="-5" r="19"/><circle cx="-9" cy="4" r="13"/></g>)}
  <path d="M360 335L555 302 600 327 405 360Z" className="campus-bridge"/><path d="M360 335V355L405 380V360M405 380L600 347V327" className="campus-bridge-side"/>
  <Hotspot label="進入新址住院大樓，地上十三層、地下三層" onClick={()=>onChoose('inpatient')}>
   <InpatientMass/>
   <g className="building-label" transform="translate(730 36)"><rect x="-135" y="-20" width="270" height="49" rx="5"/><text textAnchor="middle" y="0">新址住院大樓</text><text textAnchor="middle" y="19" className="svg-small">13F / B3F · A・B・C 分區</text></g>
   <g transform="translate(942 207)" className="story-pin"><circle r="20"/><text textAnchor="middle" y="5">10</text><path d="M-20 0H-80"/></g>
  </Hotspot>
  <Hotspot label="進入第一門診大樓，歷史建築導覽" onClick={()=>onChoose('outpatient')}>
   <path d="M115 256L175 220 430 283 370 320Z" className="clinic-roof"/><path d="M115 256V351L370 414V320Z" className="clinic-front"/><path d="M370 320V414L430 378V283Z" className="clinic-side"/>
   <path d="M115 256V351L370 414V320Z" fill="url(#campus-brick)"/>
   {[0,1,2].map(row=>[0,1,2,3,4,5,6].map(col=><path key={`${row}-${col}`} d={`M${133+col*33} ${276+row*27+col*8}v14l13 3v-14q-6-14-13-3Z`} className="clinic-window"/>))}
   <path d="M210 370V342Q229 323 246 351V379" className="clinic-door"/>
   <g className="building-label" transform="translate(255 188)"><rect x="-130" y="-20" width="260" height="49" rx="5"/><text textAnchor="middle" y="0">第一門診大樓</text><text textAnchor="middle" y="19" className="svg-small">1914 · 紅磚與檜木的舊時光</text></g>
  </Hotspot>
  <text x="455" y="394" className="svg-small" transform="rotate(-10 455 394)">1F 風雨連通廊</text><text x="36" y="38" className="plan-caption">CIAI CAMPUS / 建築量體示意</text><North x={1045} y={32}/>
 </svg>;
}

export function FloorDrawing({floor,zone,onZone}:{floor:CampusFloor;zone:number;onZone:(n:number)=>void}){
 const code=floor.id.replace('F','');
 // All floors share the same layout: A northeast, B south, C northwest.
 const zonePolys=['550,115 830,115 830,355 550,355','200,425 700,425 700,610 200,610','70,115 350,115 350,355 70,355'];
 const centers=[[690,230],[450,520],[210,230]];
 return <svg viewBox="0 0 900 670" className="floor-drawing" aria-label={`${floor.id} ${floor.title}，點選 A、B、C 區查看機能`}>
  <text x="35" y="35" className="plan-caption">{floor.id} / 樓層機能示意</text><North x={850} y={35}/>
  <path d="M350 245H550M450 245V440" className="plan-connector"/>
  {[0,1,2].map(i=><Hotspot key={i} label={`${code}${'ABC'[i]} ${floor.zones[i]}${floor.id==='10F'&&i===0?'，開啟 10A 詳細平面圖':''}`} selected={zone===i} onClick={()=>onZone(i)} className={'wing wing-'+i}>
   <polygon points={zonePolys[i]} className="zone-area"/>
   <g transform={`translate(${centers[i][0]} ${centers[i][1]})`} className="wing-label"><rect x="-65" y="-31" width="130" height="70" rx="7"/><text textAnchor="middle" className="wing-code">{floor.id==='RF'?'ABC'[i]+' 區':code+'ABC'[i]}</text><text textAnchor="middle" y="24" className="svg-small">{floor.id==='10F'&&i===0?'進入故事現場 →':floor.beds?.[i]?floor.beds[i]+' 床':'點選查看'}</text></g>
  </Hotspot>)}
  <g className="floor-core"><path d="M400 275H500L542 345 500 415H400L358 345Z"/><path d="M408 289H492L526 345 492 401H408L374 345Z" className="core-ring"/>{[0,1,2,3].map(i=><rect key={i} x={398+i*26} y="309" width="22" height="27" rx="1"/>)}<text x="450" y="360" textAnchor="middle">中央核心筒</text><text x="450" y="380" textAnchor="middle" className="svg-small">梯廳・醫勤支援</text></g>
  <text x="55" y="635" className="plan-caption">A 東北區（右上） / B 南區（下方） / C 西北區（左上）</text>
 </svg>;
}

function Bed({x,y,w=32,h=54,label}:{x:number;y:number;w?:number;h?:number;label?:string}){return <g transform={`translate(${x} ${y})`} className="plan-bed"><rect width={w} height={h} rx="3"/><rect x="3" y="4" width={w-6} height={h*.22} rx="2"/><path d={`M3 ${h*.38}H${w-3}M-3 10V${h-10}M${w+3} 10V${h-10}`}/>{label&&<text x={w/2} y={h+15} textAnchor="middle">{label}</text>}</g>;}
function Bath({x,y,w=45,h=45}:{x:number;y:number;w?:number;h?:number}){return <g transform={`translate(${x} ${y})`} className="plan-bath"><rect width={w} height={h}/><rect x="5" y="5" width={w*.38} height={h*.42}/><ellipse cx={w*.72} cy={h*.33} rx={w*.12} ry={h*.14}/><path d={`M${w-12} ${h}v-12h12`}/><text x={w/2} y={h-9} textAnchor="middle">衛浴</text></g>;}
function Door({x,y,rotate=0,size=28}:{x:number;y:number;rotate?:number;size?:number}){return <g transform={`translate(${x} ${y}) rotate(${rotate})`} className="plan-door"><path d={`M0 0H${size}`} className="door-gap"/><path d={`M0 0V-${size}M0 -${size}A${size} ${size} 0 0 1 ${size} 0`}/></g>;}
function WindowLine({x,y,w}:{x:number;y:number;w:number}){return <g className="plan-window"><path d={`M${x} ${y-2}h${w}M${x} ${y+2}h${w}`}/></g>;}
export function WardDrawing({onSpace,selected,route}:{onSpace:(id:string)=>void;selected:string|null;route:boolean}){
 const four=['01','02','03','05','06'];const south=['07','08','09','10','11','12','15'];
 return <svg viewBox="0 0 1420 840" className="ward-drawing" aria-label="10A 一般內科暨感染症病房平面圖，北側四人房與隔離室，南側雙人及單人房。每個房間皆可點選。">
  <text x="80" y="44" className="plan-caption">10A / 一般內科暨感染症病房</text><North x={1340} y={38}/>
  <g className="plan-dimension"><path d="M120 85V68H1020V85M300 62V76M480 62V76M660 62V76M840 62V76"/><text x="575" y="58" textAnchor="middle">北側採光面 · 五間四人病房</text></g>
  <rect x="115" y="95" width="1195" height="625" rx="2" className="ward-outline"/>
  <path d="M120 300H1305V370H985V455H1305V515H245V455H915V370H120Z" className="plan-corridor"/>
  <text x="660" y="342" textAnchor="middle" className="corridor-label">10A 主走道 · 圖冊淨寬 2,800 mm</text>
  <text x="660" y="490" textAnchor="middle" className="corridor-label">南側病房支走道</text>
  {four.map((n,i)=>{const x=120+i*180;return <Hotspot key={n} label={`10A-${n} 四人健保病房，4 床`} selected={selected==='10A-'+n} onClick={()=>onSpace('10A-'+n)} className="room-four"><rect x={x} y="100" width="180" height="200" className="room-shape"/><WindowLine x={x+26} y={100} w={128}/><text x={x+90} y="125" textAnchor="middle" className="room-name">10A-{n}</text>{[[30,145],[109,145],[30,215],[109,215]].map(([dx,y],j)=><Bed key={j} x={x+dx} y={y} w={35} h={42}/>)}<Bath x={x+5} y={263} w={43} h={35}/><Door x={x+115} y={300}/></Hotspot>;})}
  <Hotspot label="10A-16 負壓隔離病房，1 床，含前室" onClick={()=>onSpace('10A-16')} selected={selected==='10A-16'} className="room-isolation"><rect x="1020" y="100" width="180" height="200" className="room-shape"/><WindowLine x={1045} y={100} w={125}/><path d="M1020 248H1200" className="plan-wall"/><text x="1110" y="125" textAnchor="middle" className="room-name">10A-16</text><Bed x={1080} y={150} w={38} h={60}/><text x="1090" y="233" textAnchor="middle" className="svg-small">負壓隔離</text><text x="1070" y="279" className="svg-small">前室</text><Bath x={1147} y={198} w={50} h={46}/><Door x={1080} y={300}/><Door x={1080} y={248}/></Hotspot>
  <Hotspot label="S-A 安全梯，病房末端" onClick={()=>onSpace('stairs')} selected={selected==='stairs'} className="room-support"><rect x="1200" y="100" width="105" height="200" className="room-shape"/><text x="1252" y="130" textAnchor="middle" className="room-name">S-A</text><g className="plan-stairs">{Array.from({length:9},(_,i)=><path key={i} d={`M1215 ${153+i*10}H1243M1262 ${153+i*10}H1290`}/>)}<path d="M1228 235V150H1277V235M1223 160L1228 150 1233 160"/></g><Door x={1235} y={300}/></Hotspot>
  <Hotspot label="中央梯廳與病房入口" onClick={()=>onSpace('core')} selected={selected==='core'} className="room-support"><rect x="120" y="370" width="125" height="345" className="room-shape"/><text x="182" y="404" textAnchor="middle" className="room-name">中央梯廳</text><text x="182" y="427" textAnchor="middle" className="svg-small">10F 核心筒</text>{[0,1,2].map(i=><g key={i}><rect x="137" y={453+i*67} width="88" height="46" className="plan-fixture"/><path d={`M181 ${453+i*67}v46`} className="plan-wall"/><text x="181" y={480+i*67} textAnchor="middle" className="svg-small">{['訪客電梯','病床電梯','醫勤服務'][i]}</text></g>)}<text x="182" y="687" textAnchor="middle" className="svg-small">病房入口 ↑</text><Door x={160} y={370} rotate={180}/><Door x={245} y={500} rotate={-90} size={40}/></Hotspot>
  <Hotspot label="中央護理站與醫師工作區" onClick={()=>onSpace('station')} selected={selected==='station'} className="room-station"><rect x="245" y="370" width="345" height="85" className="room-shape"/><path d="M268 402Q415 361 567 402L565 414Q415 377 270 414Z" className="station-counter"/>{[0,1,2,3,4,5].map(i=><rect key={i} x={285+i*45} y="388" width="12" height="9" className="station-monitor"/>)}<text x="418" y="431" textAnchor="middle" className="room-name">護理站 / 醫師工作區</text>{[0,1,2,3,4].map(i=><path key={i} d={`M${305+i*47} 446h27v-7h-27Z`} className="plan-fixture"/>)}</Hotspot>
  {[{id:'treatment',x:590,w:125,name:'處置治療室'},{id:'medication',x:715,w:100,name:'配藥室'},{id:'utility',x:815,w:100,name:'污物室'},{id:'meeting',x:985,w:135,name:'會談室'},{id:'oncall',x:1120,w:185,name:'醫師值班室'}].map(s=><Hotspot key={s.id} label={s.name} onClick={()=>onSpace(s.id)} selected={selected===s.id} className="room-support"><rect x={s.x} y="370" width={s.w} height="85" className="room-shape"/><text x={s.x+s.w/2} y="422" textAnchor="middle" className="room-name">{s.name}</text><rect x={s.x+10} y="437" width={s.w-20} height="9" className="plan-fixture"/><Door x={s.x+30} y={370} rotate={180} size={24}/></Hotspot>)}
  {south.map((n,i)=>{const single=i>3;const x=single?825+(i-4)*160:245+i*145;const w=single?160:145;return <Hotspot key={n} label={`10A-${n} ${single?'單人特等病房，1 床':'雙人差額病房，2 床'}`} onClick={()=>onSpace('10A-'+n)} selected={selected==='10A-'+n} className={single?'room-single':'room-double'}><rect x={x} y="515" width={w} height="200" className="room-shape"/><Door x={x+85} y={515} rotate={180}/><Bath x={x+5} y={520} w={47} h={43}/><text x={x+w/2} y="590" textAnchor="middle" className="room-name">10A-{n}</text><Bed x={x+20} y={612} h={59} w={37}/>{single?<rect x={x+99} y="623" width="40" height="26" rx="4" className="plan-fixture"/>:<Bed x={x+86} y={612} h={59} w={37}/>}<WindowLine x={x+20} y={715} w={w-40}/><text x={x+w/2} y="699" textAnchor="middle" className="svg-small">{single?'單人特等房':'雙人差額房'}</text></Hotspot>;})}
  {route&&<g className="ward-route" aria-hidden="true"><path d="M181 645V335H950V485H320V535M181 335H418V395"/><circle cx="181" cy="645" r="7"/><path d="M411 385L418 398 425 385M313 525L320 538 327 525"/></g>}
  <g className="plan-dimension"><path d="M245 735V750H1305V735"/><text x="775" y="774" textAnchor="middle">南側：4 間雙人病房 + 3 間單人病房</text></g>
  <text x="80" y="812" className="plan-caption">A-04 / 互動場景重繪 · 保留房號、床數與分區；南側支走道及家具位置依通行需求補繪</text>
 </svg>;
}

export function RoomDrawing({space}:{space:WardSpace}){
 const patient=!!space.beds;
 const negative=space.kind==='isolation';
 return <svg viewBox="0 0 620 480" className="room-detail-drawing" aria-label={`${space.id} ${space.name}，室內配置示意`}>
  <text x="26" y="28" className="plan-caption">{patient?space.id:space.name} / 室內配置示意</text>
  <rect x="80" y="55" width="460" height="345" className={'room-shape detail-'+space.kind}/><WindowLine x={220} y={55} w={240}/>
  {patient?<>
   <Bath x={84} y={59} w={112} h={100}/><Door x={196} y={145} rotate={-90} size={35}/>
   {space.beds===4?[[240,95],[415,95],[240,250],[415,250]].map(([x,y],i)=><Bed key={i} x={x} y={y} w={65} h={99} label={`床 ${i+1}`}/>):space.beds===2?[[235,150],[425,150]].map(([x,y],i)=><Bed key={i} x={x} y={y} w={65} h={122} label={`床 ${i+1}`}/>):<><Bed x={298} y={negative?105:145} w={77} h={128} label="病床"/><rect x="444" y="163" width="57" height="90" rx="6" className="plan-fixture"/><text x="472" y="275" textAnchor="middle" className="svg-small">陪伴座位</text></>}
   {negative?<><path d="M80 280H540" className="plan-wall"/><Door x={290} y={280} size={46}/><Door x={420} y={400} size={46}/><text x="340" y="345" textAnchor="middle">氣密前室</text><path d="M440 377V322H330V258" className="detail-airflow"/><text x="452" y="365" className="svg-small">入口</text></>:<><Door x={115} y={400} size={58}/><text x="150" y="433" textAnchor="middle" className="svg-small">病房入口 / 接病房走道</text>{space.beds!>1&&<path d="M370 80V365" className="privacy-curtain"/>}</>}
  </>:space.kind==='station'?<><path d="M125 195Q310 80 495 195L490 230Q310 130 130 230Z" className="station-counter"/>{Array.from({length:6},(_,i)=><rect key={i} x={154+i*53} y={160+Math.abs(2.5-i)*8} width="28" height="18" className="station-monitor"/>)}<text x="310" y="260" textAnchor="middle">6 部 COW 充電座 / 護理工作區</text>{Array.from({length:5},(_,i)=><g key={i}><rect x={135+i*73} y="305" width="61" height="36" className="plan-fixture"/><rect x={149+i*73} y="312" width="30" height="14" className="station-monitor"/></g>)}<text x="310" y="377" textAnchor="middle">5 台 HIS / PACS 醫師工作站</text></>:space.kind==='stairs'?<g className="plan-stairs">{Array.from({length:12},(_,i)=><path key={i} d={`M130 ${105+i*19}H260M360 ${105+i*19}H490`}/>)}<path d="M190 330V80H430V330M181 100L190 80 199 100"/><Door x={285} y={400} size={55}/></g>:<><Door x={120} y={400} size={54}/>{space.kind==='oncall'?<><Bed x={270} y={105} w={78} h={150}/><rect x="430" y="85" width="75" height="170" className="plan-fixture"/><text x="467" y="278" textAnchor="middle" className="svg-small">收納櫃</text></>:space.kind==='meeting'?<><rect x="235" y="160" width="170" height="100" rx="12" className="plan-fixture"/>{[0,1,2].map(i=><g key={i}><rect x={249+i*55} y="120" width="30" height="25" rx="5" className="plan-fixture"/><rect x={249+i*55} y="280" width="30" height="25" rx="5" className="plan-fixture"/></g>)}<text x="320" y="216" textAnchor="middle" className="svg-small">會談桌</text></>:space.kind==='core'?<>{['P1–P4','B1–B2','S1'].map((s,i)=><g key={s}><rect x={120+i*135} y="110" width="110" height="110" className="plan-fixture"/><path d={`M${175+i*135} 110V220`} className="plan-wall"/><text x={175+i*135} y="260" textAnchor="middle">{s}</text></g>)}<text x="310" y="330" textAnchor="middle" className="svg-small">訪客電梯 / 病床電梯 / 服務電梯</text></>:<><rect x="120" y="82" width="380" height="45" className="plan-fixture"/><text x="310" y="111" textAnchor="middle" className="svg-small">{space.kind==='medication'?'ADC 智慧藥櫃':'設備與工作檯'}</text>{space.kind==='treatment'?<Bed x={290} y={180} w={80} h={130}/>:<rect x="425" y="165" width="70" height="150" className="plan-fixture"/>}<circle cx="150" cy="103" r="12" className="plan-fixture"/></>}</>}
  <text x="310" y="468" textAnchor="middle" className="plan-caption">依圖冊機能補繪家具與門扇 · 不作等比例量測</text>
 </svg>;
}
