'use client';
import { useState } from 'react';
import { PenLine,ChevronDown } from 'lucide-react';
import { AUTHOR_SECTIONS } from '@/lib/presentation-config';
export default function AuthorNav({active}:{active:boolean}){const [open,setOpen]=useState(active);return <div className="author-nav"><button type="button" className={'nav-link author-nav-trigger '+(active?'selected':'')} onClick={()=>setOpen(!open)} aria-expanded={open} aria-controls="author-navigation"><PenLine size={18}/>作者工作台<ChevronDown size={16} className={open?'rotated':''}/></button>{open&&<nav id="author-navigation" aria-label="作者編輯面向">{AUTHOR_SECTIONS.map(s=><a key={s.id} href={'/author?section='+s.id}>{s.label}</a>)}<span className="author-nav-hint">限作者編輯</span></nav>}</div>}
