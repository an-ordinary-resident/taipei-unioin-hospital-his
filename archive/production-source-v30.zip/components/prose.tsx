"use client";
import { useTourDismiss } from './tour-events';
import { useState,type ReactNode } from 'react';
import { Popover,PopoverTrigger,PopoverContent,PopoverTitle,PopoverDescription } from '@/components/ui/popover';
import Protected from '@/components/protected-content';
import { inlineNodes,proseBlocks,type InlineNode,type Annotation } from '@/lib/rich-text';
import { X } from 'lucide-react';
import { TermTags } from './term-tags';
import { passageKeys } from '@/lib/reading-history';
function Spoiler({children}:{children:ReactNode}){
 const [revealed,setRevealed]=useState(false);
 return <span className="spoiler-mask" role="button" tabIndex={0} data-revealed={revealed} aria-expanded={revealed} aria-label={revealed?undefined:'防劇透文字，按下揭露'} title="你知道的太多了" onClick={e=>{if(!revealed||!(e.target as Element).closest('a')){e.preventDefault();e.stopPropagation();setRevealed(!revealed);}}} onKeyDown={e=>{if(e.target===e.currentTarget&&(e.key==='Enter'||e.key===' ')){e.preventDefault();setRevealed(!revealed);}}}><span className="spoiler-content" aria-hidden={!revealed}>{children}</span></span>;
}
function NoteLink({note}:{note:Annotation}){const [open,setOpen]=useState(false);useTourDismiss(()=>setOpen(false));return <sup className="annotation-ref"><Popover open={open} onOpenChange={setOpen}><PopoverTrigger className="annotation-button" aria-label={'註解 '+note.id+'：'+note.term}>[{note.id}]</PopoverTrigger><PopoverContent className="annotation-popover" backdropClassName="annotation-backdrop" side="top" sideOffset={10}><Protected><div className="annotation-top"><span className="mono">TERM NOTE / {String(note.id).padStart(2,'0')}</span><button type="button" aria-label="關閉註解" className="popup-close" onClick={()=>setOpen(false)}><X size={16}/></button></div><PopoverTitle className="annotation-title">{note.term}</PopoverTitle><TermTags tags={note.tags}/><PopoverDescription render={<div/>} className="annotation-description"><Prose text={note.text}/></PopoverDescription><span className="annotation-author">作者註釋</span></Protected></PopoverContent></Popover></sup>}
function Inline({nodes,notes}:{nodes:InlineNode[];notes:Annotation[]}){return <>{nodes.map((node,i)=>{
 if(node.kind==='text')return node.text;
 if(node.kind==='note'){const note=notes.find(n=>n.id===node.id);return note?<NoteLink key={i} note={note}/>:<span key={i}>[{node.id}]</span>;}
 const children=<Inline nodes={node.children} notes={notes}/>;
 if(node.kind==='spoiler')return <Spoiler key={i}>{children}</Spoiler>;
 if(node.kind==='underline')return <u key={i}>{children}</u>;
 if(node.kind==='bold')return <strong key={i}>{children}</strong>;
 if(node.kind==='italic')return <em key={i}>{children}</em>;
 if(node.kind==='strike')return <s key={i}>{children}</s>;
 if(node.kind==='link')return <a key={i} href={node.href} className="novel-link" target="_blank" rel="noopener noreferrer">{children}</a>;
 return <span key={i} className={'ink-'+node.color}>{children}</span>;
})}</>}
export default function Prose({text,notes=[],headingPrefix,trackPassages=false,preserveBlank=trackPassages}:{text:string;notes?:Annotation[];headingPrefix?:string;trackPassages?:boolean;preserveBlank?:boolean}){
 const blocks=proseBlocks(text,preserveBlank),keys=trackPassages?passageKeys(blocks):[];
 // Keep existing section links stable when blank paragraphs are displayed.
 const headingIds=proseBlocks(text).flatMap((block,i)=>block.kind==='heading'?[headingPrefix+'-'+(i+1)]:[]);
 let headingIndex=0;
 return <>{blocks.map((block,i)=>{
  if(block.kind==='paragraph'&&!block.lines[0].trim())return <div key={i} className="prose-blank-line" aria-hidden="true"/>;
  const passage=trackPassages?{'data-reader-block':keys[i]}:{};
  if(block.kind==='divider')return <hr key={i} {...passage} className="novel-divider"/>;
  if(block.kind==='image')return <figure key={i} {...passage}><img src={block.lines[0]} alt="作者上傳的作品插圖" loading="lazy" draggable={false}/></figure>;
  if(block.kind==='list')return <ul key={i} {...passage} className="novel-list" style={{textAlign:block.alignment,listStylePosition:block.alignment&&block.alignment!=='left'?'inside':undefined}}>{block.lines.map((line,j)=><li key={j}><Inline nodes={inlineNodes(line)} notes={notes}/></li>)}</ul>;
  const children=<Inline nodes={inlineNodes(block.lines[0])} notes={notes}/>;
  if(block.kind==='heading'){
   const Tag=block.level===1?'h2':block.level===2?'h3':'h4';
   return <Tag key={i} {...passage} style={{textAlign:block.alignment}} id={headingPrefix?headingIds[headingIndex++]:undefined} tabIndex={headingPrefix?-1:undefined} className={'prose-heading prose-heading-'+block.level}>{children}</Tag>;
  }
  return <p key={i} {...passage} style={{textAlign:block.alignment}}>{children}</p>;
 })}</>
}
