'use client';
import { useState } from 'react';
import { Download,FileText,Copy,FileCode } from 'lucide-react';
import type { NovelDoc } from '@/lib/content';
import { chapterBackup } from '@/lib/chapter-backup';
import { Dialog,DialogContent,DialogTitle,DialogDescription } from './ui/dialog';
export default function ChapterBackup({doc,records}:{doc:NovelDoc;records:NovelDoc[]}){
 const [open,setOpen]=useState(false),[message,setMessage]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(false);
 function download(format:'markdown'|'html'){
  const backup=chapterBackup(doc,records,window.location.origin),extension=format==='markdown'?'md':'html';
  const url=URL.createObjectURL(new Blob([backup[format]],{type:format==='markdown'?'text/markdown;charset=utf-8':'text/html;charset=utf-8'}));
  const anchor=document.createElement('a');anchor.href=url;anchor.download=backup.filename+'.'+extension;document.body.appendChild(anchor);anchor.click();anchor.remove();window.setTimeout(()=>URL.revokeObjectURL(url),60000);
  setError(false);setMessage('已下載 '+extension.toUpperCase()+' 備份，包含本章資訊、完整內文與全部 '+(doc.notes?.length||0)+' 則註釋。');
 }
 async function copy(){
  setBusy(true);setMessage('');setError(false);
  try{
   if(!navigator.clipboard?.write||typeof ClipboardItem==='undefined')throw Error('此瀏覽器不支援複製格式文字，請改用下載 Markdown 或 HTML。');
   const backup=chapterBackup(doc,records,window.location.origin);
   await navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([backup.html],{type:'text/html'}),'text/plain':new Blob([backup.markdown],{type:'text/plain'})})]);
   setMessage('已複製格式文字，可貼入文件編輯器；不支援格式的欄位會貼上 Markdown。');
  }catch{setError(true);setMessage('瀏覽器未允許複製格式文字，請改用下載 Markdown 或 HTML。');}finally{setBusy(false);}
 }
 return <><button type="button" className="text-btn" onClick={()=>{setMessage('');setError(false);setOpen(true);}}><Download size={15}/>文字備份</button><Dialog open={open} onOpenChange={setOpen}><DialogContent className="chapter-backup-dialog"><DialogTitle>章節文字備份</DialogTitle><DialogDescription>匯出目前編輯中的「{doc.title||'未命名章節'}」，包含尚未儲存的修改、本章資訊與全部用詞註釋。</DialogDescription><div className="backup-options"><button type="button" className="secondary-btn" onClick={()=>download('markdown')}><FileText size={20}/><span><strong>下載 Markdown</strong><small>保留標題、粗體、列點與連結，方便收藏與再編輯。</small></span></button><button type="button" className="secondary-btn" disabled={busy} onClick={copy}><Copy size={20}/><span><strong>{busy?'複製中…':'複製格式文字'}</strong><small>貼入文件編輯器，盡量保留顏色與排版。</small></span></button><button type="button" className="secondary-btn" onClick={()=>download('html')}><FileCode size={20}/><span><strong>下載 HTML</strong><small>使用瀏覽器開啟，保留完整文字格式。</small></span></button></div><p className="config-help">純 Markdown 沒有標準的文字顏色或對齊語法，備份會以 HTML 補充。貼入 Anytype、Google 文件或其他平台時，實際格式依該平台支援。</p>{message&&<p className={'editor-message '+(error?'is-error':'')} role={error?'alert':'status'}>{message}</p>}</DialogContent></Dialog></>;
}
