'use client';
import { useEffect,useState } from 'react';
import { Save,Send,Stethoscope } from 'lucide-react';
import { tourSteps,tourStations } from '@/lib/reader-tour';
import { tourContent,type TourContent,type TourCopy } from '@/lib/tour-content';
import { Tabs,TabsList,TabsTrigger,TabsContent } from './ui/tabs';
import Choice from './editor-choice';

export default function TourEditor({initial}:{initial:{value:TourContent;revision:number;hasDraft:boolean}}){
 const [value,setValue]=useState(()=>tourContent(initial.value)),[revision,setRevision]=useState(initial.revision),[hasDraft,setHasDraft]=useState(initial.hasDraft),[dirty,setDirty]=useState(false),[busy,setBusy]=useState(false),[selected,setSelected]=useState('welcome'),[message,setMessage]=useState(''),[error,setError]=useState(false);
 const current=selected==='welcome'?value.welcome:selected==='complete'?value.complete:value.steps[selected];
 const step=tourSteps.find(s=>s.id===selected);
 useEffect(()=>{const warn=(e:BeforeUnloadEvent)=>{if(dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[dirty]);
 function change(patch:Partial<TourCopy>){setValue(v=>selected==='welcome'||selected==='complete'?{...v,[selected]:{...v[selected],...patch}}:{...v,steps:{...v.steps,[selected]:{...v.steps[selected],...patch}}});setDirty(true);setMessage('');}
 async function save(action:'draft'|'publish'){
  setBusy(true);setMessage('');
  try{const response=await fetch('/api/site-config/tour',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({value,revision,action})});const data=await response.json() as typeof initial&{error?:string};if(!response.ok)throw Error(data.error||'儲存失敗');setValue(tourContent(data.value));setRevision(data.revision);setHasDraft(data.hasDraft);setDirty(false);setError(false);setMessage(action==='publish'?'教學文案已刊登，讀者下次開啟頁面即會使用新版內容。':'教學草稿已儲存，讀者仍會看到目前刊登的版本。');}catch(e){setError(true);setMessage(e instanceof Error?e.message:'儲存失敗，請稍後重試。');}finally{setBusy(false);}
 }
 return <><section className="panel editor-panel presentation-editor">
  <div className="editor-status"><span>報到教學 <span className="badge">已刊登</span>{hasDraft&&<span className="badge warning">有草稿修改</span>}</span><span>{dirty?'有尚未儲存的修改':'所有修改已儲存'}</span></div>
  <div className="tour-editor-selector"><label>教學段落<Choice label="選擇教學段落" value={selected} onChange={setSelected} disabled={busy} items={[{value:'welcome',label:'報到歡迎視窗'},...tourSteps.map((s,i)=>({value:s.id,label:`${String(i+1).padStart(2,'0')} · ${tourStations[s.station]} / ${s.title}`})),{value:'complete',label:'完成報到視窗'}]}/></label></div>
  <Tabs defaultValue="edit"><TabsList className="presentation-tabs"><TabsTrigger value="edit">編輯設定</TabsTrigger><TabsTrigger value="preview">畫面預覽</TabsTrigger></TabsList>
   <TabsContent value="edit"><fieldset className="presentation-fields" disabled={busy}><section className="config-section">
    <div className="config-section-heading"><span className="section-number">{step?String(tourSteps.indexOf(step)+1).padStart(2,'0'):'HIS'}</span><div><h2>{step?tourStations[step.station]:selected==='welcome'?'報到歡迎視窗':'完成報到視窗'}</h2><p>編輯標題、介紹內文與補充提醒。</p></div></div>
    <label>教學標題<input maxLength={100} value={current.title} onChange={e=>change({title:e.target.value})}/></label>
    <label>介紹內文<textarea rows={6} maxLength={1500} value={current.body} onChange={e=>change({body:e.target.value})}/></label>
    <label>補充提醒（選填）<textarea rows={3} maxLength={500} value={current.hint} onChange={e=>change({hint:e.target.value})}/></label>
    <p className="config-help">介紹員為「一個平凡的住院醫師」。建議每段保持簡短，讓讀者花約 3-5 分鐘熟悉系統。</p>
   </section></fieldset></TabsContent>
   <TabsContent value="preview"><div className="tour-editor-preview"><div className="tour-card tour-copy-preview"><div className="tour-brand"><span><Stethoscope size={19}/></span><div>慈愛院區・新進人員報到<small>帶路醫師 · 一個平凡的住院醫師</small></div></div><h2>{current.title}</h2><p>{current.body}</p>{current.hint&&<p className="tour-hint">{current.hint}</p>}{step?.actionLabel&&<span className="secondary-btn tour-preview-action">{step.actionLabel}</span>}</div><p className="config-help">此處預覽尚未刊登的文案；實際教學會依裝置調整排版。</p></div></TabsContent>
  </Tabs>
  <div className="save-bar"><div/><div className="button-row"><button type="button" className="secondary-btn" disabled={busy} onClick={()=>void save('draft')}><Save size={16}/>儲存草稿</button><button type="button" className="primary-btn" disabled={busy} onClick={()=>void save('publish')}><Send size={16}/>{busy?'處理中…':'刊登教學'}</button></div></div>
  {message&&<div role={error?'alert':'status'} className={'editor-message '+(error?'is-error':'')}>{message}</div>}
 </section><p className="editor-help">一次儲存所有教學段落。草稿僅作者可見，刊登後才更新讀者的教學內文。</p></>;
}
