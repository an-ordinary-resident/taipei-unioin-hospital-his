"use client";
import { useTourDismiss } from './tour-events';
import { useEffect,useRef,useState } from 'react';
import { createPortal } from 'react-dom';
import { DropdownMenu,DropdownMenuTrigger,DropdownMenuContent,DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { Popover,PopoverTrigger,PopoverContent,PopoverTitle,PopoverDescription } from '@/components/ui/popover';
import { Dialog,DialogTrigger,DialogContent,DialogTitle,DialogDescription } from '@/components/ui/dialog';
import { RadioGroup,RadioGroupItem } from '@/components/ui/radio-group';
import { Select,SelectTrigger,SelectValue,SelectContent,SelectItem } from '@/components/ui/select';
import { useReadingPreferences,type Preferences } from '@/components/reading-preferences';
import Protected from '@/components/protected-content';
import { useReaderSession } from './reader-session';
import ReaderPanels,{type ReaderSection,type ReaderChapter,type ReaderTool} from './reader-panels';
import { SlidersHorizontal,ClipboardList,UsersRound,Text,Clock3,Sun,Moon,ListTree,MessagesSquare,Files,ChevronDown,Bookmark } from 'lucide-react';
const toolItems=[
 {id:'settings',label:'閱讀設定',Icon:SlidersHorizontal},
 {id:'info',label:'本章資訊',Icon:ClipboardList},
 {id:'sections',label:'章節分段',Icon:ListTree},
 {id:'comments',label:'病歷評論',Icon:MessagesSquare},
 {id:'chapters',label:'同卷目錄',Icon:Files},
] as const;
const fonts=[{value:'serif',label:'明體 · 原始字型'},{value:'sans',label:'黑體 · 清晰俐落'},{value:'kai',label:'楷體 · 手寫筆意'}];
export default function ReaderTools({title,cast=[],summary='',count,readingMinutes='',chapterId,sections,chapters}:{title:string;cast?:string[];summary?:string;count:number;readingMinutes?:string;chapterId:string;sections:ReaderSection[];chapters:ReaderChapter[]}){const {preferences,setPreferences}=useReadingPreferences();
 const session=useReaderSession();
 const toolbarRef=useRef<HTMLDivElement>(null),floatingRef=useRef<HTMLButtonElement>(null);
 const [header,setHeader]=useState<HTMLElement|null>(null);
 const [floating,setFloating]=useState(false);
 const [menuOpen,setMenuOpen]=useState(false);
 const [activeTool,setActiveTool]=useState<ReaderTool|null>(null);
 useTourDismiss(()=>{setActiveTool(null);setMenuOpen(false);});
 useEffect(()=>{const open=(event:Event)=>{if((event as CustomEvent).detail===chapterId)setActiveTool('comments');};window.addEventListener('his-open-comments',open);return()=>window.removeEventListener('his-open-comments',open);},[chapterId]);
 useEffect(()=>{const open=(event:Event)=>{const tool=(event as CustomEvent).detail;if(tool==='bookmark')session.openBookmark();else if(['settings','info','sections','comments','chapters'].includes(tool))setActiveTool(tool);};window.addEventListener('his-tour-tool',open);return()=>window.removeEventListener('his-tour-tool',open);},[session]);
 function onToolChange(tool:ReaderTool,open:boolean){
  setActiveTool(current=>open?tool:current===tool?null:current);
 }
 useEffect(()=>{
  const toolbar=toolbarRef.current,topbar=document.querySelector<HTMLElement>('.his-main .topbar');
  if(!toolbar||!topbar)return;
  setHeader(topbar);
  let observer:IntersectionObserver;
  const observe=()=>{
   const headerHeight=topbar.getBoundingClientRect().height;
   observer?.disconnect();
   observer=new IntersectionObserver(([entry])=>{
    setFloating(!entry.isIntersecting&&entry.boundingClientRect.bottom<=headerHeight);
   },{rootMargin:`-${headerHeight}px 0px 0px 0px`,threshold:0});
   observer.observe(toolbar);
  };
  observe();
  const resize=new ResizeObserver(observe);
  resize.observe(topbar);
  return()=>{observer.disconnect();resize.disconnect();};
 },[]);
 const returnFocus=floating?floatingRef:undefined;
 const estimate=readingMinutes||Math.max(1,Math.ceil(count/500))+'–'+Math.max(1,Math.ceil(count/350))+' 分鐘';return <><div className="reader-tools" ref={toolbarRef}><Popover open={activeTool==='settings'} onOpenChange={open=>onToolChange('settings',open)}><PopoverTrigger className="secondary-btn"><SlidersHorizontal size={16}/>閱讀設定</PopoverTrigger><PopoverContent className="reading-settings" align="end" anchor={floating?floatingRef:undefined} finalFocus={returnFocus}><PopoverTitle>閱讀設定</PopoverTitle><PopoverDescription>保留在這個瀏覽器，接著讀也一樣舒適。</PopoverDescription><fieldset><legend>字體大小</legend><RadioGroup value={preferences.size} onValueChange={value=>setPreferences({size:value as Preferences['size']})} className="reading-options">{[['small','小','16'],['medium','中','18'],['large','大','22']].map(([value,label,size])=><label key={value} className={preferences.size===value?'chosen':''}><RadioGroupItem value={value}/><span style={{fontSize:size+'px'}}>{label}</span>{value==='medium'&&<small>原始</small>}</label>)}</RadioGroup></fieldset><fieldset><legend>字型</legend><Select value={preferences.font} items={fonts} onValueChange={v=>v&&setPreferences({font:v as Preferences['font']})}><SelectTrigger className="editor-select" aria-label="閱讀字型"><SelectValue/></SelectTrigger><SelectContent>{fonts.map(f=><SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent></Select><small className="font-fallback-note">字型依裝置支援顯示相近字型。</small></fieldset><fieldset><legend>閱讀模式</legend><RadioGroup className="reading-options theme-options" value={preferences.theme} onValueChange={v=>setPreferences({theme:v as Preferences['theme']})}><label className={preferences.theme==='light'?'chosen':''}><RadioGroupItem value="light"/><Sun size={17}/>淺色</label><label className={preferences.theme==='dark'?'chosen':''}><RadioGroupItem value="dark"/><Moon size={17}/>深色</label></RadioGroup></fieldset></PopoverContent></Popover><Dialog open={activeTool==='info'} onOpenChange={open=>onToolChange('info',open)}><DialogTrigger className="secondary-btn"><ClipboardList size={17}/>本章資訊</DialogTrigger><DialogContent className="chapter-info" finalFocus={returnFocus}><DialogTitle>本章資訊</DialogTitle><DialogDescription>{title}</DialogDescription><Protected><section className="chapter-facts"><h3><UsersRound size={17}/>登場人物</h3>{cast.length?<div className="cast-tags">{cast.map((name,i)=><span key={i}>{name}</span>)}</div>:<p className="muted">作者尚未填寫登場人物。</p>}<div className="chapter-stat-grid"><div><h3><Text size={16}/>內文字數</h3><strong>{count.toLocaleString()} <small>字</small></strong></div><div><h3><Clock3 size={16}/>預估閱讀</h3><strong className="time-estimate">{estimate}</strong></div></div><p className="count-note">字數計入標點與英數字元，不含空白、格式標記與註解。</p><h3><ClipboardList size={17}/>本章大綱</h3><p className="chapter-summary">{summary||'作者尚未填寫本章大綱。'}</p></section></Protected></DialogContent></Dialog><button type="button" className="secondary-btn" onClick={session.openBookmark}><Bookmark size={16}/>病歷暫存</button><ReaderPanels chapterId={chapterId} title={title} sections={sections} chapters={chapters} activeTool={activeTool} onToolChange={onToolChange} returnFocus={returnFocus}/></div>
 {floating&&header&&createPortal(<div className="reader-floating-toolbox">
  <DropdownMenu modal={false} open={menuOpen} onOpenChange={setMenuOpen}>
   <DropdownMenuTrigger className="secondary-btn reader-functions-button" ref={floatingRef}><ClipboardList size={16}/>病歷功能<ChevronDown size={14}/></DropdownMenuTrigger>
   <DropdownMenuContent className="reader-functions-menu" align="end" sideOffset={9} finalFocus={activeTool?false:floatingRef}>
    {toolItems.map(({id,label,Icon})=><DropdownMenuItem key={id} onClick={()=>onToolChange(id,true)}><Icon size={17}/>{label}</DropdownMenuItem>)}
    <DropdownMenuItem onClick={session.openBookmark}><Bookmark size={17}/>病歷暫存</DropdownMenuItem>
   </DropdownMenuContent>
  </DropdownMenu>
 </div>,header)}
 </>;
}
