'use client';

import type { NovelDoc } from '@/lib/content';
import { isBonusChapter } from '@/lib/story-access';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from './ui/accordion';
import { ChevronRight, LockKeyhole } from 'lucide-react';
import Prose from './prose';

export default function VolumeDirectory({ volumes, chapters }: { volumes: NovelDoc[]; chapters: NovelDoc[] }) {
  return <Accordion multiple defaultValue={[]} className="volume-directory">
    {volumes.map(volume => {
      const entries = chapters.filter(chapter => chapter.volume === volume.id);
      return <AccordionItem key={volume.id} value={volume.id} className="panel volume-index">
        <AccordionTrigger className="volume-toggle">
          <span className="volume-index-no mono">{volume.volumeType === 'bonus' ? '番外篇' : 'VOL. ' + String(volume.order).padStart(2, '0')}</span>
          <span className="volume-toggle-title">{volume.title}</span>
          {volume.locked && <span className="volume-lock"><LockKeyhole size={16}/><span>住院醫師以上</span></span>}
        </AccordionTrigger>
        <AccordionContent className="volume-expanded">
          <div className="volume-overview">
            {volume.subtitle && <p className="muted mono volume-subtitle">{volume.subtitle}</p>}
            {volume.image && <figure className="volume-cover"><img src={volume.image} alt={volume.title + ' · 完整封面'} loading="lazy"/></figure>}
            {volume.body && <div className="volume-description"><Prose text={volume.body} notes={volume.notes}/></div>}
            {volume.volumeType === 'bonus' && <p className="volume-access-note">番外篇 · 角色日常與個人故事 · 住院醫師以上可讀</p>}
          </div>
          <div className="chapter-table">
            {entries.map(chapter => <a href={'/read/' + chapter.id} key={chapter.id}>
              <span className="log-tag">{/^\d+$/.test(chapter.chapterLabel || '') ? 'Log ' + chapter.chapterLabel : chapter.chapterLabel || '—'}</span>
              <span className="chapter-entry-title"><small>{chapter.subtitle}</small><strong>{chapter.title}</strong></span>
              <span className={'badge ' + (chapter.locked ? 'warning' : '')}>{chapter.locked ? <><LockKeyhole size={13}/>住院醫師以上</> : isBonusChapter(chapter, volumes) ? '番外篇' : '可閱覽'}</span>
              <ChevronRight size={17}/>
            </a>)}
          </div>
          {!entries.length && <p className="empty-state">本卷尚未刊載章節。</p>}
        </AccordionContent>
      </AccordionItem>;
    })}
  </Accordion>;
}
