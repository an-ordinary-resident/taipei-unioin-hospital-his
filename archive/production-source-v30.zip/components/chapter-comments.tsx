'use client';
import { useEffect,useRef,useState,type RefObject } from 'react';
import { Dialog,DialogTrigger,DialogContent,DialogTitle,DialogDescription } from './ui/dialog';
import { AlertDialog,AlertDialogContent,AlertDialogTitle,AlertDialogDescription,AlertDialogAction,AlertDialogCancel } from './ui/alert-dialog';
import Choice from './editor-choice';
import type { CommentKind,PublicComment } from '@/lib/comment-policy';
import { MessagesSquare,Pencil,Trash2,ExternalLink,Send,RefreshCw } from 'lucide-react';

const filters=[{value:'all',label:'全部'},{value:'author',label:'作者評論'},{value:'visitor',label:'訪客留言'},{value:'reference',label:'參考資料'}];
type Result={comments:PublicComment[];nextCursor:number|null;isAuthor:boolean;name:string;error?:string};
export default function ChapterComments({chapterId,title,open,onOpenChange,returnFocus}:{chapterId:string;title:string;open:boolean;onOpenChange:(open:boolean)=>void;returnFocus?:RefObject<HTMLButtonElement|null>}){
 const [filter,setFilter]=useState('all'),[rows,setRows]=useState<PublicComment[]>([]),[next,setNext]=useState<number|null>(null);
 const [loading,setLoading]=useState(false),[ready,setReady]=useState(false),[busy,setBusy]=useState(false),[author,setAuthor]=useState(false);
 const [name,setName]=useState('VISITOR-001'),[kind,setKind]=useState<CommentKind>('visitor'),[body,setBody]=useState(''),[url,setUrl]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [editing,setEditing]=useState<PublicComment|null>(null),[deleting,setDeleting]=useState<PublicComment|null>(null);
 const requestNumber=useRef(0);
 async function load(before?:number){
  const request=++requestNumber.current;setLoading(true);setError('');
  try{
   const response=await fetch('/api/chapter-comments?'+new URLSearchParams({chapterId,kind:filter,...(before?{before:String(before)}:{})}),{cache:'no-store'});
   const data=await response.json() as Result;
   if(!response.ok)throw Error(data.error||'留言暫時無法載入。');
   if(request!==requestNumber.current)return;
   setRows(previous=>before?[...previous,...data.comments.filter(c=>!previous.some(r=>r.id===c.id))]:data.comments);setNext(data.nextCursor);setAuthor(data.isAuthor);setReady(true);
   if(!ready){setName(data.name);setKind(data.isAuthor?'author':'visitor');}
  }catch(e){if(request===requestNumber.current)setError(e instanceof Error?e.message:'留言暫時無法載入。');}
  finally{if(request===requestNumber.current)setLoading(false);}
 }
 useEffect(()=>{if(open){setRows([]);setNext(null);void load();}return()=>{requestNumber.current++;};},[open,filter,chapterId]);
 function edit(comment:PublicComment){setEditing(comment);setBody(comment.body);setUrl(comment.url);setKind(comment.kind);setError('');setNotice('');}
 function cancel(){setEditing(null);setBody('');setUrl('');setKind(author?'author':'visitor');}
 async function mutate(action:'create'|'update'|'delete',comment?:PublicComment){
  if(busy)return;setBusy(true);setError('');setNotice('');
  try{
   const response=await fetch('/api/chapter-comments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,chapterId,id:comment?.id,revision:comment?.revision,name:editing?.name||name,kind,body,url})});
   const data=await response.json() as {error?:string};
   if(!response.ok)throw Error(data.error||'留言未能儲存。');
   if(action!=='delete'||editing?.id===comment?.id)cancel();
   setDeleting(null);setNotice(action==='delete'?'留言已刪除。':action==='update'?'留言已更新。':'留言已送出。');await load();
  }catch(e){setError(e instanceof Error?e.message:'留言未能儲存，請稍後再試。');}
  finally{setBusy(false);}
 }
 return <><Dialog open={open} onOpenChange={value=>!busy&&onOpenChange(value)}><DialogTrigger className="secondary-btn"><MessagesSquare size={17}/>病歷評論</DialogTrigger><DialogContent className="reader-tool-dialog comments-dialog" finalFocus={returnFocus}><div className="reader-panel-header"><DialogTitle>病歷評論</DialogTitle><DialogDescription>{title}</DialogDescription></div>
  <div className="comment-filters" role="group" aria-label="評論分類">{filters.map(item=><button type="button" key={item.value} disabled={busy} aria-pressed={filter===item.value} onClick={()=>setFilter(item.value)}>{item.label}</button>)}</div>
  <div className="comment-list" aria-busy={loading}>
   {rows.map(comment=><article className="comment-card" key={comment.id}><div className="comment-byline"><strong>{comment.name}</strong><span className={'badge comment-kind-'+comment.kind}>{filters.find(f=>f.value===comment.kind)?.label}</span><time dateTime={comment.created_at}>{new Intl.DateTimeFormat('zh-TW',{dateStyle:'short',timeStyle:'short',timeZone:'Asia/Taipei'}).format(new Date(comment.created_at))}</time></div><p>{comment.body}</p>{comment.url&&<a className="comment-source" href={comment.url} target="_blank" rel="noopener noreferrer">參考連結 <ExternalLink size={14}/></a>}<div className="comment-footer">{comment.revision>1&&<small>{comment.edited_by_author?'作者已編輯':'已編輯'}</small>}{comment.canEdit&&<div className="button-row"><button type="button" disabled={busy} className="text-btn" onClick={()=>edit(comment)} aria-label={'編輯留言 '+comment.id}><Pencil size={14}/>編輯</button><button type="button" disabled={busy} className="text-btn danger" onClick={()=>setDeleting(comment)} aria-label={'刪除留言 '+comment.id}><Trash2 size={14}/>刪除</button></div>}</div></article>)}
   {loading&&<p className="muted" role="status">載入留言中…</p>}
   {!loading&&!rows.length&&!error&&<p className="comment-empty">此分類目前還沒有留言。</p>}
   {next&&<button type="button" className="secondary-btn" disabled={loading||busy} onClick={()=>load(next)}>載入更多留言</button>}
  </div>
  <form className="comment-form" onSubmit={e=>{e.preventDefault();void mutate(editing?'update':'create',editing||undefined);}}><h3>{editing?'編輯留言':'留下病歷評論'}</h3><fieldset disabled={!ready||loading||busy}>
   <div className="comment-form-meta">{editing?<p className="muted">留言者：{editing.name}</p>:<label>顯示名稱<input aria-label="留言顯示名稱" value={name} onChange={e=>setName(e.target.value)} maxLength={80} required disabled={author}/></label>}{author&&(!editing||editing.kind!=='visitor')&&<label>刊登類別<Choice label="評論刊登類別" value={kind} onChange={v=>setKind(v as CommentKind)} items={[{value:'author',label:'作者評論'},{value:'reference',label:'參考資料'}]}/></label>}</div>
   <label className="sr-only" htmlFor={'comment-body-'+chapterId}>留言內容</label><textarea id={'comment-body-'+chapterId} value={body} onChange={e=>setBody(e.target.value)} maxLength={5000} rows={4} required placeholder="分享對本章的想法…"/>
   {(author||!!url)&&<label>參考網址{kind==='reference'?'（必填）':'（選填）'}<input type="url" value={url} onChange={e=>setUrl(e.target.value)} maxLength={2048} placeholder="https://…" required={kind==='reference'}/></label>}
   <div className="comment-form-footer"><small>{body.length.toLocaleString()} / 5,000</small><div className="button-row">{editing&&<button type="button" className="secondary-btn" onClick={cancel}>取消編輯</button>}<button type="submit" className="primary-btn"><Send size={15}/>{busy?'儲存中…':editing?'更新留言':'送出留言'}</button></div></div>
  </fieldset><p className="comment-ownership">{author?'作者可編輯或刪除本章留言，並刊登評論與參考資料。':'訪客可在此瀏覽器修改或刪除自己的留言。'}</p></form>
  {notice&&<p className="editor-message" role="status">{notice}</p>}{error&&<div className="editor-message is-error" role="alert">{error}<button type="button" disabled={busy||loading} className="text-btn" onClick={()=>load()}><RefreshCw size={14}/>重新載入留言</button></div>}
 </DialogContent></Dialog><AlertDialog open={!!deleting} onOpenChange={value=>!value&&!busy&&setDeleting(null)}><AlertDialogContent><AlertDialogTitle>刪除這則留言？</AlertDialogTitle><AlertDialogDescription>刪除後這則留言會從本章評論中移除。</AlertDialogDescription><div className="button-row"><AlertDialogCancel disabled={busy}>保留</AlertDialogCancel><AlertDialogAction disabled={busy} onClick={e=>{e.preventDefault();if(deleting)void mutate('delete',deleting);}}>刪除留言</AlertDialogAction></div></AlertDialogContent></AlertDialog></>;
}
