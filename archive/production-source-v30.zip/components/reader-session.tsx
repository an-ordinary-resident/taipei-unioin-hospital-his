'use client';
import { useTourDismiss } from './tour-events';
import { createContext,useContext,useEffect,useRef,useState,type ReactNode } from 'react';
import { Bookmark,Heart,Eye,MessagesSquare,Share2,Copy } from 'lucide-react';
import { Dialog,DialogContent,DialogTitle,DialogDescription } from './ui/dialog';
import { readerHistory,readerMutation } from '@/lib/reader-client';
import ReadingProgress from './reading-progress';
import { tourPreviewActive } from '@/lib/reader-tour';
import type { ReadingPoint,ChapterStats } from '@/lib/reading-history';
import { currentReadingPosition } from '@/lib/reading-position';
type Session={openBookmark:()=>void;stats:ChapterStats|null;busy:boolean;like:()=>void;share:()=>void;comments:()=>void;error:string};
const Context=createContext<Session|null>(null);
export function useReaderSession(){const value=useContext(Context);if(!value)throw Error('ReaderSession missing');return value;}
function currentPoint(chapterId:string):ReadingPoint{
 const {blocks,index,offset,percent}=currentReadingPosition();
 return {chapterId,block:blocks[index]?.dataset.readerBlock||null,offset,percent,updatedAt:Date.now()};
}
export default function ReaderSession({chapterId,title,children}:{chapterId:string;title:string;children:ReactNode}){
 const [stats,setStats]=useState<ChapterStats|null>(null),[bookmark,setBookmark]=useState<ReadingPoint|null>(null),[bookmarkOpen,setBookmarkOpen]=useState(false),[shareOpen,setShareOpen]=useState(false),[ready,setReady]=useState(false),[busy,setBusy]=useState(false),[message,setMessage]=useState(''),[error,setError]=useState('');
 const point=useRef<ReadingPoint|null>(null),sessionReady=useRef(false);
 useTourDismiss(()=>{setBookmarkOpen(false);setShareOpen(false);});
 useEffect(()=>{
  let active=true,started=false,timer:ReturnType<typeof setTimeout>|undefined,frame=0,lastSent=0,lastSignature='',userMoved=false;
  const moved=()=>{userMoved=true;};window.addEventListener('wheel',moved,{passive:true});window.addEventListener('touchstart',moved,{passive:true});window.addEventListener('keydown',moved);
  async function flush(keepalive=false){
   if(tourPreviewActive()||!sessionReady.current||!point.current)return;const p=point.current,signature=p.block+':'+p.offset.toFixed(3);
   if(signature===lastSignature)return;lastSignature=signature;lastSent=Date.now();
   try{await readerMutation({action:'progress',chapterId,point:p},true);}catch(e){lastSignature='';if(active)setError(e instanceof Error?e.message:'續讀位置暫時無法儲存。');}
  }
  function capture(){if(tourPreviewActive()||!sessionReady.current||document.visibilityState!=='visible')return;point.current=currentPoint(chapterId);if(!timer)timer=setTimeout(()=>{timer=undefined;void flush();},Math.max(600,10000-(Date.now()-lastSent)));}
  function scroll(){cancelAnimationFrame(frame);frame=requestAnimationFrame(capture);}
  async function start(){
   if(started||document.visibilityState!=='visible')return;started=true;
   try{
    const history=await readerHistory(true);if(!active)return;setBookmark(history.bookmark);
    if(tourPreviewActive()){setReady(true);return;}
    const source=new URLSearchParams(location.search).get('resume'),saved=source==='bookmark'?history.bookmark:source==='last'?history.lastRead:null;
    if(saved?.chapterId===chapterId){
     await Promise.race([Promise.allSettled([document.fonts.ready,...Array.from(document.querySelectorAll<HTMLImageElement>('.reader-paper img')).map(img=>img.decode())]),new Promise(resolve=>setTimeout(resolve,2000))]);
     await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
     if(!active)return;
     if(!userMoved){
      const node=Array.from(document.querySelectorAll<HTMLElement>('.reader-paper [data-reader-block]')).find(n=>n.dataset.readerBlock===saved.block);
      if(node){const rect=node.getBoundingClientRect(),header=document.querySelector('.topbar')?.getBoundingClientRect().bottom||0;window.scrollTo({top:Math.max(0,scrollY+rect.top+rect.height*saved.offset-header-24),behavior:'instant'});}
      else setMessage('本章段落已更新，已回到章節開頭。');
     }
    }
    if(!active)return;sessionReady.current=true;setReady(true);capture();
    const data=await readerMutation({action:'view',chapterId});if(active&&data.stats)setStats(data.stats);
   }catch(e){if(active){setError(e instanceof Error?e.message:'閱讀紀錄暫時無法載入。');started=false;}}
  }
  function visibility(){if(document.visibilityState==='hidden'){if(sessionReady.current)point.current=currentPoint(chapterId);void flush(true);}else void start();}
  function leave(){if(sessionReady.current)point.current=currentPoint(chapterId);void flush(true);}
  window.addEventListener('scroll',scroll,{passive:true});window.addEventListener('pagehide',leave);document.addEventListener('visibilitychange',visibility);void start();
  return()=>{active=false;clearTimeout(timer);cancelAnimationFrame(frame);void flush(true);sessionReady.current=false;window.removeEventListener('scroll',scroll);window.removeEventListener('pagehide',leave);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('wheel',moved);window.removeEventListener('touchstart',moved);window.removeEventListener('keydown',moved);};
 },[chapterId]);
 async function saveBookmark(clear=false){
  if(busy||!ready)return;setBusy(true);setError('');setMessage('');
  try{const p=currentPoint(chapterId);await readerMutation(clear?{action:'clear-bookmark'}:{action:'bookmark',chapterId,point:p});setBookmark(clear?null:p);setMessage(clear?'已移除書籤，首頁將改為呈現上次閱讀。':'已暫存目前段落，回到首頁即可繼續閱讀。');}catch(e){setError(e instanceof Error?e.message:'書籤未能儲存。');}finally{setBusy(false);}
 }
 async function like(){if(busy||!ready)return;setBusy(true);setError('');try{const data=await readerMutation({action:'like',chapterId,liked:!stats?.liked});if(data.stats)setStats(data.stats);}catch(e){setError(e instanceof Error?e.message:'按讚未能儲存。');}finally{setBusy(false);}}
 const shareUrl=typeof window==='undefined'?'':window.location.origin+'/read/'+chapterId;
 async function copyShare(){try{await navigator.clipboard.writeText(shareUrl);setMessage('已複製本章連結。');setError('');}catch{setError('請選取下方網址後手動複製。');}}
 async function share(){setError('');setMessage('');if(navigator.share){try{await navigator.share({title,url:shareUrl});return;}catch(e){if(e instanceof Error&&e.name==='AbortError')return;}}setShareOpen(true);}
 const context:Session={openBookmark:()=>{setMessage('');setBookmarkOpen(true);},stats,busy:busy||!ready||!stats,like:()=>void like(),share:()=>void share(),comments:()=>window.dispatchEvent(new CustomEvent('his-open-comments',{detail:chapterId})),error};
 return <Context.Provider value={context}>{children}<ReadingProgress/><Dialog open={bookmarkOpen} onOpenChange={value=>!busy&&setBookmarkOpen(value)}><DialogContent className="reader-tool-dialog bookmark-dialog"><div className="reader-panel-header"><DialogTitle>病歷暫存</DialogTitle><DialogDescription>{title}</DialogDescription></div><p>儲存目前閱讀的段落，首頁會優先顯示這個書籤。新的暫存會取代原有書籤。</p>{bookmark?.chapterId===chapterId&&<p className="bookmark-position"><Bookmark size={17}/>本章已暫存位置：約 {Math.round(bookmark.percent)}%</p>}<div className="button-row"><button type="button" className="primary-btn" disabled={!ready||busy} onClick={()=>void saveBookmark()}><Bookmark size={16}/>{busy?'儲存中…':bookmark?'更新為目前段落':'暫存目前段落'}</button>{bookmark&&<button type="button" className="secondary-btn" disabled={!ready||busy} onClick={()=>void saveBookmark(true)}>移除書籤</button>}</div><p className="config-help">書籤與續讀以此瀏覽器 Cookie 識別；更換瀏覽器或清除 Cookie 後會使用新的紀錄。</p>{message&&<p role="status" className="editor-message">{message}</p>}{error&&<p role="alert" className="editor-message is-error">{error}</p>}</DialogContent></Dialog><Dialog open={shareOpen} onOpenChange={setShareOpen}><DialogContent className="reader-tool-dialog share-dialog"><div className="reader-panel-header"><DialogTitle>分享這份病歷</DialogTitle><DialogDescription>{title}</DialogDescription></div><input aria-label="章節分享網址" value={shareUrl} readOnly onFocus={e=>e.target.select()}/><button type="button" className="primary-btn" onClick={()=>void copyShare()}><Copy size={16}/>複製連結</button>{message&&<p role="status">{message}</p>}{error&&<p role="alert">{error}</p>}</DialogContent></Dialog></Context.Provider>;
}
export function ReaderActions(){const session=useReaderSession();return <section className="reader-actions" aria-label="讀後互動"><div className="reader-engagement"><span><Eye size={16}/>{session.stats?session.stats.views.toLocaleString():'—'} 次閱覽</span><span><Heart size={16}/>{session.stats?session.stats.likes.toLocaleString():'—'} 個喜歡</span></div><div className="reader-action-buttons"><button type="button" className="secondary-btn" onClick={session.comments}><MessagesSquare size={17}/>留言</button><button type="button" className="secondary-btn like-button" disabled={session.busy} aria-pressed={!!session.stats?.liked} onClick={session.like}><Heart size={17} fill={session.stats?.liked?'currentColor':'none'}/>{session.stats?.liked?'已按讚':'按讚'}</button><button type="button" className="secondary-btn" onClick={session.share}><Share2 size={17}/>分享</button></div>{session.error&&<p className="editor-message is-error" role="alert">{session.error}<button type="button" className="text-btn" onClick={()=>location.reload()}>重新載入</button></p>}</section>;}
