import Prose from './prose';
import type { Annotation } from '@/lib/rich-text';
import type { ProfileSection } from '@/lib/content';

const TEMPLATE=['人物簡介','基本資料','外觀特徵','人物特質','喜好與習慣','角色語錄'];

export function ProfileSections({sections,notes=[]}:{sections?:ProfileSection[];notes?:Annotation[]}){
 const byTitle=new Map((sections||[]).map(section=>[section.title,section.body]));
 return <div className="profile-sections">{TEMPLATE.map(title=><section className="profile-section" key={title}><h3>{title}</h3>{byTitle.get(title)?<Prose text={byTitle.get(title)!} notes={notes}/>:<p className="profile-pending">此段設定尚待作者建檔。</p>}</section>)}</div>;
}

export function ConfidentialDossier({text,notes=[]}:{text?:string;notes?:Annotation[]}){
 if(!text)return <p className="profile-pending">機密檔案尚待作者建檔。</p>;
 const parts=text.split(/\s*▎(?=[^\s])/).map(part=>part.trim()).filter(Boolean);
 return <div className="confidential-dossier">{parts.map((part,index)=>{const space=part.indexOf(' ');const title=space>0?part.slice(0,space):'機密紀錄';const body=space>0?part.slice(space+1):part;return <section className="case-file-section" key={index}><h3>{title}</h3><Prose text={body} notes={notes}/></section>})}</div>;
}
