'use client';
import { useEffect,useId,useLayoutEffect,useMemo,useRef,useState } from 'react';
import { EditorContent,useEditor } from '@tiptap/react';
import { Slice } from '@tiptap/pm/model';
import { TextSelection,type Transaction } from '@tiptap/pm/state';
import { closeHistory } from '@tiptap/pm/history';
import type { JSONContent } from '@tiptap/core';
import { reorderAnnotations,removeAnnotation } from '@/lib/annotation-order';
import { Popover,PopoverTrigger,PopoverContent,PopoverTitle } from '@/components/ui/popover';
import { Dialog,DialogContent,DialogTitle,DialogDescription } from '@/components/ui/dialog';
import { AlertDialog,AlertDialogContent,AlertDialogTitle,AlertDialogDescription,AlertDialogAction,AlertDialogCancel } from '@/components/ui/alert-dialog';
import { INKS,parseAnnotatedText,plainText,safeLink,type Annotation } from '@/lib/rich-text';
import { editorDocument,storedProse } from '@/lib/editor-document';
import GlossaryList from '@/components/glossary-list';
import { normalizeTerm,type GlossaryTerm } from '@/lib/glossary';
import TermTagEditor from '@/components/term-tags';
import { EDITOR_SYMBOLS } from '@/lib/editor-symbols';
import { proseEditorExtensions } from '@/lib/editor-extensions';
import { Bold,Italic,Strikethrough,Underline,Heading,Link,Minus,List,Palette,MessageSquarePlus,Pencil,Plus,Trash2,ScanText,ArrowUp,ArrowDown,ListOrdered,AlignLeft,AlignCenter,AlignRight,Smile,BookOpen,Save,EyeOff,Unlink,Send,RefreshCw } from 'lucide-react';

const EMPTY_NOTES:Annotation[]=[];
type Patch={body?:string;notes?:Annotation[]};
export default function FormatEditor({body,notes,onChange,disabled=false,annotationTools=true,maxLength=250000}:{body:string;notes:Annotation[];onChange:(patch:Patch)=>void;disabled?:boolean;annotationTools?:boolean;maxLength?:number}){
 const editorId=useId(), selection=useRef({from:1,to:1}), lastBody=useRef(body), lastNotes=useRef(notes);
 const changeRef=useRef(onChange);
 useLayoutEffect(()=>{changeRef.current=onChange;},[onChange]);
 const [colorOpen,setColorOpen]=useState(false),[headingOpen,setHeadingOpen]=useState(false),[noteOpen,setNoteOpen]=useState(false),[term,setTerm]=useState(''),[explanation,setExplanation]=useState(''),[editingId,setEditingId]=useState<number|null>(null),[deleting,setDeleting]=useState<Annotation|null>(null),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const [linkOpen,setLinkOpen]=useState(false),[linkText,setLinkText]=useState(''),[linkUrl,setLinkUrl]=useState(''),[linkError,setLinkError]=useState('');
 const [symbolsOpen,setSymbolsOpen]=useState(false),[libraryOpen,setLibraryOpen]=useState(false),[libraryBusy,setLibraryBusy]=useState(false),[libraryMessage,setLibraryMessage]=useState('');
 const [shared,setShared]=useState<GlossaryTerm|null>(null),[sharedId,setSharedId]=useState<string|undefined>(),[sharedLoading,setSharedLoading]=useState(false);
 const noteRequest=useRef(0);
 const [tags,setTags]=useState<string[]>([]);
 const [initialContent]=useState(()=>({...editorDocument(body),attrs:{annotations:notes}}));
 const extensions=useMemo(()=>proseEditorExtensions(()=>setNotice('內容上限為 '+maxLength.toLocaleString()+' 字元，這次輸入未加入內文。'),maxLength),[maxLength]);
 const editor=useEditor({
  immediatelyRender:false, shouldRerenderOnTransaction:true,
  extensions, content:initialContent, editable:!disabled,
  editorProps:{
   attributes:{id:editorId,role:'textbox','aria-label':annotationTools?'作品內文':'註解內容','aria-multiline':'true',class:'body-editor visual-editor'},
   handleDOMEvents:{
    click:(_view,event)=>openReference(event.target),
    keydown:(_view,event)=>{if((event.key==='Enter'||event.key===' ')&&(event.target as Element).matches('[data-annotation-id]')){event.preventDefault();return openReference(event.target);}return false;},
   },
   handlePaste:(view,event)=>{
    const plain=event.clipboardData?.getData('text/plain');
    if(event.clipboardData?.getData('text/html')||!plain)return false;
    const doc=view.state.schema.nodeFromJSON(editorDocument(plain));
    view.dispatch(view.state.tr.replaceSelection(Slice.maxOpen(doc.content)).scrollIntoView());return true;
   },
   transformPasted:(slice,view)=>{
    const content=editorDocument(storedProse({type:'doc',content:slice.content.toJSON()}));
    return Slice.maxOpen(view.state.schema.nodeFromJSON(content).content);
   },
  },
  onUpdate:({editor:active})=>{const value=storedProse(active.getJSON()),updated=active.state.doc.attrs.annotations as Annotation[];lastBody.current=value;lastNotes.current=updated;changeRef.current({body:value,notes:updated});},
  onSelectionUpdate:({editor:active})=>{selection.current={from:active.state.selection.from,to:active.state.selection.to};},
 });
 useEffect(()=>{if(editor&&(body!==lastBody.current||notes!==lastNotes.current)){lastBody.current=body;lastNotes.current=notes;const doc=editor.schema.nodeFromJSON(editorDocument(body));editor.view.dispatch(editor.state.tr.replaceWith(0,editor.state.doc.content.size,doc.content).setDocAttribute('annotations',notes).setMeta('preventUpdate',true).setMeta('addToHistory',false));selection.current={from:editor.state.selection.from,to:editor.state.selection.to};}},[body,notes,editor]);
 useEffect(()=>{editor?.setEditable(!disabled,false);},[disabled,editor]);
 function commitNotes(tr:Transaction,updated:Annotation[]){
  if(!editor||disabled)return;
  editor.view.dispatch(closeHistory(tr.setDocAttribute('annotations',updated)));
  editor.view.dispatch(closeHistory(editor.state.tr));
 }
 function replaceNotes(doc:JSONContent,updated:Annotation[]){
  if(!editor||disabled)return;
  const next=editor.schema.nodeFromJSON(doc),tr=editor.state.tr.replaceWith(0,editor.state.doc.content.size,next.content);
  tr.setSelection(TextSelection.near(tr.doc.resolve(Math.min(selection.current.to,tr.doc.content.size))));
  commitNotes(tr,updated);
 }
 function sortNotes(order?:number[]){
  if(!editor||disabled)return;
  try{const result=reorderAnnotations(editor.getJSON(),notes,order);replaceNotes(result.doc,result.notes);setNotice(order?'已調整註釋順序，內文標號同步更新。':'已依內文出現順序編號，未插入內文的註解保留在末尾。');}
  catch(error){setNotice(error instanceof Error?error.message:'註解排序未完成。');}
 }
 function moveNote(index:number,direction:number){
  const order=notes.map(note=>note.id),target=index+direction;
  if(target<0||target>=order.length)return;
  [order[index],order[target]]=[order[target],order[index]];sortNotes(order);
 }
 function capture(){if(editor)selection.current={from:editor.state.selection.from,to:editor.state.selection.to};}
 function chain(){return editor?.chain().focus().setTextSelection(selection.current);}
 function newNote(){noteRequest.current++;setShared(null);setSharedId(undefined);setSharedLoading(false);setTags([]);setLibraryOpen(false);setLibraryMessage('');capture();const {from,to}=selection.current;setEditingId(null);setTerm(editor?.state.doc.textBetween(from,to,' ').trim().slice(0,200)||'');setExplanation('');setError('');setNoteOpen(true);}
 function editNote(note:Annotation){noteRequest.current++;setShared(null);setSharedId(note.glossaryId);setSharedLoading(false);setTags(note.tags||[]);setLibraryOpen(false);setLibraryMessage('');capture();setEditingId(note.id);setTerm(note.term);setExplanation(note.text);setError('');setNoteOpen(true);if(note.glossaryId)void loadShared(note.glossaryId);}
 async function loadShared(id:string){
  const request=++noteRequest.current;setSharedLoading(true);setError('');
  try{const response=await fetch('/api/glossary?'+new URLSearchParams({scope:'author',id}),{cache:'no-store'});const data=await response.json() as {term:GlossaryTerm;error?:string};if(!response.ok)throw Error(data.error||'無法載入共用詞條。');if(request!==noteRequest.current)return;setShared(data.term);setTerm(data.term.term);setExplanation(data.term.text);setTags(data.term.tags);}
  catch(e){if(request===noteRequest.current)setError(e instanceof Error?e.message:'無法載入共用詞條，請重試。');}
  finally{if(request===noteRequest.current)setSharedLoading(false);}
 }
 function selectShared(entry:GlossaryTerm){noteRequest.current++;setSharedId(entry.id);setShared(entry);setTerm(entry.term);setExplanation(entry.text);setTags(entry.tags);setLibraryOpen(false);setError('');setLibraryMessage('已選取共用詞條。套用後請儲存或刊載章節以保留連結；專用吐槽可先解除連結。');void loadShared(entry.id);}
 function detachShared(){noteRequest.current++;setShared(null);setSharedId(undefined);setSharedLoading(false);setError('');setLibraryMessage('已解除連結，保留目前解說供本章獨立編輯。請更新註解並儲存或刊載章節。');}
 function sharedNote(entry:GlossaryTerm){return {term:entry.term,text:entry.text,tags:entry.tags,glossaryId:entry.id,glossaryRevision:entry.revision,glossaryPublished:entry.isPublished,glossaryHasDraft:entry.hasDraft};}
 function sharedChanged(){return !!shared&&(term.trim()!==shared.term||explanation.trim()!==shared.text||JSON.stringify(tags)!==JSON.stringify(shared.tags));}
 function openReference(target:EventTarget|null){if(!annotationTools||disabled||!(target instanceof Element))return false;const ref=target.closest('[data-annotation-id]');if(!ref)return false;const note=notes.find(n=>n.id===Number(ref.getAttribute('data-annotation-id')));if(!note)return false;editNote(note);return true;}
 async function saveNote(){
  if(disabled||!editor||libraryBusy||sharedLoading)return;
  if(sharedId&&!shared){setError('請先重新載入共用詞條，或解除連結。');return;}
  if(!term.trim()||!explanation.trim()){setError('請填寫專有名詞與解說。');return;}
  const reused=editingId===null?notes.find(n=>n.glossaryId===sharedId&&normalizeTerm(n.term)===normalizeTerm(term)&&n.text.trim()===explanation.trim()&&JSON.stringify(n.tags||[])===JSON.stringify(tags)):undefined;
  if(notes.length>=200&&editingId===null&&!reused){setError('每篇最多 200 則註解。');return;}
  const id=editingId??reused?.id??Math.max(0,...notes.map(n=>n.id))+1;
  if(id>999){setError('註解編號上限為 999。');return;}
  let entry=shared;if(entry&&sharedChanged()){entry=await saveToLibrary('draft');if(!entry)return;}
  const value=entry?sharedNote(entry):{term:term.trim(),text:explanation.trim(),tags};
  const updated=[...notes.filter(n=>n.id!==id).map(n=>entry&&n.glossaryId===entry.id?{...n,...sharedNote(entry)}:n),{id,...value}].sort((a,b)=>a.id-b.id);
  if(editingId===null){
   commitNotes(editor.state.tr.insert(selection.current.to,editor.schema.nodes.annotation.create({id})),updated);
  }else commitNotes(editor.state.tr,updated);
  setNoteOpen(false);
 }
 async function saveToLibrary(action:'draft'|'publish'='draft'):Promise<GlossaryTerm|null>{
  if(libraryBusy||disabled||sharedLoading)return null;
  if(sharedId&&!shared){setError('請先重新載入共用詞條，或解除連結。');return null;}
  if(!term.trim()||!explanation.trim()){setError('請先填寫專有名詞與解說。');return null;}
  setLibraryBusy(true);setError('');setLibraryMessage('');
  try{
   const response=await fetch('/api/glossary',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,term:{id:sharedId||crypto.randomUUID(),term:term.trim(),text:explanation.trim(),tags,revision:shared?.revision||0}})});
   const result=await response.json() as {term:GlossaryTerm;error?:string};if(!response.ok)throw Error(result.error||'辭典未能儲存。');
   setSharedId(result.term.id);setShared(result.term);setTerm(result.term.term);setExplanation(result.term.text);setTags(result.term.tags);
   if(editor&&notes.some(n=>n.glossaryId===result.term.id))commitNotes(editor.state.tr,notes.map(n=>n.glossaryId===result.term.id?{...n,...sharedNote(result.term)}:n));
   setLibraryMessage(action==='publish'?'共用詞條已刊登，所有已連結章節於重新載入後同步更新。':'共用草稿已儲存，讀者仍看到上次刊登的解說。');setLibraryOpen(false);return result.term;
  }catch(error){setError(error instanceof Error?error.message:'辭典未能儲存，請重試。');return null;}
  finally{setLibraryBusy(false);}
 }
 async function saveAllNotes(){
  if(libraryBusy||disabled||!notes.length)return;const independent=notes.filter(n=>!n.glossaryId);if(!independent.length){setNotice('這些註釋已連結共用詞條，請直接編輯並儲存共用草稿。');return;}setLibraryBusy(true);setNotice('');
  try{const response=await fetch('/api/glossary/batch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'import-drafts',notes:independent})});const data=await response.json() as {added:number;existing:number;conflicts:string[];error?:string};if(!response.ok)throw Error(data.error||'註釋未能儲存。');setNotice('已新增 '+data.added+' 個辭典草稿；'+data.existing+' 個相同詞條已存在；共用註釋已略過，獨立註釋不會自動建立連結。'+(data.conflicts.length?'以下同名詞條解說不同，已保留原稿，請於辭典確認：'+data.conflicts.join('、')+'。':''));}catch(e){setNotice(e instanceof Error?e.message:'批次儲存失敗，請重試。');}finally{setLibraryBusy(false);}
 }
 function alignText(alignment:'left'|'center'|'right'){
  chain()?.command(({tr})=>{tr.doc.nodesBetween(tr.selection.from,tr.selection.to,(node,pos)=>{if(node.type.name==='paragraph'||node.type.name==='heading')tr.setNodeMarkup(pos,undefined,{...node.attrs,textAlign:alignment});});return true;}).run();
 }
 function insertSymbol(value:string){chain()?.insertContent({type:'text',text:value}).run();setSymbolsOpen(false);}
 function insertNote(id:number){if(!disabled)editor?.chain().focus().setTextSelection(selection.current.to).insertContent({type:'annotation',attrs:{id}}).run();}
 function removeNote(){if(!deleting||disabled||!editor)return;replaceNotes(removeAnnotation(editor.getJSON(),deleting.id),notes.filter(n=>n.id!==deleting.id));setDeleting(null);}
 function importNotes(){const parsed=parseAnnotatedText(body);if(!parsed){setNotice('請貼上包含【故事內文】與【用詞註釋】的全文，並確認每個編號都有解說。');return;}replaceNotes(editorDocument(parsed.body),parsed.notes);setNotice('已辨識 '+parsed.notes.length+' 則註解，可在下方逐則編輯。');}
 function openLink(){if(!editor)return;if(editor.isActive('link'))editor.commands.extendMarkRange('link');capture();const {from,to}=selection.current;setLinkText(editor.state.doc.textBetween(from,to,' '));setLinkUrl(editor.getAttributes('link').href||'');setLinkError('');setLinkOpen(true);}
 function saveLink(){
  if(!editor||disabled)return;const href=safeLink(linkUrl);
  if(!href){setLinkError('請輸入完整的 http://、https:// 或 mailto: 網址。');return;}
  if(!linkText.trim()){setLinkError('請填寫連結顯示文字。');return;}
  const {from,to}=selection.current, original=editor.state.doc.textBetween(from,to,' ');
  if(original===linkText&&from!==to)chain()?.setLink({href}).run();
  else chain()?.insertContent({type:'text',text:linkText,marks:[{type:'link',attrs:{href}}]}).unsetLink().run();
  setLinkOpen(false);
 }
 const hold=(e:React.MouseEvent)=>{e.preventDefault();capture();};
 function applyFormat(mark:string){const action=chain();if(!action)return;switch(mark){case 'spoiler':action.toggleMark('spoiler').run();break;case 'bold':action.toggleBold().run();break;case 'italic':action.toggleItalic().run();break;case 'underline':action.toggleUnderline().run();break;case 'strike':action.toggleStrike().run();break;case 'horizontalRule':action.setHorizontalRule().run();break;case 'bulletList':action.toggleBulletList().run();break;}}
 const formatButtons=[
  {label:'加粗',mark:'bold',Icon:Bold},
  {label:'斜體',mark:'italic',Icon:Italic},
  {label:'底線',mark:'underline',Icon:Underline},
  {label:'刪除線',mark:'strike',Icon:Strikethrough},
  {label:'分隔線',mark:'horizontalRule',Icon:Minus},
  {label:'列點',mark:'bulletList',Icon:List},
  {label:'防劇透黑框',mark:'spoiler',Icon:EyeOff},
 ];
 return <>
  <div className="format-toolbar" role="toolbar" aria-label="內文格式工具">
   <Popover open={headingOpen} onOpenChange={setHeadingOpen}><PopoverTrigger disabled={disabled||!editor} className="format-button" onMouseDown={hold}><Heading size={17}/>標題</PopoverTrigger><PopoverContent className="heading-menu" finalFocus={false}><PopoverTitle>標題大小</PopoverTitle>{([1,2,3] as const).map((level,i)=><button type="button" key={level} className="format-button" aria-pressed={editor?.isActive('heading',{level})||false} onClick={()=>{chain()?.toggleHeading({level}).run();setHeadingOpen(false);}}>{['大標題','中標題','小標題'][i]}</button>)}<button type="button" className="format-button" onClick={()=>{chain()?.setParagraph().run();setHeadingOpen(false);}}>一般內文</button></PopoverContent></Popover>
   {formatButtons.map(({label,mark,Icon})=><button type="button" key={mark} disabled={disabled||!editor} className="format-button" aria-pressed={editor?.isActive(mark)||false} onMouseDown={hold} onClick={()=>applyFormat(mark)}><Icon size={17}/>{label}</button>)}
   <Popover open={colorOpen} onOpenChange={setColorOpen}><PopoverTrigger disabled={disabled||!editor} className="format-button" onMouseDown={hold}><Palette size={17}/>文字顏色</PopoverTrigger><PopoverContent className="color-menu" finalFocus={false}><PopoverTitle>選取文字顏色</PopoverTitle><div className="color-swatches">{INKS.map(ink=><button type="button" key={ink.id} aria-label={ink.name} title={ink.name+' '+ink.hex} aria-pressed={editor?.isActive('textStyle',{color:ink.hex})||false} className={'color-swatch ink-'+ink.id} onClick={()=>{const active=editor?.isActive('textStyle',{color:ink.hex});const action=chain();if(active)action?.unsetColor().run();else action?.setColor(ink.hex).run();setColorOpen(false);}}><span>字</span><small>{ink.name}</small></button>)}</div></PopoverContent></Popover>
   {([{value:'left',label:'置左',Icon:AlignLeft},{value:'center',label:'置中',Icon:AlignCenter},{value:'right',label:'置右',Icon:AlignRight}] as const).map(({value,label,Icon})=><button type="button" key={value} disabled={disabled||!editor} className="format-button" aria-pressed={!!editor?.isActive({textAlign:value})} onMouseDown={hold} onClick={()=>alignText(value)}><Icon size={17}/>{label}</button>)}
   <Popover open={symbolsOpen} onOpenChange={setSymbolsOpen}><PopoverTrigger disabled={disabled||!editor} className="format-button" onMouseDown={hold}><Smile size={17}/>常用符號</PopoverTrigger><PopoverContent className="symbols-menu" finalFocus={false}><PopoverTitle>常用標點符號／顏文字</PopoverTitle><div className="symbols-grid">{EDITOR_SYMBOLS.map(value=><button type="button" key={value} className={value.length>12?'wide':''} onClick={()=>insertSymbol(value)} title={'插入 '+value}>{value}</button>)}</div></PopoverContent></Popover>
   <button type="button" disabled={disabled||!editor} className="format-button" aria-pressed={editor?.isActive('link')||false} onMouseDown={hold} onClick={openLink}><Link size={17}/>超連結</button>
   {annotationTools&&<><button type="button" disabled={disabled||!editor} className="format-button" onMouseDown={hold} onClick={newNote}><MessageSquarePlus size={17}/>插入註解</button>
   <button type="button" disabled={disabled||!editor} className="format-button import-notes-button" onClick={importNotes}><ScanText size={17}/>辨識註解</button></>}
  </div>
  <p className="format-hint">選取文字即可套用格式；防劇透黑框於閱讀時點擊揭露。{annotationTools&&'貼上含【用詞註釋】的全文後，可一鍵辨識註解。'}</p>
  <div className="visual-editor-wrap" data-empty={editor?.isEmpty||undefined}><EditorContent editor={editor}/>{!editor&&<output className="body-editor">載入文字編輯器…</output>}</div>
  {!annotationTools&&notice&&<output className="format-notice" role="status">{notice}</output>}
  {annotationTools&&<><section className="note-manager"><div className="note-manager-heading"><h3>用詞註釋 <span>{notes.length}</span></h3><div className="note-manager-controls"><button type="button" className="text-btn" disabled={disabled||libraryBusy||!notes.length} onClick={()=>void saveAllNotes()}><Save size={16}/>{libraryBusy?'儲存中…':'全部存入辭典草稿'}</button><button type="button" disabled={disabled||!editor||!notes.length} className="text-btn" onClick={()=>sortNotes()}><ListOrdered size={16}/>依內文順序編號</button><button type="button" disabled={disabled||!editor} className="text-btn" onClick={newNote}><Plus size={16}/>新增註解</button></div></div><p className="note-order-hint">使用上下箭頭調整順序，或依內文首次出現的位置編號；標號會同步更新，可使用 Ctrl／⌘ + Z 復原。</p>{notes.length?<ol>{notes.map((note,index)=><li key={note.id}><span className="note-number">[{note.id}]</span><div><strong>{note.term}</strong><span className={'note-link-badge '+(note.glossaryId?'is-shared':'')}>{note.glossaryId?'共用詞條':'本章專用'}</span><p>{plainText(note.text)}</p></div><div className="note-actions"><button type="button" disabled={disabled||!editor||index===0} title="向上移動" aria-label={'向上移動註解 '+note.id} onClick={()=>moveNote(index,-1)}><ArrowUp size={15}/></button><button type="button" disabled={disabled||!editor||index===notes.length-1} title="向下移動" aria-label={'向下移動註解 '+note.id} onClick={()=>moveNote(index,1)}><ArrowDown size={15}/></button><button type="button" disabled={disabled} title="在游標位置插入這則註解" aria-label={'插入註解 '+note.id} onClick={()=>insertNote(note.id)}><Plus size={15}/></button><button type="button" disabled={disabled} aria-label={'編輯註解 '+note.id} onClick={()=>editNote(note)}><Pencil size={15}/></button><button type="button" disabled={disabled} aria-label={'移除註解 '+note.id} onClick={()=>setDeleting(note)}><Trash2 size={15}/></button></div></li>)}</ol>:<p className="note-empty">尚無註解。選取內文中的專有名詞，再按「插入註解」。</p>}{notice&&<output className="format-notice">{notice}</output>}</section>
  <Dialog open={noteOpen} onOpenChange={open=>{if(libraryBusy)return;setNoteOpen(open);if(!open)noteRequest.current++;}}><DialogContent className="note-edit-dialog">
   <DialogTitle>{editingId===null?'新增註解':'編輯註解 ['+editingId+']'}</DialogTitle>
   <DialogDescription>{sharedId?'此註釋連結共用辭庫；刊登詞條後會同步更新所有已連結章節。':'本章專用註釋可獨立編輯；選取辭庫詞條後才會建立共用連結。'}</DialogDescription>
   <div className={'note-link-status '+(sharedId?'is-shared':'')}><div><strong>{sharedId?'共用詞條':'本章專用'}</strong><p>{sharedLoading?'正在取得辭庫最新草稿…':sharedId?shared?.isPublished?shared.hasDraft?'有共用草稿修改，讀者仍看到上次刊登版本。':'目前共用詞條已刊登。':'詞條尚未刊登；章節刊載前須先刊登詞條，或解除連結。':'解說與吐槽僅用於本章，同名辭庫詞條不會覆寫此內容。'}</p></div>{sharedId&&<button type="button" className="secondary-btn" disabled={disabled||libraryBusy} onClick={detachShared}><Unlink size={15}/>解除連結</button>}</div>
   <div className="note-library-tools"><button type="button" className="secondary-btn" disabled={libraryBusy||sharedLoading} onClick={()=>setLibraryOpen(!libraryOpen)}><BookOpen size={16}/>{libraryOpen?'收起辭典':'搜尋並連結詞條'}</button>{sharedId&&<button type="button" className="text-btn" disabled={libraryBusy||sharedLoading} onClick={()=>{if(!sharedChanged()||window.confirm('重新載入會取代此視窗尚未儲存的共用詞條修改。'))void loadShared(sharedId);}}><RefreshCw size={15}/>重新載入詞條</button>}</div>
   {libraryOpen&&<><p className="config-help">選取詞條會以辭庫解說取代目前編輯內容。</p><GlossaryList author initialQuery={term} onSelect={selectShared}/></>}
   {libraryMessage&&<p className="format-notice" role="status">{libraryMessage}</p>}
   <fieldset className="note-definition-fields" disabled={disabled||libraryBusy||sharedLoading||!!sharedId&&!shared}>
    <label>專有名詞<input value={term} maxLength={200} onChange={e=>setTerm(e.target.value)} placeholder="例如：PGY（不分科住院醫師）"/></label>
    <TermTagEditor value={tags} onChange={setTags} disabled={disabled||libraryBusy||sharedLoading||!!sharedId&&!shared}/>
    <div className="definition-editor"><h3>註解內容</h3><FormatEditor key={String(editingId)} body={explanation} notes={EMPTY_NOTES} annotationTools={false} maxLength={6000} disabled={disabled||libraryBusy||sharedLoading||!!sharedId&&!shared} onChange={p=>{if(p.body!==undefined)setExplanation(p.body);}}/></div>
   </fieldset>
   {error&&<p className="form-error" role="alert">{error}</p>}
   <div className="note-shared-actions"><button type="button" className="secondary-btn" disabled={disabled||libraryBusy||sharedLoading||!!sharedId&&!shared} onClick={()=>void saveToLibrary('draft')}><Save size={15}/>{libraryBusy?'處理中…':sharedId?'儲存共用草稿':'新增共用詞條草稿'}</button>{sharedId&&<button type="button" className="secondary-btn" disabled={disabled||libraryBusy||sharedLoading||!shared} onClick={()=>void saveToLibrary('publish')}><Send size={15}/>刊登詞條並同步所有連結</button>}</div>
   <button type="button" disabled={disabled||libraryBusy||sharedLoading||!!sharedId&&!shared} className="primary-btn" onClick={()=>void saveNote()}>{sharedId?'儲存共用草稿並套用至本章':editingId===null?'插入編號與註解':'更新本章專用註解'}</button>
   <p className="config-help">套用或解除連結後，仍須儲存／刊載章節。章節刊載只採用共用詞條的已刊登版本，不會代為刊登詞條草稿。</p>
  </DialogContent></Dialog></>}
  <Dialog open={linkOpen} onOpenChange={setLinkOpen}><DialogContent className="note-edit-dialog"><DialogTitle>設定超連結</DialogTitle><DialogDescription>連結文字會顯示藍色底線，讀者點擊後可開啟您指定的網址。</DialogDescription><label>顯示文字<input value={linkText} maxLength={10000} onChange={e=>setLinkText(e.target.value)}/></label><label>連結網址<input type="url" value={linkUrl} maxLength={2048} onChange={e=>setLinkUrl(e.target.value)} placeholder="https://…" autoCapitalize="off" spellCheck={false}/></label>{linkError&&<p className="form-error" role="alert">{linkError}</p>}<div className="button-row"><button type="button" disabled={disabled} className="primary-btn" onClick={saveLink}>套用連結</button>{editor?.isActive('link')&&<button type="button" disabled={disabled} className="secondary-btn" onClick={()=>{chain()?.unsetLink().run();setLinkOpen(false);}}>移除連結</button>}</div></DialogContent></Dialog>
  <AlertDialog open={!!deleting} onOpenChange={open=>!open&&setDeleting(null)}><AlertDialogContent><AlertDialogTitle>移除註解 [{deleting?.id}]？</AlertDialogTitle><AlertDialogDescription>會移除本篇內文中的對應編號，專有名詞與其他文字會保留。</AlertDialogDescription><div className="button-row"><AlertDialogCancel>保留</AlertDialogCancel><AlertDialogAction onClick={removeNote}>移除註解</AlertDialogAction></div></AlertDialogContent></AlertDialog>
 </>
}
