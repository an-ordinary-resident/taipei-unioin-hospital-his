'use client';
import { useEffect,useState } from 'react';
import { Search,BookOpen,RefreshCw } from 'lucide-react';
import { DEFAULT_TERM_TAGS,type GlossaryTerm,type GlossaryPage } from '@/lib/glossary';
import { plainText } from '@/lib/rich-text';
import Prose from './prose';
import { TermTags } from './term-tags';
import Protected from './protected-content';
export default function GlossaryList({author=false,onSelect,refreshKey=0,initialQuery=''}:{author?:boolean;onSelect?:(term:GlossaryTerm)=>void;refreshKey?:number;initialQuery?:string}){
 const [query,setQuery]=useState(initialQuery),[tag,setTag]=useState(''),[offset,setOffset]=useState(0),[retry,setRetry]=useState(0);
 const [page,setPage]=useState<GlossaryPage>({terms:[],nextOffset:null,total:0,tags:[]}),[loading,setLoading]=useState(true),[error,setError]=useState('');
 useEffect(()=>{
  const controller=new AbortController();setLoading(true);setError('');
  const timer=setTimeout(async()=>{
   try{
    const response=await fetch('/api/glossary?'+new URLSearchParams({q:query,tag,offset:String(offset),...(author?{scope:'author'}:{})}),{signal:controller.signal,cache:'no-store'});
    const result=await response.json() as GlossaryPage & {error?:string};if(!response.ok)throw Error(result.error||'辭典暫時無法載入。');
    if(!controller.signal.aborted)setPage(result);
   }catch(error){if(!controller.signal.aborted)setError(error instanceof Error?error.message:'辭典暫時無法載入。');}
   finally{if(!controller.signal.aborted)setLoading(false);}
  },200);
  return()=>{clearTimeout(timer);controller.abort();};
 },[query,tag,offset,author,refreshKey,retry]);
 return <div className={'glossary-list '+(onSelect?'glossary-picker':'')}><label className="glossary-search"><Search size={18}/><span className="sr-only">搜尋醫學名詞、解說或標籤</span><input type="search" value={query} onChange={e=>{setQuery(e.target.value);setOffset(0);}} placeholder="搜尋醫學名詞、解說或標籤…" maxLength={200}/></label>
  <div className="term-tag-filters" role="group" aria-label="依屬性標籤篩選">{['',...new Set([...DEFAULT_TERM_TAGS,...page.tags])].map(value=><button type="button" key={value} aria-pressed={tag===value} onClick={()=>{setTag(value);setOffset(0);}}>{value||'全部詞條'}</button>)}</div>
  <div aria-live="polite" className="glossary-result-count">{loading?'搜尋中…':error?'':page.total+' 個詞條'}</div>
  {error?<div className="editor-message is-error" role="alert">{error}<button type="button" className="text-btn" onClick={()=>setRetry(n=>n+1)}><RefreshCw size={15}/>重新載入</button></div>:!loading&&!page.terms.length?<p className="empty-state">{query||tag?'沒有符合的詞條。':author?'尚無詞條，從「新增詞條」開始建立。':'辭典尚待作者刊載。'}</p>:<div className="glossary-results" aria-busy={loading}>{!loading&&page.terms.map(term=>onSelect?<button className="glossary-pick" type="button" key={term.id} onClick={()=>onSelect(term)}><strong><BookOpen size={16}/>{term.term}</strong>{author&&<span className="badge">{term.isPublished?term.hasDraft?'有草稿':'已刊載':'草稿'}</span>}<TermTags tags={term.tags}/><span className="glossary-excerpt">{plainText(term.text,!author)}</span></button>:<article className="panel glossary-term" key={term.id}><Protected><h2><BookOpen size={19}/>{term.term}</h2><TermTags tags={term.tags}/><div className="glossary-definition"><Prose text={term.text}/></div></Protected></article>)}</div>}
  {!loading&&!error&&(offset>0||page.nextOffset!==null)&&<nav className="glossary-pagination" aria-label="辭典分頁"><button type="button" className="secondary-btn" disabled={!offset} onClick={()=>setOffset(Math.max(0,offset-30))}>上一頁</button><span>第 {Math.floor(offset/30)+1} 頁</span><button type="button" className="secondary-btn" disabled={page.nextOffset===null} onClick={()=>setOffset(page.nextOffset!)}>下一頁</button></nav>}
 </div>;
}
