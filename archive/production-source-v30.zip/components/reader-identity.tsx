'use client';
import { useTourDismiss } from './tour-events';
import { useEffect,useRef,useState } from 'react';
import { UserRound,Stethoscope,Coffee,HeartPulse,Pencil,Upload,Hospital,ChevronDown,Check } from 'lucide-react';
import { Dialog,DialogContent,DialogTitle,DialogDescription } from './ui/dialog';
import { roleInfo } from '@/lib/reader-roles';
import { readerAvatars,initialProfile,checkedProfile,sanityValue } from '@/lib/reader-profile';
const KEY='his-reader-profile-v1';
const presets=[{id:'doctor',label:'值班醫師',Icon:Stethoscope},{id:'visitor',label:'院內訪客',Icon:UserRound},{id:'coffee',label:'續命咖啡',Icon:Coffee},{id:'heart',label:'熱血醫護',Icon:HeartPulse}];
function cookie(name:string){try{return decodeURIComponent(document.cookie.split('; ').find(c=>c.startsWith(name+'='))?.slice(name.length+1)||'');}catch{return '';}}
function Avatar({value}:{value:string}){const character=readerAvatars.find(p=>p.id===value),Icon=presets.find(p=>p.id===value)?.Icon||UserRound;return character?<img src={character.src} alt={character.label}/>:value.startsWith('data:')?<img src={value} alt="個人識別證大頭貼"/>:<Icon size={34}/>;}

function SanityControl({value,onChange}:{value:number;onChange:(value:number)=>void}){
 const wheelRef=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  const node=wheelRef.current;if(!node)return;
  const wheel=(event:WheelEvent)=>{if(event.ctrlKey||Math.abs(event.deltaY)<1)return;event.preventDefault();onChange(sanityValue(value+(event.deltaY<0?1:-1)));};
  node.addEventListener('wheel',wheel,{passive:false});
  return()=>node.removeEventListener('wheel',wheel);
 },[value,onChange]);
 return <div className="reader-sanity-editor"><label htmlFor="reader-sanity-number">今日理智值</label><div ref={wheelRef} className="reader-sanity-controls"><input type="range" min={0} max={100} step={1} value={value} aria-label="今日理智值滑桿" aria-describedby="reader-sanity-help" onChange={e=>onChange(Number(e.target.value))}/><div><input id="reader-sanity-number" type="number" min={0} max={100} step={1} value={value} inputMode="numeric" aria-describedby="reader-sanity-help" onChange={e=>onChange(sanityValue(e.target.valueAsNumber,0))}/><span>%</span></div></div><p id="reader-sanity-help" className="config-help">拖曳滑桿、輸入數字，或在滑桿與數值上滾動滑鼠（0–100）。</p></div>;
}
export default function ReaderIdentity({sanity}:{sanity:number}){
 const initial={...initialProfile,sanity:sanityValue(sanity)};
 const [profile,setProfile]=useState(initial),[draft,setDraft]=useState(initial),[open,setOpen]=useState(false),[galleryOpen,setGalleryOpen]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const fileRef=useRef<HTMLInputElement>(null),uploadNumber=useRef(0);
 useTourDismiss(()=>{setOpen(false);setGalleryOpen(false);});
 useEffect(()=>{const read=()=>{const fallback={...initialProfile,sanity:sanityValue(sanity),name:cookie('his-visitor')||initialProfile.name,role:roleInfo(cookie('his-reader-role')).label};try{setProfile(checkedProfile(JSON.parse(localStorage.getItem(KEY)||'null'),fallback));}catch{setProfile(fallback);}};read();const sync=(event:StorageEvent)=>{if(event.key===KEY||event.key===null)read();};window.addEventListener('storage',sync);return()=>{window.removeEventListener('storage',sync);uploadNumber.current++;};},[sanity]);
 function edit(){setDraft(profile);setGalleryOpen(readerAvatars.some(a=>a.id===profile.avatar));setError('');setOpen(true);}
 async function upload(file?:File){
  if(!file)return;const request=++uploadNumber.current;setError('');
  if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>8*1024*1024){setError('請選擇 8 MB 以內的 PNG、JPEG 或 WebP 圖片。');return;}
  setBusy(true);const url=URL.createObjectURL(file);
  try{const image=new Image();image.src=url;await image.decode();if(image.naturalWidth*image.naturalHeight>40000000)throw Error('圖片尺寸過大，請先縮小。');const canvas=document.createElement('canvas');canvas.width=384;canvas.height=384;const context=canvas.getContext('2d');if(!context)throw Error('無法處理圖片。');context.fillStyle='#edf4fa';context.fillRect(0,0,384,384);const side=Math.min(image.naturalWidth,image.naturalHeight);context.drawImage(image,(image.naturalWidth-side)/2,(image.naturalHeight-side)/2,side,side,0,0,384,384);const avatar=canvas.toDataURL('image/jpeg',.8);if(avatar.length>=250000)throw Error('圖片過於複雜，請選擇較小的圖片。');if(request===uploadNumber.current){setDraft(d=>({...d,avatar}));setGalleryOpen(false);}}catch(e){if(request===uploadNumber.current)setError(e instanceof Error?e.message:'圖片無法讀取，請重試。');}finally{URL.revokeObjectURL(url);if(request===uploadNumber.current)setBusy(false);if(fileRef.current)fileRef.current.value='';}
 }
 function save(){if(!draft.name.trim()||!draft.role.trim()){setError('請填寫姓名與職級。');return;}const next=checkedProfile({...draft,name:draft.name.trim(),role:draft.role.trim()},initial);try{localStorage.setItem(KEY,JSON.stringify(next));document.cookie='his-visitor='+encodeURIComponent(next.name)+'; Path=/; SameSite=Lax; Max-Age=31536000'+(location.protocol==='https:'?'; Secure':'');setProfile(next);setOpen(false);}catch{setError('此瀏覽器未允許儲存個人設定，請檢查儲存空間或隱私設定。');}}
 return <>
  <div className="patient-banner reader-id-banner">
   <button type="button" className="reader-id-button" aria-label="編輯我的值班識別證" onClick={edit}><span className="patient-initial duty-portrait"><Avatar value={profile.avatar}/></span><span className="reader-id-copy"><span className="patient-name">{profile.name}<span className="badge">{profile.role}</span></span><span className="reader-motto">{profile.motto||'個性宣言待填寫。'}</span><span className="reader-edit-hint"><Pencil size={12}/>編輯我的識別證</span></span></button>
   <button type="button" className="sanity reader-sanity-button" aria-label="編輯今日理智值" onClick={edit}><span>今日理智值 <Pencil size={11}/></span><strong>{profile.sanity}<small>%</small></strong><span className="sanity-bar"><i style={{width:profile.sanity+'%'}}/></span></button>
  </div>
  <Dialog open={open} onOpenChange={value=>{if(!busy)setOpen(value);}}><DialogContent className="reader-tool-dialog reader-profile-dialog">
   <div className="reader-panel-header"><DialogTitle>我的值班識別證</DialogTitle><DialogDescription>換上大頭貼，留下你的值班宣言。</DialogDescription></div>
   <fieldset disabled={busy}>
    <div className="reader-avatar-editor"><span className="duty-portrait-preview"><Avatar value={draft.avatar}/></span><div><button type="button" className="secondary-btn" onClick={()=>fileRef.current?.click()}><Upload size={16}/>{busy?'處理圖片中…':'匯入個人大頭貼'}</button><p className="config-help">正方形 1:1 · PNG、JPEG、WebP · 上限 8 MB</p></div></div>
    <input ref={fileRef} type="file" hidden accept="image/png,image/jpeg,image/webp" onChange={e=>void upload(e.target.files?.[0])}/>
    <div className="reader-avatar-presets" role="group" aria-label="預設頭像">{presets.map(({id,label,Icon})=><button type="button" key={id} aria-pressed={draft.avatar===id} onClick={()=>{setDraft({...draft,avatar:id});setGalleryOpen(false);}}><Icon size={21}/>{label}</button>)}<button type="button" aria-expanded={galleryOpen} aria-controls="reader-hospital-avatars" className={readerAvatars.some(a=>a.id===draft.avatar)?'is-selected':''} onClick={()=>setGalleryOpen(!galleryOpen)}><Hospital size={21}/>慈愛醫院<ChevronDown size={15} className={galleryOpen?'is-open':''}/></button></div>
    {galleryOpen&&<div id="reader-hospital-avatars" className="reader-character-avatars" role="group" aria-label="慈愛醫院角色頭像">{readerAvatars.map(a=><button type="button" key={a.id} aria-pressed={draft.avatar===a.id} onClick={()=>setDraft({...draft,avatar:a.id})}><span className="reader-character-image"><img src={a.src} alt="" width={160} height={160}/>{draft.avatar===a.id&&<span className="reader-avatar-check"><Check size={15}/></span>}</span><span>{a.label}</span></button>)}</div>}
    <label>姓名<input value={draft.name} maxLength={80} onChange={e=>setDraft({...draft,name:e.target.value})}/></label>
    <label>職級<input value={draft.role} maxLength={80} onChange={e=>setDraft({...draft,role:e.target.value})}/></label>
    <label>個性宣言<textarea value={draft.motto} maxLength={200} rows={3} onChange={e=>setDraft({...draft,motto:e.target.value})}/></label>
    <SanityControl value={draft.sanity} onChange={value=>setDraft(d=>({...d,sanity:value}))}/>
    <p className="config-help">識別證、照片與理智值只儲存在這個瀏覽器。職級為展示文字，閱讀權限依登入身分。</p>
    <button type="button" className="primary-btn" onClick={save}>儲存識別證</button>
   </fieldset>
   {error&&<p role="alert" className="editor-message is-error">{error}</p>}
  </DialogContent></Dialog>
 </>;
}
