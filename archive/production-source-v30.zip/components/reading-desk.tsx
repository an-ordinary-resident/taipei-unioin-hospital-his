'use client';
import { useEffect,useState } from 'react';
import { ArrowRight,ClipboardList,Bookmark,RotateCcw } from 'lucide-react';
import type { NovelDoc } from '@/lib/content';
import { resumeRecord,type ReaderHistory } from '@/lib/reading-history';
import { readerHistory } from '@/lib/reader-client';
import { volumeLabel } from '@/lib/story-access';
export default function ReadingDesk({all}:{all:NovelDoc[]}){
 const [history,setHistory]=useState<ReaderHistory>({lastRead:null,bookmark:null}),[ready,setReady]=useState(false),[error,setError]=useState('');
 useEffect(()=>{let active=true;async function load(){try{const result=await readerHistory(true);if(active){setHistory(result);setError('');}}catch{if(active)setError('暫時無法載入續讀紀錄，可先從第一章開始。');}finally{if(active)setReady(true);}}void load();const resume=(e:PageTransitionEvent)=>{if(e.persisted)void load();};window.addEventListener('pageshow',resume);return()=>{active=false;window.removeEventListener('pageshow',resume);};},[]);
 const {chapter,point,source}=resumeRecord(all,history),volume=all.find(d=>d.kind==='volume'&&d.id===chapter?.volume);
 const last=history.lastRead&&all.find(d=>d.kind==='chapter'&&!d.locked&&d.id===history.lastRead?.chapterId);
 const label=source==='bookmark'?'已暫存病歷':source==='last'?'上次閱讀':'首次報到 · 全員初登場';
 return <section className="panel volume-panel dashboard-card-latest"><div className="panel-heading"><h2><ClipboardList size={18}/>本日待閱病歷</h2><span className="mono">READING DESK</span></div>{!ready?<p className="empty-state" role="status">正在調閱你的病歷紀錄…</p>:chapter?<div className="dashboard-latest-content">{volume&&<><span className="badge">{volumeLabel(volume)}</span><h2>{volume.title}</h2>{volume.subtitle&&<p className="dashboard-volume-subtitle mono">{volume.subtitle}</p>}{volume.image&&<figure className="volume-cover"><img src={volume.image} alt={volume.title+' · 完整封面'}/></figure>}</>}<div className="latest-episode"><small className="resume-source">{source==='bookmark'?<Bookmark size={15}/>:<RotateCcw size={15}/>} {label}{point&&' · '+Math.round(point.percent)+'%'}</small><strong>{chapter.title}</strong><p className="resume-summary">{chapter.summary||'本章大綱尚待作者填寫。'}</p></div><a className="primary-btn" href={'/read/'+chapter.id+(source==='first'?'':'?resume='+source)}>{source==='bookmark'?'回到書籤段落':source==='last'?'繼續上次閱讀':'從第一章開始'}<ArrowRight size={16}/></a>{source==='bookmark'&&last&&<a className="desk-last-link" href={'/read/'+last.id+'?resume=last'}>上次閱讀：{last.title}<ArrowRight size={14}/></a>}</div>:<p className="empty-state">目前尚無可閱讀的章節。</p>}{error&&<p role="status" className="desk-history-error">{error}</p>}<a href="/volumes" className="panel-bottom-link">開啟完整病程目錄 <ArrowRight size={15}/></a></section>;
}
