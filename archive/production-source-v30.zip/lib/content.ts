import { env } from 'cloudflare:workers';
import seed from '@/data/seed.json';
import chapterUpdate from '@/data/chapter-updates.json';
import personnelImport from '@/data/personnel-import.json';
import { referenceIds,type Annotation } from './rich-text';
import { cleanTags } from './glossary';
import { validGlossaryId,linkedTermRows,resolveLinkedNotes } from './annotation-links';
import { applyStoryAccess,chapterLabels } from './story-access';
import { readerIdentity } from './reader-access';
import { getChatGPTUser } from '@/app/chatgpt-auth';
export type ProfileSection={title:string;body:string};
export type NovelDoc={id:string;kind:'chapter'|'character'|'volume';volume:string;title:string;subtitle:string;body:string;image:string;order:number;revision:number;role?:string;age?:string;gender?:string;department?:string;position?:string;feature?:string;category?:string;profileVersion?:number;profileSections?:ProfileSection[];isPublished?:boolean;hasDraft?:boolean;notes?:Annotation[];cast?:string[];summary?:string;readingMinutes?:string;details?:string;background?:string;volumeType?:'main'|'bonus';chapterType?:'main'|'bonus'|'appendix'|'interlude'|'afterword';chapterLabel?:string;locked?:boolean;quote?:string};
type Stored={id:string;draft:string;published:string|null;revision:number;updated_at:string};
type ImportedPersonnel={id:string|null;name:string;feature:string;category:string;role:string;gender:string;age:string;bullets:string[];details:Record<string,string>;confidential:string};
const importedPersonnel=personnelImport.records as ImportedPersonnel[];
const sourceExistingIds:Record<string,string>={'陳屏帆':'person-1','殷采熠':'person-2','江柏川':'person-3','楊紫潔':'person-4','沈書儀':'person-5','吳耀彰':'person-6','梅良昕':'person-7','趙天祥':'person-9'};
const importId=(record:ImportedPersonnel,index:number)=>sourceExistingIds[record.name]||record.id||'person-source-'+String(index+1).padStart(2,'0');
function splitRole(role:string){const match=role.match(/^(.*?)(?:\s+)(R\d+|CR|VS|PGY\d+|Clerk|主任|護理師|工友|放射師|社工師|營養師)$/);return match?{department:match[1],position:match[2]}:{department:role,position:''};}
function quoteFromSections(sections:Record<string,string>){const match=(sections['角色語錄']||'').match(/「([^」]+)」/);return match?.[1]||'';}
const profileTitles=['人物簡介','基本資料','外觀特徵','人物特質','喜好與習慣','角色語錄'];
function profileSectionsFromText(text:string):ProfileSection[]{return profileTitles.map((title,index)=>{const marker=`【${title}】`;const start=text.indexOf(marker);if(start<0)return null;const next=profileTitles.slice(index+1).map(t=>text.indexOf(`【${t}】`,start+marker.length)).filter(i=>i>=0).sort((a,b)=>a-b)[0];return {title,body:text.slice(start+marker.length,next<0||next===undefined?text.length:next).trim()};}).filter((section):section is ProfileSection=>!!section);}
function normalizeBullets(bullets:string[]){const output=[...bullets];while(output.length>5){output[output.length-2]=output[output.length-2]+'；'+output.pop();}while(output.length<4&&output.length){const index=output.reduce((best,value,current)=>value.length>output[best].length?current:best,0);const text=output[index];const cuts=[...text.matchAll(/[，；]/g)].map(match=>(match.index??0)+1).filter(point=>point>text.length*.28&&point<text.length*.78);const point=cuts.sort((a,b)=>Math.abs(a-text.length/2)-Math.abs(b-text.length/2))[0]||Math.floor(text.length/2);output.splice(index,1,text.slice(0,point).replace(/[，；]$/,'')+'。',text.slice(point).replace(/^[，；]/,''));}return output;}
function importedProfile(record:ImportedPersonnel,index:number,base?:NovelDoc):NovelDoc{
 const roleParts=splitRole(record.role); const sections=Object.entries(record.details||{}).map(([title,body])=>({title,body}));
 const body=normalizeBullets(record.bullets).map(b=>'• '+b).join('\n');
 const id=importId(record,index); const existing=base&&base.id===id?base:undefined;
 const displayName=record.name==='柯詩婷'?'Christina':record.name;
 const sourceQuote=quoteFromSections(record.details||{});
 return {id,kind:'character',volume:existing?.volume||'vol-1',title:displayName,subtitle:record.feature,body,image:existing?.image||'',order:existing?.order||100+index,revision:existing?.revision||0,role:record.role,age:record.age,gender:record.gender,department:roleParts.department,position:roleParts.position,feature:record.feature,category:record.category,profileVersion:1,profileSections:sections,details:sections.map(s=>`【${s.title}】\n${s.body}`).join('\n\n'),background:record.confidential||'',quote:existing?.quote||sourceQuote,notes:existing?.notes||[],isPublished:existing?.isPublished??true,hasDraft:existing?.hasDraft??false};
}
function applyImportedPersonnel(map:Map<string,NovelDoc>,suppressed=new Set<string>()){
 importedPersonnel.forEach((record,index)=>{
  const id=importId(record,index); if(suppressed.has(id))return; const existing=[...map.values()].find(d=>d.kind==='character'&&(d.id===id||d.title===record.name));
  if(existing?.profileVersion===1)return;
  map.set(id,importedProfile(record,index,existing));
 });
}
export function database(){if(!env.DB)throw new Error('資料庫暫時無法連線');return env.DB;}
export async function isAuthor(){const user=await getChatGPTUser(); const email=env.AUTHOR_EMAIL?.trim().toLowerCase();return !!(user && email && user.email.toLowerCase()===email);}
export async function documents(author=false,applyAccess=true):Promise<NovelDoc[]>{
 const {results}=await database().prepare("SELECT id, draft, published, revision, updated_at FROM documents WHERE id NOT IN ('site-announcement','site-dashboard','site-about','site-tour')").all<Stored>();
 const map=new Map<string,NovelDoc>((seed as NovelDoc[]).map(d=>[d.id,{...d,isPublished:true,hasDraft:false}]));
 for(const row of results){if(author){map.set(row.id,{...JSON.parse(row.draft),revision:row.revision,isPublished:!!row.published,hasDraft:row.draft!==row.published});}else if(row.published){map.set(row.id,{...JSON.parse(row.published),revision:row.revision,isPublished:true,hasDraft:false});}else{map.delete(row.id);}}
 const suppressedImports=new Set(results.filter(row=>row.published===null).map(row=>row.id));
 applyImportedPersonnel(map,suppressedImports);
 const identity=author||!applyAccess?null:await readerIdentity();
 const result=[...map.values()].map(d=>d.id===chapterUpdate.id&&!d.notes&&chapterUpdate.expectedBodies.includes(d.body)?{...d,...chapterUpdate.replacement}:d).map(d=>{
  if(d.kind==='chapter'||d.kind==='volume')return applyStoryAccess(d,[...map.values()],identity?.rank??null);
  if(d.kind!=='character')return d;
  let basic=d.body,details=d.details||'';
  if(d.details===undefined){const split=d.body.indexOf('• ',d.body.indexOf('• ')+2);if(split>0){basic=d.body.slice(0,split).trim();details=d.body.slice(split).trim()}}
  const value={...d,body:basic,details,background:d.background||'',profileSections:d.profileSections?.length?d.profileSections:profileSectionsFromText(details)};
  if(!identity)return value;
  if(identity.rank<1){value.details='';value.profileSections=[];}
  if(identity.rank<3)value.background='';
  const visible=referenceIds(value.body+'\n'+value.details+'\n'+value.background);value.notes=(value.notes||[]).filter(n=>visible.includes(n.id));
  return value;
 });
 const visibleVolumes=new Set(result.filter(d=>d.kind==='volume').map(d=>d.id));
 const visible=result.filter(d=>author||d.kind!=='chapter'||visibleVolumes.has(d.volume));
 const terms=await linkedTermRows(database(),visible.flatMap(d=>d.notes||[]));
 return chapterLabels(visible.map(d=>d.notes?{...d,notes:resolveLinkedNotes(d.notes,terms,author)}:d).sort((a,b)=>a.order-b.order||a.id.localeCompare(b.id)));
}
export async function mutationGuard(req:Request){if(!await isAuthor())return Response.json({error:'只有作者可以編輯或刊載作品。'},{status:403});if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'請由本站作者工作台操作。'},{status:403});return null;}
export function cleanDocument(x:unknown):NovelDoc|null{
 if(!x||typeof x!=='object')return null; const d=x as Record<string,unknown>;
 if(typeof d.id!=='string'||!/^[-a-z0-9]{1,80}$/.test(d.id)||!['chapter','character','volume'].includes(String(d.kind))||typeof d.title!=='string'||!d.title.trim()||d.title.length>200||typeof d.body!=='string'||d.body.length>250000||typeof d.volume!=='string'||!/^[-a-z0-9]{1,80}$/.test(d.volume)||!Number.isInteger(d.order)||Number(d.order)<1||Number(d.order)>999||!Number.isInteger(d.revision)||Number(d.revision)<0)return null;
 for(const key of ['subtitle','image','role','age','gender','department','position','feature','category'])if(d[key]!==undefined&&(typeof d[key]!=='string'||String(d[key]).length>300))return null;
 if(d.image&&d.image!=='/covers/vol-1.png'&&!/^\/api\/media\/[a-f0-9-]{36}$/.test(String(d.image)))return null;
 if(d.notes!==undefined&&(!Array.isArray(d.notes)||d.notes.length>200||d.notes.some((n:unknown)=>!n||typeof n!=='object'||!Number.isInteger((n as Annotation).id)||(n as Annotation).id<1||(n as Annotation).id>999||typeof (n as Annotation).term!=='string'||!(n as Annotation).term.trim()||(n as Annotation).term.length>200||typeof (n as Annotation).text!=='string'||!(n as Annotation).text.trim()||(n as Annotation).text.length>6000||cleanTags((n as Annotation).tags)===null)||new Set(d.notes.map((n:Annotation)=>n.id)).size!==d.notes.length))return null;
 if(Array.isArray(d.notes)&&d.notes.some((n:Annotation)=>n.glossaryId!==undefined&&!validGlossaryId(n.glossaryId)))return null;
 if(d.cast!==undefined&&(!Array.isArray(d.cast)||d.cast.length>50||d.cast.some((n:unknown)=>typeof n!=='string'||n.length>80)))return null;
 if(d.id==='site-dashboard'||d.id==='site-about'||d.id==='site-announcement'||d.id==='site-tour')return null;
 if(d.quote!==undefined&&(typeof d.quote!=='string'||d.quote.length>1000))return null;
 if(d.volumeType!==undefined&&!['main','bonus'].includes(String(d.volumeType)))return null;
 if(d.chapterType!==undefined&&!['main','bonus','appendix','interlude','afterword'].includes(String(d.chapterType)))return null;
 for(const key of ['details','background'])if(d[key]!==undefined&&(typeof d[key]!=='string'||String(d[key]).length>250000))return null;
 if(d.profileVersion!==undefined&&(!Number.isInteger(d.profileVersion)||Number(d.profileVersion)<1||Number(d.profileVersion)>20))return null;
 if(d.profileSections!==undefined&&(!Array.isArray(d.profileSections)||d.profileSections.length>20||d.profileSections.some((s:unknown)=>!s||typeof s!=='object'||typeof (s as ProfileSection).title!=='string'||(s as ProfileSection).title.length>100||typeof (s as ProfileSection).body!=='string'||(s as ProfileSection).body.length>250000)))return null;
 if(d.summary!==undefined&&(typeof d.summary!=='string'||d.summary.length>6000))return null;
 if(d.readingMinutes!==undefined&&(typeof d.readingMinutes!=='string'||d.readingMinutes.length>60))return null;
 return {volumeType:d.kind==='volume'?(d.volumeType||'main') as NovelDoc['volumeType']:undefined,quote:d.kind==='character'?String(d.quote||''):undefined,details:d.kind==='character'?String(d.details||''):undefined,background:d.kind==='character'?String(d.background||''):undefined,profileVersion:d.kind==='character'&&d.profileVersion!==undefined?Number(d.profileVersion):undefined,profileSections:d.kind==='character'&&Array.isArray(d.profileSections)?(d.profileSections as ProfileSection[]).map(s=>({title:s.title.trim(),body:s.body})):undefined,department:d.kind==='character'?String(d.department||''):undefined,position:d.kind==='character'?String(d.position||''):undefined,feature:d.kind==='character'?String(d.feature||''):undefined,category:d.kind==='character'?String(d.category||''):undefined,chapterType:d.kind==='chapter'?(d.chapterType||'main') as NovelDoc['chapterType']:undefined,notes:((d.notes||[]) as Annotation[]).map(n=>({id:n.id,term:n.term,text:n.text,tags:cleanTags(n.tags)||[],...(n.glossaryId?{glossaryId:n.glossaryId}:{})})),cast:((d.cast||[]) as string[]).map(n=>n.trim()).filter(Boolean),summary:String(d.summary||''),readingMinutes:String(d.readingMinutes||''),id:d.id,kind:d.kind as NovelDoc['kind'],volume:d.volume,title:d.title.trim(),subtitle:String(d.subtitle||''),body:d.body,image:String(d.image||''),order:Number(d.order),revision:Number(d.revision),role:String(d.role||''),age:String(d.age||''),gender:String(d.gender||'')};
}
