import { database,cleanDocument } from './content';
import { CARD_IDS,DEFAULT_ABOUT,DEFAULT_DASHBOARD,type DashboardConfig,type AboutConfig } from './presentation-config';
import { DEFAULT_TOUR,cleanTourContent,type TourContent } from './tour-content';
export type PresentationSection='dashboard'|'about'|'tour';
export async function presentation(section:PresentationSection,author=false){
 const row=await database().prepare('SELECT draft,published,revision FROM documents WHERE id=?').bind('site-'+section).first<{draft:string;published:string|null;revision:number}>();
 const fallback=section==='tour'?DEFAULT_TOUR:section==='dashboard'?DEFAULT_DASHBOARD:DEFAULT_ABOUT;
 return {value:row&&(author?row.draft:row.published)?JSON.parse((author?row.draft:row.published)!):fallback,revision:author?(row?.revision||0):0,hasDraft:author&&!!row&&row.draft!==row.published};
}
export function cleanPresentation(section:PresentationSection,input:unknown):DashboardConfig|AboutConfig|TourContent|null{
 if(section==='tour')return cleanTourContent(input);
 if(!input||typeof input!=='object')return null;const p=input as Record<string,unknown>;const str=(x:unknown,max:number)=>typeof x==='string'&&x.length<=max;
 if(section==='about'){
  if(!str(p.title,200)||!String(p.title).trim()||!str(p.subtitle,500)||!str(p.body,100000))return null;
  const doc=cleanDocument({id:'about-validation',kind:'chapter',title:'about',body:p.body,volume:'vol-1',order:1,revision:0,notes:p.notes});
  return doc?{title:String(p.title).trim(),subtitle:String(p.subtitle),body:String(p.body),notes:doc.notes||[]}:null;
 }
 if(!str(p.welcome,500)||!str(p.dutyCharacterId,80)||!str(p.featuredCharacterId,80)||!str(p.dutyMessage,1000)||!Number.isInteger(p.sanity)||Number(p.sanity)<0||Number(p.sanity)>100||!['standard','reverse','single'].includes(String(p.layout))||!['news','chat'].includes(String(p.newsStyle)))return null;
 if(p.dutyPortraits!==undefined&&(!p.dutyPortraits||typeof p.dutyPortraits!=='object'||Array.isArray(p.dutyPortraits)||Object.keys(p.dutyPortraits).length>100||Object.entries(p.dutyPortraits).some(([id,url])=>!/^[-a-z0-9]{1,80}$/.test(id)||typeof url!=='string'||!/^\/api\/media\/[a-f0-9-]{36}$/.test(url))))return null;
 if(!Array.isArray(p.cards)||p.cards.length!==3||new Set(p.cards).size!==3||p.cards.some(x=>!CARD_IDS.includes(x))||!Array.isArray(p.hiddenCards)||new Set(p.hiddenCards).size!==p.hiddenCards.length||p.hiddenCards.some(x=>!CARD_IDS.includes(x)))return null;
 if(!Array.isArray(p.quotes)||p.quotes.length>100||p.quotes.some(q=>!q||!str(q.id,80)||!q.id||!str(q.text,2000)||!q.text.trim()||!str(q.byline,200))||new Set(p.quotes.map(q=>q.id)).size!==p.quotes.length)return null;
 if(!Array.isArray(p.news)||p.news.length>100||p.news.some(n=>!n||!str(n.id,80)||!n.id||!str(n.title,200)||!str(n.body,6000)||!n.body.trim()||!str(n.byline,200)||!str(n.date,60))||new Set(p.news.map(n=>n.id)).size!==p.news.length)return null;
 return {dutyPortraits:{...(p.dutyPortraits as Record<string,string>||{})},welcome:p.welcome,dutyCharacterId:p.dutyCharacterId,dutyMessage:p.dutyMessage,sanity:p.sanity,featuredCharacterId:p.featuredCharacterId,layout:p.layout,cards:p.cards,hiddenCards:p.hiddenCards,newsStyle:p.newsStyle,news:p.news.map(n=>({id:n.id,title:n.title,body:n.body,byline:n.byline,date:n.date})),quotes:p.quotes.map(q=>({id:q.id,text:q.text,byline:q.byline}))} as DashboardConfig;
}
