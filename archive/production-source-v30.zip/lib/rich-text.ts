export type Annotation={id:number;term:string;text:string;tags?:string[];glossaryId?:string;glossaryRevision?:number;glossaryPublished?:boolean;glossaryHasDraft?:boolean;glossaryMissing?:boolean};
export { INKS,inlineNodes,plainText,referenceIds,proseBlocks,safeLink,type InlineNode } from './prose-format';
import { plainText,referenceIds } from './prose-format';
export function wordCount(text:string){return Array.from(plainText(text).replace(/\s/g,'')).length;}
export function insertDivider(text:string,caret:number){const newline=text.indexOf('\n',caret),position=newline<0?text.length:newline;const before=text.slice(0,position),after=text.slice(position).replace(/^\n+/,'');const value=before+(before?'\n\n':'')+'---\n\n'+after;const start=before.length+(before?2:0)+5;return{value,start,end:start};}
export function parseAnnotatedText(text:string):{body:string;notes:Annotation[]}|null{
 const marker=/【用詞[注註]釋】/.exec(text);if(!marker)return null;
 const body=text.slice(0,marker.index).replace(/^\s*【故事內文】\s*/, '').trim();
 const entries=[...text.slice(marker.index+marker[0].length).matchAll(/^\[(\d{1,3})\]\s*([\s\S]*?)(?=^\[\d{1,3}\]|(?![\s\S]))/gm)];
 const notes=entries.map(m=>{const value=m[2].trim(),split=value.search(/[：:]/);return{id:Number(m[1]),term:split<0?'註解 '+m[1]:value.slice(0,split).trim(),text:split<0?value:value.slice(split+1).trim()}});
 if(!body||!notes.length||new Set(notes.map(n=>n.id)).size!==notes.length||referenceIds(body).some(id=>!notes.some(n=>n.id===id)))return null;
 return {body,notes};
}
export function wrapSelection(text:string,start:number,end:number,before:string,after:string){
 const selected=text.slice(start,end)||'重點文字';
 if(selected.includes('\n')){
  const lines=selected.split('\n').map(line=>{const m=line.match(/^(\s*(?:[-•𖣠]\s+)?)(.*?)(\s*)$/u)!;return{prefix:m[1],content:m[2],suffix:m[3]}});
  const remove=lines.filter(l=>l.content).every(l=>l.content.startsWith(before)&&l.content.endsWith(after)&&l.content.length>=before.length+after.length);
  const value=lines.map(l=>l.prefix+(l.content?(remove?l.content.slice(before.length,-after.length):before+l.content+after):'')+l.suffix).join('\n');
  return{value:text.slice(0,start)+value+text.slice(end),start,end:start+value.length};
 }
 if(start>=before.length&&text.slice(start-before.length,start)===before&&text.slice(end,end+after.length)===after)return{value:text.slice(0,start-before.length)+selected+text.slice(end+after.length),start:start-before.length,end:end-before.length};
 if(selected.startsWith(before)&&selected.endsWith(after)&&selected.length>before.length+after.length){const value=selected.slice(before.length,-after.length);return{value:text.slice(0,start)+value+text.slice(end),start,end:start+value.length};}
 const value=text.slice(0,start)+before+selected+after+text.slice(end);return{value,start:start+before.length,end:start+before.length+selected.length};
}
export function listSelection(text:string,start:number,end:number){const a=start===0?0:text.lastIndexOf('\n',start-1)+1;const last=end>start&&text[end-1]==='\n'?end-1:end;let b=text.indexOf('\n',last);if(b<0)b=text.length;const lines=text.slice(a,b).split('\n');const remove=lines.every(l=>/^\s*- /.test(l));const next=lines.map(l=>remove?l.replace(/^(\s*)- /,'$1'):l.trim()?'- '+l:'- ').join('\n');return{value:text.slice(0,a)+next+text.slice(b),start:a,end:a+next.length};}
