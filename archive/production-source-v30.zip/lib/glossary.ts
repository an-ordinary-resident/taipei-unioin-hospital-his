export const DEFAULT_TERM_TAGS=['行政職級','醫護黑話','醫療處置','疾病症狀','檢查儀器','專科分類','解剖生理'];
export function cleanTags(value:unknown):string[]|null{
 if(value===undefined)return [];
 if(!Array.isArray(value)||value.length>20||value.some(t=>typeof t!=='string'||!t.trim()||t.normalize('NFKC').trim().length>40))return null;
 return [...new Set(value.map(t=>t.normalize('NFKC').trim()))];
}
export type GlossaryTerm={id:string;term:string;text:string;tags:string[];revision:number;isPublished:boolean;hasDraft:boolean};
export type GlossaryPage={terms:GlossaryTerm[];nextOffset:number|null;total:number;tags:string[]};
export const normalizeTerm=(term:string)=>term.normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase('en');
export function cleanTerm(value:unknown):Pick<GlossaryTerm,'id'|'term'|'text'|'tags'|'revision'>|null{
 if(!value||typeof value!=='object')return null;
 const t=value as Record<string,unknown>;
 if(typeof t.id!=='string'||!/^[-a-z0-9]{1,80}$/.test(t.id)||typeof t.term!=='string'||!t.term.trim()||t.term.length>200||typeof t.text!=='string'||!t.text.trim()||t.text.length>6000||!Number.isInteger(t.revision)||Number(t.revision)<0)return null;
 const tags=cleanTags(t.tags);if(!tags)return null;
 return {id:t.id,term:t.term.trim(),text:t.text.trim(),tags,revision:Number(t.revision)};
}
