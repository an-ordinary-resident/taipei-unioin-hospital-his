export const TOUR_COOKIE='his-onboarding-v1';
export const TOUR_RUN='his-onboarding-run-v1';
export const TOUR_RETURN='his-onboarding-return-v1';
export const tourStations=['院內動線','值班主控台','病程閱覽','人員檔案','註釋辭典庫','完成報到'];
export type TourStep={id:string;station:number;title:string;body:string;hint?:string;route:'dashboard'|'volumes'|'read'|'character'|'characters'|'glossary';target:string;action?:string;actionLabel?:string};
export const tourSteps:TourStep[]=[
 {id:'navigation',station:0,title:'先認識院內動線',body:'側欄是你的院內地圖：值班主控台、病程紀錄、人員檔案、註釋辭典庫與系統聲明。上方顯示登入身分，下方可切換淺色／深色模式。',hint:'手機點左上角選單展開。之後也能從側欄的「新進人員教學」重新報到。',route:'dashboard',target:'.his-sidebar-scroll',action:'sidebar',actionLabel:'看看側邊欄'},
 {id:'identity',station:1,title:'領取你的值班識別證',body:'點選識別證，就能更換姓名、頭像、展示職級與個性宣言；「慈愛醫院」提供五位角色頭像。今日理智值可用滑桿、滾輪或輸入數字調整。',hint:'展示職級不會改變閱讀權限。理智值歸零也不會幫你代班。',route:'dashboard',target:'.reader-id-banner',action:'.reader-id-button',actionLabel:'試開識別證'},
 {id:'resume',station:1,title:'你的待閱病歷，替你記著',body:'本日待閱病歷優先顯示你設定的書籤，其次是上次閱讀的章節，並附上本章大綱。首次報到則從第一卷第一章開始。上方三個數字是目前已刊載的卷數、篇數與人員檔案數。',hint:'教學示範不會覆蓋原本的續讀紀錄。',route:'dashboard',target:'.dashboard-card-latest'},
 {id:'notices',station:1,title:'異常通報與院內八卦',body:'「院內異常通報」推薦一位角色，顯示照片、基本介紹與名言，點擊可查閱人員檔案。「瓷礙魔窟小道消息」則收錄作者刊登的院內新聞與群聊。',hint:'這裡的異常，是指同事；通常不是系統故障。',route:'dashboard',target:'.dashboard-recommendation'},
 {id:'volumes',station:2,title:'打開一卷，開始查房',body:'各卷預設收合。點卷名即可展開封面、簡介與章節目錄；正文以 Log 編號，間章、附錄與後記另有標籤。番外篇需住院醫師以上身分閱讀。',hint:'下一步會開啟目前可閱讀的第一章，示範閱讀工具。',route:'volumes',target:'.volume-directory',action:'.volume-toggle',actionLabel:'試著展開這一卷'},
 {id:'settings',station:2,title:'先把閱讀環境調舒服',body:'「閱讀設定」可調整大中小字體、字型與淺色／深色模式。系統會記住這個瀏覽器的偏好，下次打開也能接著使用。',route:'read',target:'.reader-tools',action:'settings',actionLabel:'試開閱讀設定'},
 {id:'info',station:2,title:'先看本章資訊，再決定要不要值班',body:'「本章資訊」整理登場人物、內文字數、預估閱讀時間與本章大綱。想知道這次要面對哪些神仙同事，先看這裡。',route:'read',target:'.reader-tools',action:'info',actionLabel:'查看本章資訊'},
 {id:'bookmark',station:2,title:'病歷暫存，替自己留個書籤',body:'「病歷暫存」記錄目前章節與閱讀段落。回到值班主控台後，即可從書籤接續；新的暫存會取代原有書籤。',hint:'可以先看看視窗。只有你按下儲存／移除時，才會更動書籤。',route:'read',target:'.reader-tools',action:'bookmark',actionLabel:'看看病歷暫存'},
 {id:'sections',station:2,title:'章節分段，快速找到重點',body:'「章節分段」依大中小標題整理本章段落，點選即可跳轉。若作者尚未加入標題，目錄會顯示尚無分段，不影響正常閱讀。',route:'read',target:'.reader-tools',action:'sections',actionLabel:'查看章節分段'},
 {id:'comments',station:2,title:'病歷評論，也歡迎你的會診意見',body:'「病歷評論」收錄作者評論、訪客留言及參考資料。你可以留下想法，並編輯或刪除自己在這個瀏覽器留下的留言。',hint:'教學不會代你送出任何留言。',route:'read',target:'.reader-tools',action:'comments',actionLabel:'看看病歷評論'},
 {id:'chapters',station:2,title:'同卷目錄，不必每次回總表',body:'「同卷目錄」列出這一卷的其他章節，點標題即可切換。需較高權限的番外篇會保留鎖定提示。',route:'read',target:'.reader-tools',action:'chapters',actionLabel:'查看同卷目錄'},
 {id:'annotations',station:2,title:'遇到醫學名詞，點一下註解',body:'正文中的 [1]、[2] 是用詞註釋。點擊可展開名詞解釋，背景略微淡化，方便區分正文與補充說明；關閉後即可接著閱讀。',hint:'若這一章尚無註解，也能到註釋辭典庫查閱。',route:'read',target:'.annotation-ref',action:'.annotation-button',actionLabel:'試開內文註解'},
 {id:'floating',station:2,title:'往下讀，工具也跟著你',body:'當上方工具列滑出畫面，右上角會整合成「病歷功能」，仍可開啟閱讀設定、本章資訊、書籤與各種目錄。右下角顯示閱讀進度，停止捲動約 1 秒後隱藏。',route:'read',target:'.reader-paper [data-reader-block]:nth-child(8)',action:'scroll',actionLabel:'試著往下閱讀'},
 {id:'feedback',station:2,title:'讀完了，留下一份會診意見',body:'章末的「留言」「按讚」「分享」讓你留下讀後感、支持作品，或邀朋友一起進入瓷礙魔窟。每個閱讀裝置在同一章只計一次閱覽。',hint:'教學只介紹按鈕，不會自動按讚、留言或分享。',route:'read',target:'.reader-actions'},
 {id:'characters',station:3,title:'人員檔案：先認識你的神仙同事',body:'用搜尋欄查姓名、人物特色、科別或職級，也能利用分類篩選。點角色卡片查看人物簡介；實習醫學生以上可讀人物設定，主治醫師可讀機密檔案。',hint:'機密內容預設收起；教學不會改變你的登入權限。',route:'characters',target:'.directory-controls',action:'.directory-search input',actionLabel:'試試搜尋人物'},
 {id:'character',station:3,title:'陳屏帆的人員檔案',body:'這是陳屏帆的個人檔案。照片旁列出人物特色、科別、職級與基本資料，下方是人物名言與列點簡介。你可以實際捲動查看完整內容。',hint:'人物設定與機密檔案依登入身分開放。教學不會自動展開機密內容，也不會提高閱讀權限。',route:'character',target:'.character-detail',action:'character',actionLabel:'實際查看角色內容'},
 {id:'glossary',station:4,title:'註釋辭典庫：不必翻回原章找名詞',body:'輸入醫學名詞、解說關鍵字或標籤，即可查找詞條；也可以用行政職級、醫護黑話、醫療處置等分類篩選。解說就在詞條下方，可以獨立查閱。',hint:'我是「一個平凡的住院醫師」。解釋名詞是本分，準時下班是願望。',route:'glossary',target:'.glossary-search',action:'.glossary-search input',actionLabel:'試著搜尋名詞'},
];
export type TourStatus={status:'active'|'done'|'skipped';step:number};
export function parseTourCookie(value:string):TourStatus|null{
 const match=/^1\.(active|done|skipped)\.(\d{1,2})$/.exec(value);
 if(!match)return null;const step=Number(match[2]);return step<tourSteps.length?{status:match[1] as TourStatus['status'],step}:null;
}
export function safeTourPath(value:unknown):string|null{
 if(typeof value!=='string'||value.length>600||!/^\/(dashboard|volumes|glossary|about|characters(?:\/[\w-]+)?|read\/[\w-]+)(?:[?#]|$)/.test(value)||/[\\\r\n]/.test(value))return null;
 try{const url=new URL(value,'https://his.invalid');if(url.origin!=='https://his.invalid')return null;url.searchParams.delete('his-tour');return url.pathname+url.search+url.hash;}catch{return null;}
}
export function tourPreviewActive(){
 if(typeof window==='undefined')return false;
 if(new URLSearchParams(location.search).get('his-tour')==='1')return true;
 try{return !!sessionStorage.getItem(TOUR_RUN);}catch{return false;}
}
