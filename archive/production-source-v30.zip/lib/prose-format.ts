export const INKS = [
  { id: 'green', name: '吐槽綠', hex: '#2ecc71' },
  { id: 'blue', name: '笨蛋藍', hex: '#3498db' },
  { id: 'red', name: '中二紅', hex: '#e74c3c' },
  { id: 'amber', name: '被虐橘', hex: '#f39c12' },
  { id: 'violet', name: '自戀紫', hex: '#9b59b6' },
] as const;
export type InlineNode = { kind: 'text'; text: string } | { kind: 'note'; id: number } |
  { kind: 'bold' | 'italic' | 'strike' | 'underline' | 'color' | 'link' | 'spoiler'; color?: string; href?: string; children: InlineNode[] };

export function safeLink(value: string): string | null {
  const url = value.trim();
  if (!url || url.length > 2048 || /[\s\\]/u.test(url) || Array.from(url).some(c => c.charCodeAt(0) <= 31 || c.charCodeAt(0) === 127)) return null;
  if (/^\/(?!\/)/.test(url)) return url;
  try { const parsed = new URL(url); return ['http:', 'https:', 'mailto:'].includes(parsed.protocol) ? url : null; } catch { return null; }
}
export function inlineNodes(text: string, depth = 0): InlineNode[] {
  if (depth > 20) return [{ kind: 'text', text }];
  const result: InlineNode[] = [];
  function literal(value: string) { const last = result[result.length - 1]; if (last?.kind === 'text') last.text += value; else result.push({ kind: 'text', text: value }); }
  const escaped = (pos: number) => { let count = 0; for (let i = pos - 1; i >= 0 && text[i] === '\\'; i--) count++; return count % 2 === 1; };
  function closing(token: string, from: number) { let pos = text.indexOf(token, from); while (pos >= 0 && escaped(pos)) pos = text.indexOf(token, pos + token.length); return pos; }
  for (let i = 0; i < text.length;) {
    if (text[i] === '\\' && /[[\]\\*~#\-•𖣠]/u.test(text[i + 1] || '')) { literal(text[i + 1]); i += 2; continue; }
    const rest = text.slice(i);
    const tag = rest.match(/^\[(u|i|s|spoiler|color=(blue|red|green|amber|violet)|link=([^\]\n]+))\]/);
    let open = '', close = '', kind: 'bold'|'italic'|'strike'|'underline'|'color'|'link'|'spoiler' = 'bold', href: string | null = null;
    if (tag) {
      open = tag[0]; const name = tag[1].split('=')[0]; close = '[/' + name + ']';
      kind = name === 'u' ? 'underline' : name === 'i' ? 'italic' : name === 's' ? 'strike' : name as 'color'|'link'|'spoiler';
      if (kind === 'link') { try { href = safeLink(decodeURIComponent(tag[3])); } catch {} }
    } else if (rest.startsWith('**')) { open = close = '**'; kind = 'bold'; }
    else if (rest.startsWith('~~')) { open = close = '~~'; kind = 'strike'; }
    else if (rest.startsWith('*')) { open = close = '*'; kind = 'italic'; }
    if (open) {
      const end = closing(close, i + open.length);
      if (end > i + open.length) {
        const children = inlineNodes(text.slice(i + open.length, end), depth + 1);
        if (kind === 'link' && !href) result.push(...children);
        else result.push({ kind, children, ...(kind === 'color' ? { color: tag![2] } : {}), ...(href ? { href } : {}) });
        i = end + close.length; continue;
      }
    }
    const note = rest.match(/^\[(\d{1,3})\]/);
    if (note) { result.push({ kind: 'note', id: Number(note[1]) }); i += note[0].length; continue; }
    literal(text[i]); i++;
  }
  return result;
}

export type ProseBlock = { kind: 'paragraph'|'heading'|'list'|'image'|'divider'; lines: string[]; level?: 1|2|3; alignment?: 'left'|'center'|'right' };
export function proseBlocks(text: string, preserveBlank = false): ProseBlock[] {
  const blocks: ProseBlock[] = [];
  for (const raw of text.replace(/(?<![\n\\])•\s/g, '\n• ').split('\n')) {
    const aligned=raw.match(/^\[align=(left|center|right)\]([\s\S]*)\[\/align\]$/);
    const line=aligned?aligned[2]:raw,alignment=aligned?.[1] as ProseBlock['alignment'];
    const value = line.trim();
    if (!value) { if (preserveBlank) blocks.push({ kind: 'paragraph', lines: [''], alignment }); continue; }
    if (/^---+$/.test(value)) { blocks.push({ kind: 'divider', lines: [] }); continue; }
    const image = value.match(/^\[image:(\/api\/media\/[a-f0-9-]{36})\]$/);
    if (image) { blocks.push({ kind: 'image', lines: [image[1]] }); continue; }
    const heading = line.trimStart().match(/^(#{1,3})[ \t]+(.*)$/);
    if (heading) { blocks.push({ kind: 'heading', level: heading[1].length as 1|2|3, lines: [heading[2]], alignment }); continue; }
    const bullet = line.trimStart().match(/^(?:[-•𖣠])[ \t]+(.*)/u);
    if (bullet) { const previous = blocks[blocks.length - 1]; if (previous?.kind === 'list' && previous.alignment === alignment) previous.lines.push(bullet[1]); else blocks.push({ kind: 'list', lines: [bullet[1]], alignment }); continue; }
    blocks.push({ kind: 'paragraph', lines: [line], alignment });
  }
  return blocks;
}

export function plainText(text: string, concealSpoilers = false): string {
  function flatten(nodes: InlineNode[]): string { return nodes.map(n => n.kind === 'text' ? n.text : n.kind === 'note' ? '' : n.kind === 'spoiler' && concealSpoilers ? '▇▇▇' : flatten(n.children)).join(''); }
  return proseBlocks(text, true).filter(b => b.kind !== 'image' && b.kind !== 'divider').flatMap(b => b.lines.map(line => flatten(inlineNodes(line)))).join('\n');
}
export function proseHeadings(text: string, prefix: string) {
  return proseBlocks(text).flatMap((block,index) => block.kind === 'heading' ? [{ id: prefix + '-' + (index+1), level: block.level || 1, title: plainText(block.lines[0], true) || '未命名分段' }] : []);
}
export function referenceIds(text: string): number[] {
  const ids = new Set<number>();
  function walk(nodes: InlineNode[]) { for (const n of nodes) { if (n.kind === 'note') ids.add(n.id); else if (n.kind !== 'text') walk(n.children); } }
  for (const block of proseBlocks(text)) if (block.kind !== 'image') for (const line of block.lines) walk(inlineNodes(line));
  return [...ids];
}
