import { safeLink } from './prose-format';
export type CommentKind='visitor'|'author'|'reference';
export type CommentRecord={id:number;chapter_id:string;owner_key:string;name:string;kind:CommentKind;body:string;url:string;revision:number;created_at:string;updated_at:string;edited_by_author:number};
export type PublicComment=Omit<CommentRecord,'owner_key'|'chapter_id'> & {canEdit:boolean};
export function mayEditComment(row:Pick<CommentRecord,'owner_key'>,keys:readonly string[],author:boolean){return author||keys.includes(row.owner_key);}
export function publicComment(row:CommentRecord,keys:readonly string[],author:boolean):PublicComment {
 const {owner_key:_,chapter_id:__,...comment}=row;return {...comment,canEdit:mayEditComment(row,keys,author)};
}
export function cleanComment(value:unknown,author:boolean){
 if(!value||typeof value!=='object')return null;const x=value as Record<string,unknown>;
 if(typeof x.body!=='string'||!x.body.trim()||x.body.length>5000)return null;
 if(typeof x.name!=='string'||!x.name.trim()||x.name.length>80)return null;
 if(!['visitor','author','reference'].includes(String(x.kind))||(!author&&x.kind!=='visitor'))return null;
 if(typeof x.url!=='string'||x.url.length>2048)return null;
 const url=x.url.trim();if(url&&(!safeLink(url)||!/^https?:\/\//i.test(url)))return null;
 if(x.kind==='reference'&&!url)return null;
 return {name:x.name.trim(),body:x.body.trim(),kind:x.kind as CommentKind,url};
}
