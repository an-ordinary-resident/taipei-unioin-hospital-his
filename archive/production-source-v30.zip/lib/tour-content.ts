import { tourSteps } from './reader-tour';

export type TourCopy={title:string;body:string;hint:string};
export type TourContent={welcome:TourCopy;complete:TourCopy;steps:Record<string,TourCopy>};
export const DEFAULT_TOUR:TourContent={
 welcome:{title:'第一次登入慈愛院區 HIS 系統嗎？',body:'我是「一個平凡的住院醫師」。歡迎來到瓷礙魔窟，花約 3-5 分鐘熟悉系統；至少迷路時知道該按哪裡。',hint:'可隨時從側欄重新開啟教學。'},
 complete:{title:'報到完成，訪客識別證已啟用。',body:'恭喜，你已具備在慈愛院區迷路的基本資格。準備好就開始閱讀，也歡迎留下你的會診意見。',hint:''},
 steps:Object.fromEntries(tourSteps.map(s=>[s.id,{title:s.title,body:s.body,hint:s.hint||''}]))
};
// Store text only. Authors cannot change routes, selectors or access restrictions.
export function cleanTourContent(input:unknown):TourContent|null{
 if(!input||typeof input!=='object')return null;
 const value=input as TourContent;
 function copy(v:unknown):TourCopy|null{
  if(!v||typeof v!=='object')return null;const c=v as TourCopy;
  if(typeof c.title!=='string'||!c.title.trim()||c.title.length>100||typeof c.body!=='string'||!c.body.trim()||c.body.length>1500||typeof c.hint!=='string'||c.hint.length>500)return null;
  return {title:c.title.trim(),body:c.body.trim(),hint:c.hint.trim()};
 }
 const welcome=copy(value.welcome),complete=copy(value.complete);
 if(!welcome||!complete||!value.steps||typeof value.steps!=='object'||Array.isArray(value.steps))return null;
 const steps:Record<string,TourCopy>={};
 for(const step of tourSteps){const c=copy(value.steps[step.id]);if(!c)return null;steps[step.id]=c;}
 return {welcome,complete,steps};
}
export function tourContent(value:unknown):TourContent{
 const v=value as Partial<TourContent>|null;
 // New steps use their defaults when an older published configuration is loaded.
 return cleanTourContent({...DEFAULT_TOUR,...v,steps:{...DEFAULT_TOUR.steps,...v?.steps}})||DEFAULT_TOUR;
}
