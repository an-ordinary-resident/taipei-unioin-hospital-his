import { database } from './content';
export const SETTINGS_ID='site-announcement';
export const DEFAULT_ANNOUNCEMENT={text:'院內公告｜歡迎來到瓷礙魔窟。請妥善保管您的理智，並尊重作者原創，勿擅自複製轉載。',enabled:true};
export async function announcement(author=false){
 const row=await database().prepare('SELECT draft,published,revision FROM documents WHERE id=?').bind(SETTINGS_ID).first<{draft:string;published:string|null;revision:number}>();
 const value=row?(author?JSON.parse(row.draft):row.published?JSON.parse(row.published):{text:'',enabled:false}):DEFAULT_ANNOUNCEMENT;
 return {...value,revision:author?(row?.revision||0):undefined,hasDraft:author&&!!row&&row.draft!==row.published};
}
