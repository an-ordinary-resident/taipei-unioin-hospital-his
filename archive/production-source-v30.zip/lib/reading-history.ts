import type { NovelDoc } from './content';
import { plainText,proseBlocks,type ProseBlock } from './prose-format';
import { chapterKind } from './story-access';
export type ReadingPoint={chapterId:string;block:string|null;offset:number;percent:number;updatedAt:number};
export type ReaderHistory={lastRead:ReadingPoint|null;bookmark:ReadingPoint|null};
export type ChapterStats={views:number;likes:number;liked:boolean};
export function passageKeys(blocks:ProseBlock[]){
 const repeats=new Map<string,number>();
 return blocks.map(block=>{
  const value=block.kind+':'+(block.kind==='image'?block.lines.join(''):block.lines.map(line=>plainText(line)).join('\n'));
  let hash=2166136261;for(const character of value){hash^=character.codePointAt(0)!;hash=Math.imul(hash,16777619);}
  const key=(hash>>>0).toString(36),occurrence=(repeats.get(key)||0)+1;repeats.set(key,occurrence);
  return 'b-'+key+'-'+occurrence;
 });
}
export function cleanReadingPoint(value:unknown,chapter:Pick<NovelDoc,'id'|'body'>,now=Date.now()):ReadingPoint|null{
 if(!value||typeof value!=='object')return null;
 const p=value as Record<string,unknown>;
 if(p.chapterId!==chapter.id||!(p.block===null||typeof p.block==='string')||typeof p.offset!=='number'||!Number.isFinite(p.offset)||p.offset<0||p.offset>1||typeof p.percent!=='number'||!Number.isFinite(p.percent)||p.percent<0||p.percent>100||typeof p.updatedAt!=='number'||!Number.isFinite(p.updatedAt))return null;
 if(p.block!==null&&!passageKeys(proseBlocks(chapter.body, true).filter(block=>block.kind!=='paragraph'||block.lines[0].trim())).includes(p.block as string))return null;
 return {chapterId:chapter.id,block:p.block as string|null,offset:p.offset,percent:p.percent,updatedAt:Math.max(0,Math.min(now,p.updatedAt))};
}
export function firstReadableChapter(all:readonly NovelDoc[]){
 const volumes=all.filter(d=>d.kind==='volume'&&!d.locked&&d.volumeType!=='bonus').sort((a,b)=>a.order-b.order||a.id.localeCompare(b.id));
 for(const volume of volumes){const first=all.filter(d=>d.kind==='chapter'&&d.volume===volume.id&&!d.locked&&chapterKind(d)==='main').sort((a,b)=>a.order-b.order||a.id.localeCompare(b.id))[0];if(first)return first;}
 return all.find(d=>d.kind==='chapter'&&!d.locked);
}
export function resumeRecord(all:readonly NovelDoc[],history:ReaderHistory){
 for(const [source,point] of [['bookmark',history.bookmark],['last',history.lastRead]] as const){
  const chapter=point&&all.find(d=>d.kind==='chapter'&&!d.locked&&d.id===point.chapterId);
  if(chapter)return {chapter,point,source};
 }
 return {chapter:firstReadableChapter(all),point:null,source:'first' as const};
}
