export const readerAvatars=[
 {id:'ciai-pingfan',label:'眼鏡吐槽男',src:'/reader-avatars/pingfan.jpg'},
 {id:'ciai-caiyi',label:'笨蛋慣老闆',src:'/reader-avatars/caiyi.jpg'},
 {id:'ciai-baichuan',label:'浮誇自戀狂',src:'/reader-avatars/baichuan.jpg'},
 {id:'ciai-zijie',label:'中二處置狂',src:'/reader-avatars/zijie.jpg'},
 {id:'ciai-shuyi',label:'被虐工作狂',src:'/reader-avatars/shuyi.jpg'},
];
export type ReaderProfile={name:string;role:string;motto:string;avatar:string;sanity:number};
export const initialProfile:ReaderProfile={name:'VISITOR-001',role:'訪客',motto:'今天也要平安交班。',avatar:'doctor',sanity:88};
export function sanityValue(value:unknown,fallback=88){return typeof value==='number'&&Number.isFinite(value)?Math.max(0,Math.min(100,Math.round(value))):fallback;}
export function checkedProfile(raw:unknown,fallback:ReaderProfile):ReaderProfile{
 const p=(raw&&typeof raw==='object'?raw:{}) as Partial<ReaderProfile>;
 const avatar=typeof p.avatar==='string'&&(['doctor','visitor','coffee','heart'].includes(p.avatar)||readerAvatars.some(v=>v.id===p.avatar)||(/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(p.avatar)&&p.avatar.length<250000))?p.avatar:'doctor';
 return {name:typeof p.name==='string'&&p.name.trim()?p.name.slice(0,80):fallback.name,role:typeof p.role==='string'&&p.role.trim()?p.role.slice(0,80):fallback.role,motto:typeof p.motto==='string'?p.motto.slice(0,200):fallback.motto,avatar,sanity:sanityValue(p.sanity,fallback.sanity)};
}
