import { tourPreviewActive } from './reader-tour';
import type { ReaderHistory,ChapterStats,ReadingPoint } from './reading-history';
let boot:Promise<ReaderHistory>|null=null;
export function readerHistory(refresh=false):Promise<ReaderHistory>{
 if(refresh)boot=null;
 if(!boot){
  const request=async()=>{const response=await fetch('/api/reader-state',{cache:'no-store'});const data=await response.json() as ReaderHistory&{error?:string};if(!response.ok)throw Error(data.error||'閱讀紀錄暫時無法載入。');return data;};
  boot=(async()=>navigator.locks?await navigator.locks.request('his-reader-cookie',request):await request())().catch(error=>{boot=null;throw error;});
 }
 return boot!;
}
export async function readerMutation(payload:{action:'view'|'progress'|'bookmark'|'clear-bookmark'|'like';chapterId?:string;point?:ReadingPoint;liked?:boolean},keepalive=false){
 if((payload.action==='view'||payload.action==='progress')&&tourPreviewActive())return {ok:true};
 const response=await fetch('/api/reader-state',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),keepalive});
 const data=await response.json() as {ok?:boolean;stats?:ChapterStats;error?:string};
 if(!response.ok){if(response.status===409)boot=null;throw Error(data.error||'閱讀紀錄未能儲存。');}
 if(payload.action!=='view'&&payload.action!=='like')boot=null;
 return data;
}
