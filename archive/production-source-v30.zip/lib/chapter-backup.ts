import type { NovelDoc } from './content';
import { INKS,inlineNodes,proseBlocks,safeLink,type InlineNode } from './prose-format';
import { wordCount } from './rich-text';
import { chapterKind,chapterLabels,volumeLabel } from './story-access';

const htmlEscape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const mdEscape=(s:string)=>s.replace(/[\\`*_[\]<>~#|]/g,'\\$&');
function destination(value:string,origin:string){
 const safe=safeLink(value);if(!safe)return '';
 if(!safe.startsWith('/'))return safe;
 try{const base=new URL(origin);return ['https:','http:'].includes(base.protocol)?new URL(safe,base.origin).href:safe;}catch{return safe;}
}
function htmlInline(nodes:InlineNode[],origin:string):string{
 return nodes.map(node=>{
  if(node.kind==='text')return htmlEscape(node.text);
  if(node.kind==='note')return '<sup><a href="#note-'+node.id+'">['+node.id+']</a></sup>';
  const body=htmlInline(node.children,origin);
  if(node.kind==='color')return '<span style="color:'+INKS.find(i=>i.id===node.color)!.hex+'">'+body+'</span>';
  if(node.kind==='link'){const href=destination(node.href||'',origin);return href?'<a href="'+htmlEscape(href)+'" style="color:#3498db;text-decoration:underline">'+body+'</a>':body;}
  if(node.kind==='spoiler')return '<span data-spoiler="true" title="防劇透文字" style="background-color:#111827;border-radius:3px"><span style="opacity:0">'+body+'</span></span>';
  const tag={bold:'strong',italic:'em',strike:'s',underline:'u'}[node.kind];
  return '<'+tag+'>'+body+'</'+tag+'>';
 }).join('');
}
function markdownInline(nodes:InlineNode[],origin:string):string{
 return nodes.map(node=>{
  if(node.kind==='text')return mdEscape(node.text);
  if(node.kind==='note')return '[\\['+node.id+'\\]](#note-'+node.id+')';
  if(node.kind==='color'||node.kind==='underline'||node.kind==='spoiler')return htmlInline([node],origin);
  const body=markdownInline(node.children,origin);
  if(node.kind==='link'){const href=destination(node.href||'',origin);return href?'['+body+'](<'+href.replace(/</g,'%3C').replace(/>/g,'%3E')+'>)':body;}
  const marker={bold:'**',italic:'*',strike:'~~'}[node.kind];
  return marker+body+marker;
 }).join('');
}
export function exportProse(text:string,format:'markdown'|'html',origin=''):string{
 return proseBlocks(text).map(block=>{
  if(block.kind==='divider')return format==='html'?'<hr>':'---';
  if(block.kind==='image'){const src=destination(block.lines[0],origin);return format==='html'?'<img src="'+htmlEscape(src)+'" alt="作品插圖" style="max-width:100%;height:auto">':'![作品插圖](<'+src+'>)';}
  const inline=(line:string)=>format==='html'?htmlInline(inlineNodes(line),origin):markdownInline(inlineNodes(line),origin);
  const aligned=block.alignment&&block.alignment!=='left';
  if(format==='html'||aligned){
   const attrs=block.alignment?' style="text-align:'+block.alignment+'"':'';
   const lines=block.lines.map(line=>htmlInline(inlineNodes(line),origin));
   if(block.kind==='list')return '<ul'+attrs+'>'+lines.map(line=>'<li>'+line+'</li>').join('')+'</ul>';
   const tag=block.kind==='heading'?'h'+block.level:'p';
   return '<'+tag+attrs+'>'+lines[0]+'</'+tag+'>';
  }
  if(block.kind==='list')return block.lines.map(line=>'- '+inline(line)).join('\n');
  if(block.kind==='heading')return '#'.repeat(block.level||1)+' '+inline(block.lines[0]);
  return inline(block.lines[0]).replace(/^(\s*)(?=(?:[-+>]|\d+[.)])\s|---+$)/,'$1\\');
 }).join('\n\n');
}
export function chapterBackup(doc:NovelDoc,records:readonly NovelDoc[],origin='',at=new Date()){
 const volume=records.find(v=>v.kind==='volume'&&v.id===doc.volume);
 const updated=[...records.filter(d=>d.id!==doc.id),doc];
 const label=chapterLabels(updated).find(d=>d.id===doc.id)?.chapterLabel||doc.chapterLabel||'未分類';
 const kind={main:'正式章節',interlude:'間章',appendix:'附錄',afterword:'後記',bonus:'番外篇'}[chapterKind(doc)];
 const metadata=[
  ['所屬卷別',volume?volumeLabel(volume)+' · '+volume.title:doc.volume],
  ['章節代號',/^\d+$/.test(label)?'Log '+label:label],
  ['章節分類',volume?.volumeType==='bonus'?'番外篇':kind],
  ['病歷分類 / 副標題',doc.subtitle||'未填寫'],
  ['登場人物',(doc.cast||[]).join('、')||'未填寫'],
  ['內文字數',wordCount(doc.body).toLocaleString('zh-TW')+' 字'],
  ['閱讀時間',doc.readingMinutes||'約 '+Math.max(1,Math.ceil(wordCount(doc.body)/400))+' 分鐘'],
  ['備份時間',at.toISOString()],
 ];
 const title=doc.title||'未命名章節',notes=doc.notes||[];
 const intro='此備份包含目前編輯中的內容（含尚未儲存的修改）。顏色、底線、對齊與防劇透黑框使用 HTML 補充標記；實際呈現依匯入平台支援。';
 const summary=doc.summary||'尚未填寫本章大綱。';
 const markdown='# '+mdEscape(title)+'\n\n'+intro+'\n\n## 本章資訊\n\n'+metadata.map(([k,v])=>'- **'+k+'：** '+mdEscape(v)).join('\n')+'\n\n### 本章大綱\n\n'+summary.split('\n').map(mdEscape).join('\n\n')+'\n\n## 完整內文\n\n'+exportProse(doc.body,'markdown',origin)+'\n\n## 全部用詞註釋\n\n'+(notes.length?notes.map(n=>'<a id="note-'+n.id+'"></a>\n\n### ['+n.id+'] '+mdEscape(n.term)+(n.tags?.length?'\n\n屬性標籤：'+n.tags.map(mdEscape).join('、'):'')+'\n\n'+exportProse(n.text,'markdown',origin)).join('\n\n'):'本章無用詞註釋。')+'\n';
 const content='<h1>'+htmlEscape(title)+'</h1><p>'+htmlEscape(intro)+'</p><h2>本章資訊</h2><ul>'+metadata.map(([k,v])=>'<li><strong>'+k+'：</strong>'+htmlEscape(v)+'</li>').join('')+'</ul><h3>本章大綱</h3><p>'+htmlEscape(summary).replace(/\n/g,'<br>')+'</p><h2>完整內文</h2>'+exportProse(doc.body,'html',origin)+'<h2>全部用詞註釋</h2>'+(notes.length?notes.map(n=>'<section id="note-'+n.id+'"><h3>['+n.id+'] '+htmlEscape(n.term)+'</h3>'+(n.tags?.length?'<p>屬性標籤：'+htmlEscape(n.tags.join('、'))+'</p>':'')+exportProse(n.text,'html',origin)+'</section>').join(''):'<p>本章無用詞註釋。</p>');
 const html='<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>'+htmlEscape(title)+'</title></head><body><article style="font-family:Arial,Microsoft JhengHei,sans-serif;line-height:1.9;max-width:850px;margin:auto;color:#172f45;background-color:#fff">'+content+'</article></body></html>';
 const filename=((volume?volumeLabel(volume)+'-':'')+title).replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').replace(/^\.+|[. ]+$/g,'').slice(0,100)||'章節備份';
 return {markdown,html,filename:filename+'-'+at.toISOString().slice(0,10)};
}
