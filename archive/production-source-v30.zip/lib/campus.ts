// Source: 慈愛院區住院大樓工程設計圖冊, A-01–A-05, pp. 3–9.
// Room geometry is a navigable scene reconstruction, not a measured survey.
export type CampusFloor = { id:string; title:string; group:string; zones:[string,string,string]; support:string; beds?:[number|null,number|null,number|null] };
export const campusFloors:CampusFloor[] = [
 {id:'RF',title:'空中療癒花園',group:'屋頂花園',zones:['四季芳香園藝治療區','無障礙復健與沐光廣場','機電設備與高空排氣區'],support:'無障礙迎賓門廳、270° 臺北盆地觀景長廊'},
 {id:'13F',title:'精神醫學・教學行政',group:'高層病房',zones:['精神醫學急性病房','精神科日間留院中心','臨床技能中心・醫學圖書館'],support:'院部行政中心、醫療品質管理中心',beds:[32,null,null]},
 {id:'12F',title:'內科四・感染症',group:'高層病房',zones:['頭等尊爵綜合內科病房','風濕免疫與高齡醫學病房','感染症與結核負壓病房'],support:'內科部主任辦公室、醫局行政與討論室',beds:[20,32,24]},
 {id:'11F',title:'外科・骨科與神經外科',group:'高層病房',zones:['骨科與脊椎微創外科病房','神經外科與重大外傷病房','泌尿外科與整形重建病房'],support:'專科換藥室、石膏室、外科值班室',beds:[32,32,32]},
 {id:'10F',title:'內科三・故事主場景',group:'高層病房',zones:['一般內科暨感染症病房','內分泌及新陳代謝科病房','家庭醫學與整合醫學病房'],support:'內科住院醫師值班室、臨床教學討論室',beds:[32,32,32]},
 {id:'9F',title:'內科二・腸胃腎臟神經',group:'高層病房',zones:['胃腸肝膽內科病房','腎臟內科病房','神經內科與腦中風病房'],support:'腹部超音波室、專科研究醫師值班室',beds:[32,32,32]},
 {id:'8F',title:'內科一・心肺照護',group:'高層病房',zones:['心臟血管內科病房','胸腔內科病房','慢性呼吸照護病房'],support:'肺功能檢查室、心電圖室、呼吸治療室',beds:[32,32,32]},
 {id:'7F',title:'外科・手術後照護',group:'高層病房',zones:['一般及肝膽消化外科病房','胸腔及心臟血管外科病房','大腸直腸與乳房外科病房'],support:'外科專科護理師辦公室',beds:[32,32,32]},
 {id:'6F',title:'婦幼・五官・復健',group:'高層病房',zones:['婦產科病房與產房','耳鼻喉頭頸外科與眼科病房','復健醫學病房與治療大廳'],support:'裙樓結構轉換緩衝平台',beds:[32,32,32]},
 {id:'5F',title:'重症加護醫療',group:'診療裙樓',zones:['內科加護 MICU 24 床・CCU 8 床','外科加護 SICU 16 床・心導管室 2 間','RCC 16 床・血液透析 40 床'],support:'家屬等候廳、病情會談室、衛星藥局'},
 {id:'4F',title:'手術與麻醉',group:'診療裙樓',zones:['微創暨達文西手術中心 OR 1–8','標準無菌手術室 OR 9–14・PACU','中央滅菌供應中心・麻醉部'],support:'手術家屬等候大廳、冰凍切片氣送站'},
 {id:'3F',title:'檢查與臨床檢驗',group:'診療裙樓',zones:['消化道內視鏡中心','心血管與神經生理檢查中心','臨床檢驗醫學部・中央實驗室'],support:'門診抽血服務櫃檯、全院氣送管總交換站'},
 {id:'2F',title:'日間治療與門診支援',group:'診療裙樓',zones:['日間化學治療與輸血中心','高階健康管理中心','病歷資訊室・醫療事務部'],support:'志工服務中心、醫病關係公關室'},
 {id:'1F',title:'急診・影像・住院服務',group:'診療裙樓',zones:['住院服務中心・藥局大廳','放射線診斷與高階影像醫學部','急診醫學部 ER'],support:'西側無障礙風雨廊道連通第一門診大樓'},
 {id:'B1F',title:'病理・生活與後勤',group:'地下支援',zones:['解剖與分子病理部','美食廣場・24 小時便利商店','營養部中央廚房・被服中心'],support:'B1 跨棟醫勤地下連通道'},
 {id:'B2F',title:'放射治療與訪客停車',group:'地下支援',zones:['放射腫瘤治療中心','訪客與陪病家屬停車場','醫療廢棄物冷藏庫・污水廠'],support:'防空避難室、院區防災備援物資庫'},
 {id:'B3F',title:'機電與員工停車',group:'地下支援',zones:['特高壓變電站・不斷電系統','醫護員工汽機車停車場','消防蓄水池・醫療純水廠'],support:'SRC 隔震墊巡檢廊道'},
];
export type SpaceKind='four'|'double'|'single'|'isolation'|'station'|'treatment'|'medication'|'utility'|'meeting'|'oncall'|'stairs'|'core';
export type WardSpace={id:string;name:string;kind:SpaceKind;beds?:number;area?:string;description:string;features:string[];scene?:string};
const rooms=(numbers:string[],kind:SpaceKind,beds:number,area:string,name:string,description:string,features:string[]):WardSpace[]=>numbers.map(n=>({id:'10A-'+n,name,kind,beds,area,description,features}));
export const wardSpaces:WardSpace[]=[
 ...rooms(['01','02','03','05','06'],'four',4,'28.5 m²','四人健保病房','沿北側外牆配置的四床病室。窗面引入自然光，病床以隱私簾分隔，入口旁設獨立衛浴。',['四床配置・隱私簾','無障礙防滑衛浴','床頭醫療氣體帶與呼叫設備']),
 ...rooms(['07','08','09','10'],'double',2,'18.2 m²','雙人差額病房','南側的雙床病室，提供較安靜的休息空間；床邊保留照護與檢查的活動位置。',['兩床配置・床邊工作空間','乾濕分離無障礙衛浴','置物櫃、電視與家屬陪伴椅']),
 ...rooms(['11','12','15'],'single',1,'16.5 m²','單人特等病房','位於病房區東側的單人病室，兼顧休養隱私與家屬陪伴。',['單床配置・獨立衛浴','陪病沙發床與書桌','隔音牆體與會客空間']),
 {id:'10A-16',name:'負壓隔離病房',kind:'isolation',beds:1,area:'19.0 m²',description:'位於北側東端。由主走道先進入前室，再進入單人隔離病室，設獨立衛浴與專用排氣。',features:['雙門互鎖氣密前室','獨立衛浴・壓差顯示器','圖冊設定：−12 Pa、≥12 ACH、HEPA 排氣'],scene:'隔著觀察窗也能看見病室；進出必須經過前室，讓故事裡的隔離照護有清楚的空間層次。'},
 {id:'station',name:'中央護理站與醫師工作區',kind:'station',description:'朝向主走道的開放弧形護理站。後方整合醫師工作區，便於查房前討論與跨職類溝通。',features:['前排 6 部 COW 行動護理車充電座','中央生理監視器與急救設備','後排 5 台 HIS／PACS 工作站'],scene:'查房前看病歷、接電話、確認醫囑，再從這裡出發走進病房。10A 的值班日常，在這個工作核心交會。'},
 {id:'treatment',name:'處置治療室',kind:'treatment',description:'緊鄰護理站配置，讓治療設備、衛材與人員工作區保持短距離連接。',features:['急救車停靠位置','超音波設備與處置檯','洗手設備與衛材收納']},
 {id:'medication',name:'配藥室',kind:'medication',description:'清潔藥品準備空間，與污物處理室分室設置。',features:['ADC 智慧藥櫃','配藥工作檯','藥品與清潔物品收納']},
 {id:'utility',name:'污物處理室',kind:'utility',description:'獨立處理使用後的器材與污物，避免與清潔藥品準備混用空間。',features:['獨立隔間與洗滌設備','污物暫存位置','與配藥室分室管理']},
 {id:'meeting',name:'病情解釋與會談室',kind:'meeting',description:'提供醫護與家屬可坐下討論的獨立空間，兼顧隱私與安全。',features:['會談桌與家屬座椅','獨立隔間','安全求救連線']},
 {id:'oncall',name:'醫師值班室',kind:'oncall',description:'位於病房支援區的值班休息空間，與主走道及護理工作區相連。',features:['值班休息與隨身物品收納','靠近病房，便於返回工作區','家具配置為場景補繪'],scene:'離護理站不遠的一扇門。能不能在裡面睡滿六小時，則是另一份病程紀錄。'},
 {id:'stairs',name:'S-A 安全梯',kind:'stairs',description:'位於 A 區末端的獨立樓梯間，與中央核心筒形成兩端的垂直交通配置。',features:['獨立樓梯間','防火門與樓梯平台','連接各層 A 區']},
 {id:'core',name:'中央梯廳與病房入口',kind:'core',description:'由中央核心筒抵達 A 區入口，再進入 10A 主走道。',features:['訪客電梯 P1–P4','病床電梯 B1–B2・服務電梯 S1','外側訪客與內側醫勤分流']},
];
export const wardSpace=(id:string)=>wardSpaces.find(space=>space.id===id);
export type CampusLocation={building:'campus'|'inpatient'|'outpatient';floor:string;ward:boolean;space:string|null};
export function parseCampusLocation(search:string):CampusLocation{
 const p=new URLSearchParams(search);const building=p.get('building')==='outpatient'?'outpatient':p.get('building')==='inpatient'?'inpatient':'campus';
 const ward=building==='inpatient'&&p.get('ward')==='10A';
 return {building,floor:ward?'10F':campusFloors.some(f=>f.id===p.get('floor'))?p.get('floor')!:'10F',ward,space:ward&&wardSpace(p.get('space')||'')?p.get('space'):null};
}
export function campusHref(location:CampusLocation){
 if(location.building==='campus')return '/campus';
 const p=new URLSearchParams({building:location.building});
 if(location.building==='inpatient'){p.set('floor',location.ward?'10F':location.floor);if(location.ward)p.set('ward','10A');if(location.ward&&location.space&&wardSpace(location.space))p.set('space',location.space);}
 return '/campus?'+p.toString();
}
