import type { JSONContent } from '@tiptap/core';
import type { Annotation } from './rich-text';

/** Rename reference nodes once, so swaps cannot cascade or touch literal text/URLs. */
export function reorderAnnotations(doc: JSONContent, notes: Annotation[], requestedOrder?: number[]) {
  const references: number[] = [];
  function visit(node: JSONContent) {
    if (node.type === 'annotation') references.push(Number(node.attrs?.id));
    node.content?.forEach(visit);
  }
  visit(doc);
  const byId = new Map(notes.map(note => [note.id, note]));
  const missing = [...new Set(references.filter(id => !byId.has(id)))];
  if (missing.length) throw new Error('內文中的註解 '+missing.map(id=>'['+id+']').join('、')+' 尚無解說，請先補齊或移除後再排序。');
  const order = [...new Set([...(requestedOrder ?? references), ...notes.map(note => note.id)])].filter(id => byId.has(id));
  const ids = new Map(order.map((id, index) => [id, index + 1]));
  function rename(node: JSONContent): JSONContent {
    return {
      ...node,
      ...(node.type === 'annotation' ? { attrs: { ...node.attrs, id: ids.get(Number(node.attrs?.id)) } } : {}),
      ...(node.content ? { content: node.content.map(rename) } : {}),
    };
  }
  return { doc: rename(doc), notes: order.map(id => ({ ...byId.get(id)!, id: ids.get(id)! })) };
}

export function removeAnnotation(doc: JSONContent, id: number): JSONContent {
  return { ...doc, ...(doc.content ? { content: doc.content.filter(node => !(node.type === 'annotation' && Number(node.attrs?.id) === id)).map(node => removeAnnotation(node, id)) } : {}) };
}
