import type { Annotation } from './rich-text';
import { cleanTags } from './glossary';

export type LinkedTermRow={id:string;draft:string;published:string|null;revision:number};
export const validGlossaryId=(id:unknown):id is string=>typeof id==='string'&&/^[-a-z0-9]{1,80}$/.test(id);

// Links are explicit IDs. Names never imply a relationship with the glossary.
export function resolveLinkedNotes(notes:Annotation[],rows:Map<string,LinkedTermRow>,author=false):Annotation[]{
 return notes.map(note=>{
  const {glossaryRevision:_,glossaryPublished:__,glossaryHasDraft:___,glossaryMissing:____,...snapshot}=note;
  if(!note.glossaryId)return snapshot;
  const row=rows.get(note.glossaryId),source=author?row?.draft:row?.published;
  const value=source?JSON.parse(source):null;
  return {...snapshot,...(value?{term:value.term,text:value.text,tags:cleanTags(value.tags)||[]}:{}),...(author?{glossaryRevision:row?.revision,glossaryPublished:!!row?.published,glossaryHasDraft:!!row&&row.draft!==row.published,glossaryMissing:!row}:{})};
 });
}

// A chapter must never publish a glossary draft through its stored fallback.
export function publicationNotes(notes:Annotation[],rows:Map<string,LinkedTermRow>):Annotation[]{
 const unavailable=notes.filter(note=>note.glossaryId&&!rows.get(note.glossaryId)?.published);
 if(unavailable.length)throw new Error('請先刊登共用詞條，或解除連結改為本章專用：'+unavailable.map(note=>note.term).join('、'));
 return resolveLinkedNotes(notes,rows);
}

export async function linkedTermRows(db:D1Database,notes:Annotation[]):Promise<Map<string,LinkedTermRow>>{
 const ids=[...new Set(notes.map(note=>note.glossaryId).filter(validGlossaryId))];
 if(!ids.length)return new Map();
 const {results}=await db.prepare('SELECT id,draft,published,revision FROM glossary_terms WHERE id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(ids)).all<LinkedTermRow>();
 return new Map(results.map(row=>[row.id,row]));
}
