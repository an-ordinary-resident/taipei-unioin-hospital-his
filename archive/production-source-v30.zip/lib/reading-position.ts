export type PassageRect = { top: number; bottom: number; height: number };

/** Empty paragraphs have no reader-block marker, so neither spacing nor blank lines add progress. */
export function passagePosition(rects: PassageRect[], line: number, viewportBottom: number) {
 if(!rects.length)return {index:0,offset:0,percent:0};
 let index=0;
 for(let i=0;i<rects.length;i++){if(rects[i].top<=line)index=i;else break;}
 const rect=rects[index],offset=Math.max(0,Math.min(1,(line-rect.top)/Math.max(1,rect.height)));
 const complete=rects[rects.length-1].bottom<=viewportBottom;
 return {index,offset,percent:complete?100:Math.min(100,(index+offset)/rects.length*100)};
}

export function currentReadingPosition() {
 const blocks=Array.from(document.querySelectorAll<HTMLElement>('.reader-paper [data-reader-block]'));
 const line=(document.querySelector('.topbar')?.getBoundingClientRect().bottom||0)+24;
 return {blocks,...passagePosition(blocks.map(node=>node.getBoundingClientRect()),line,window.innerHeight)};
}
