export const READER_ROLES = [
 {value:'visitor',label:'訪客',short:'訪',rank:0,description:'閱讀正篇小說與人物基本介紹'},
 {value:'student',label:'實習醫學生',short:'習',rank:1,description:'包含訪客內容，解鎖人物詳細設定'},
 {value:'resident',label:'住院醫師',short:'住',rank:2,description:'包含實習醫學生內容，解鎖番外篇'},
 {value:'attending',label:'主治醫師',short:'主',rank:3,description:'包含全部閱讀內容，解鎖人物背景設定'},
] as const;
export type ReaderRole=typeof READER_ROLES[number]['value'];
export function roleInfo(value:unknown){return READER_ROLES.find(r=>r.value===value)||READER_ROLES[0]}
