import type { NovelDoc } from './content';

export function chapterKind(doc: Pick<NovelDoc,'id'|'chapterType'>): NonNullable<NovelDoc['chapterType']> {
  if (doc.chapterType && doc.chapterType !== 'main') return doc.chapterType;
  if (doc.id === 'afterword' || doc.id.startsWith('afterword-')) return 'afterword';
  if (doc.id.startsWith('attachment-') || doc.id === 'music') return 'appendix';
  return doc.chapterType || 'main';
}

export function chapterLabels(records: readonly NovelDoc[]): NovelDoc[] {
  const labels = new Map<string,string>();
  let number = 0;
  const volumes = records.filter(d => d.kind === 'volume').sort((a,b) => a.order-b.order || a.id.localeCompare(b.id));
  for (const volume of volumes) {
    const chapters = records.filter(d => d.kind === 'chapter' && d.volume === volume.id).sort((a,b) => a.order-b.order || a.id.localeCompare(b.id));
    for (const chapter of chapters) {
      const kind = chapterKind(chapter);
      const label = kind === 'interlude' ? '間章' : kind === 'appendix' ? '附錄' : kind === 'afterword' ? '後記' : isBonusChapter(chapter, volumes) ? '番外篇' : String(++number);
      labels.set(chapter.id, label);
    }
  }
  return records.map(d => d.kind === 'chapter' ? {...d, chapterType: chapterKind(d), chapterLabel: labels.get(d.id) || '未分類'} : d);
}

export function isBonusChapter(doc: NovelDoc, volumes: readonly NovelDoc[]) {
  return doc.chapterType === 'bonus' || volumes.some(v => v.kind === 'volume' && v.id === doc.volume && v.volumeType === 'bonus');
}

// Filter before passing records to pages or client components, including direct chapter requests.
export function applyStoryAccess(doc: NovelDoc, volumes: readonly NovelDoc[], rank: number | null): NovelDoc {
  if (doc.kind === 'volume') return { ...doc, volumeType: doc.volumeType || 'main', locked: rank !== null && rank < 2 && doc.volumeType === 'bonus' };
  if (doc.kind !== 'chapter') return doc;
  const chapterType = chapterKind(doc);
  if (rank !== null && rank < 2 && isBonusChapter(doc, volumes)) {
    return { ...doc, chapterType, body: '', image: '', notes: [], cast: [], summary: '', readingMinutes: '', details: '', background: '', profileSections: [], locked: true };
  }
  return { ...doc, chapterType, locked: false };
}

export function volumeLabel(volume: Pick<NovelDoc, 'volumeType' | 'order'>) {
  return volume.volumeType === 'bonus' ? '番外篇' : '第 ' + volume.order + ' 卷';
}
