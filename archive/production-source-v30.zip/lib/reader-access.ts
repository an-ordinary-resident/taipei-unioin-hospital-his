import { cookies } from 'next/headers';
import { roleInfo } from './reader-roles';
export async function readerIdentity(){return roleInfo((await cookies()).get('his-reader-role')?.value)}
