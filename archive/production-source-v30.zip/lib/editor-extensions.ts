import { Extension, Node, Mark, mergeAttributes } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import { TextStyle, Color } from '@tiptap/extension-text-style';
import { Plugin } from '@tiptap/pm/state';
import { INKS, safeLink } from './prose-format';
import { MEDIA_URL, storedProse } from './editor-document';

const AnnotationReference = Node.create({
  name: 'annotation', group: 'inline', inline: true, atom: true,
  addAttributes: () => ({ id: { default: 1, parseHTML: el => Number(el.getAttribute('data-annotation-id')) } }),
  parseHTML: () => [{ tag: 'sup[data-annotation-id]', getAttrs: el => /^\d{1,3}$/.test(el.getAttribute('data-annotation-id') || '') ? {} : false }],
  renderHTML: ({ node, HTMLAttributes }) => ['sup', mergeAttributes(HTMLAttributes, { 'data-annotation-id': node.attrs.id, class: 'annotation-ref annotation-chip', contenteditable: 'false', role: 'button', tabindex: '0', 'aria-label': '編輯註解 ' + node.attrs.id, title: '編輯註解 [' + node.attrs.id + ']' }), '[' + node.attrs.id + ']'],
});
const UploadedImage = Image.extend({
  parseHTML: () => [{ tag: 'img[src]', getAttrs: el => MEDIA_URL.test(el.getAttribute('src') || '') ? {} : false }],
}).configure({ allowBase64: false });

const PaletteColor = Color.extend({
  addGlobalAttributes() {
    return [{ types: ['textStyle'], attributes: { color: {
      default: null,
      parseHTML: el => {
        const color = el.style.color.toLowerCase(), rgb = color.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
        const hex = rgb ? '#' + rgb.slice(1).map(n => Number(n).toString(16).padStart(2, '0')).join('') : color;
        return INKS.find(ink => ink.hex === hex)?.hex || null;
      },
      renderHTML: attrs => attrs.color && INKS.some(ink => ink.hex === attrs.color) ? { style: 'color: ' + attrs.color } : {},
    } } }];
  },
});

const Spoiler = Mark.create({
  name:'spoiler',
  parseHTML:()=>[{tag:'span[data-spoiler]'}],
  renderHTML:()=>['span',{'data-spoiler':'true',class:'spoiler-edit'},0],
});

export function proseEditorExtensions(onLimit: () => void = () => {}, maxLength = 250000) {
  return [StarterKit.configure({
    heading: { levels: [1, 2, 3] }, code: false, codeBlock: false, blockquote: false, orderedList: false,
    link: { openOnClick: false, autolink: false, linkOnPaste: false, isAllowedUri: url => !!safeLink(url) },
  }), TextStyle, PaletteColor, Spoiler, AnnotationReference, UploadedImage,
  Extension.create({
    name: 'proseAlignment',
    addGlobalAttributes: () => [{ types: ['paragraph','heading'], attributes: { textAlign: {
      default: null,
      parseHTML: element => ['left','center','right'].includes(element.style.textAlign)?element.style.textAlign:null,
      renderHTML: attrs => ['left','center','right'].includes(attrs.textAlign)?{style:'text-align: '+attrs.textAlign}:{},
    } } }],
  }),
  Extension.create({
    name: 'annotationHistory',
    // Keep note definitions and references in the same undo event; this attribute is never exported.
    addGlobalAttributes: () => [{ types: ['doc'], attributes: { annotations: { default: [], rendered: false } } }],
  }),
  Extension.create({
    name: 'proseStorageGuard', priority: 1000,
    // The existing story format uses a single-level list. Keep keyboard editing consistent with it.
    addKeyboardShortcuts() { return { Tab: () => this.editor.isActive('bulletList'), 'Mod-]': () => true, 'Mod-[': () => true }; },
    addProseMirrorPlugins: () => [new Plugin({ filterTransaction: tr => {
      if (!tr.docChanged || storedProse(tr.doc.toJSON()).length <= maxLength) return true;
      onLimit(); return false;
    } })],
  })];
}
