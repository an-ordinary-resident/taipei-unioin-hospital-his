import type { JSONContent } from '@tiptap/core';
import { INKS, inlineNodes, proseBlocks, safeLink, type InlineNode } from './prose-format';

type Mark = NonNullable<JSONContent['marks']>[number];
export const MEDIA_URL = /^\/api\/media\/[a-f0-9-]{36}$/;

function toInline(nodes: InlineNode[], marks: Mark[] = []): JSONContent[] {
  return nodes.flatMap((node): JSONContent[] => {
    if (node.kind === 'text') return node.text ? [{ type: 'text', text: node.text, ...(marks.length ? { marks } : {}) }] : [];
    if (node.kind === 'note') return [{ type: 'annotation', attrs: { id: node.id }, ...(marks.length ? { marks } : {}) }];
    const mark: Mark = node.kind === 'color' ? { type: 'textStyle', attrs: { color: INKS.find(ink => ink.id === node.color)?.hex } }
      : node.kind === 'link' ? { type: 'link', attrs: { href: node.href } } : { type: node.kind };
    return toInline(node.children, [...marks.filter(m => m.type !== mark.type), mark]);
  });
}

/** Stored prose stays text-based so existing drafts, imports, and published records remain compatible. */
export function editorDocument(body: string): JSONContent {
  const content = proseBlocks(body, true).map((block): JSONContent => {
    const attrs=block.alignment?{textAlign:block.alignment}:{};
    if (block.kind === 'divider') return { type: 'horizontalRule' };
    if (block.kind === 'image') return { type: 'image', attrs: { src: block.lines[0], alt: '作者上傳的作品插圖' } };
    if (block.kind === 'list') return { type: 'bulletList', content: block.lines.map(line => ({ type: 'listItem', content: [{ type: 'paragraph', attrs, content: toInline(inlineNodes(line)) }] })) };
    return { type: block.kind === 'heading' ? 'heading' : 'paragraph', attrs:{...attrs,...(block.level?{level:block.level}:{})}, content: toInline(inlineNodes(block.lines[0])) };
  });
  return { type: 'doc', content: content.length ? content : [{ type: 'paragraph' }] };
}

function escapeText(text: string): string { return text.replace(/[\\*[\]~•]/g, '\\$&'); }
function inlineText(node: JSONContent): string {
  if (node.type === 'hardBreak') return '\n';
  let value = node.type === 'annotation' ? '[' + node.attrs?.id + ']' : escapeText(node.text || '');
  // A stable wrapping order makes overlapping marks round-trip independently of schema order.
  const marks = [...(node.marks || [])].sort((a,b) => ['spoiler','link','textStyle','bold','italic','strike','underline'].indexOf(a.type) - ['spoiler','link','textStyle','bold','italic','strike','underline'].indexOf(b.type));
  for (const mark of marks.reverse()) {
    if (mark.type === 'spoiler') value = '[spoiler]' + value + '[/spoiler]';
    if (mark.type === 'bold') value = '**' + value + '**';
    if (mark.type === 'italic') value = '[i]' + value + '[/i]';
    if (mark.type === 'strike') value = '[s]' + value + '[/s]';
    if (mark.type === 'underline') value = '[u]' + value + '[/u]';
    if (mark.type === 'textStyle') {
      const ink = INKS.find(ink => ink.hex === String(mark.attrs?.color).toLowerCase());
      if (ink) value = '[color=' + ink.id + ']' + value + '[/color]';
    }
    if (mark.type === 'link') { const href = safeLink(mark.attrs?.href || ''); if (href) value = '[link=' + encodeURIComponent(href) + ']' + value + '[/link]'; }
  }
  return value;
}

export function storedProse(doc: JSONContent): string {
  function blocks(node: JSONContent, bullet=false): string {
    if (node.type === 'horizontalRule') return '---';
    if (node.type === 'image') return MEDIA_URL.test(node.attrs?.src || '') ? '[image:' + node.attrs!.src + ']' : '';
    if (node.type === 'paragraph' || node.type === 'heading') {
      const value = (node.content || []).map(inlineText).join('');
      const line=bullet?'- '+value:node.type==='heading'?'#'.repeat(Math.min(3,Math.max(1,node.attrs?.level||1)))+' '+value:value.replace(/^(\s*)(?=#{1,3}\s|[-𖣠]\s|---+$)/u,'$1\\');
      const alignment=node.attrs?.textAlign;
      return ['left','center','right'].includes(alignment)?'[align='+alignment+']'+line+'[/align]':line;
    }
    if (node.type === 'bulletList') return (node.content || []).map(item => (item.content || []).map(child=>blocks(child,true)).join('\n')).join('\n');
    return (node.content || []).map(child=>blocks(child)).join('\n');
  }
  return blocks(doc);
}
