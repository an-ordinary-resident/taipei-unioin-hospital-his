import type { Annotation } from './rich-text';
import { referenceIds } from './rich-text';
import type { NovelDoc } from './content';
export function dashboardRecords(all:NovelDoc[]):NovelDoc[]{return all.map(d=>({...d,body:d.kind==='chapter'?'':d.body,details:undefined,background:undefined,profileSections:undefined,notes:d.kind==='character'?(d.notes||[]).filter(n=>referenceIds(d.body).includes(n.id)):undefined,summary:d.kind==='chapter'?d.summary:undefined,cast:undefined}))}
export const CARD_IDS=['latest','recommendation','news'] as const;
export type CardId=typeof CARD_IDS[number];
export type Quote={id:string;text:string;byline:string};
export type NewsItem={id:string;title:string;body:string;byline:string;date:string};
export type DashboardConfig={welcome:string;dutyCharacterId:string;dutyPortraits?:Record<string,string>;dutyMessage:string;sanity:number;featuredCharacterId:string;layout:'standard'|'reverse'|'single';cards:CardId[];hiddenCards:CardId[];newsStyle:'news'|'chat';news:NewsItem[];quotes:Quote[]};
export type AboutConfig={title:string;subtitle:string;body:string;notes:Annotation[]};
export const DEFAULT_DASHBOARD:DashboardConfig={welcome:'歡迎報到。今天的目標：平安交班。',dutyCharacterId:'person-1',dutyPortraits:{},dutyMessage:'只想準時下班、睡滿六小時。',sanity:5,featuredCharacterId:'',layout:'standard',cards:[...CARD_IDS],hiddenCards:[],newsStyle:'news',news:[],quotes:[{id:'survival-1',text:'神明通常是不會 On call 的。',byline:'慈愛院區生存法則'}]};
export const DEFAULT_ABOUT:AboutConfig={title:'系統聲明',subtitle:'這是一個關於醫療人員的故事。',notes:[],body:'**關於本作品**\n\n《內科住院醫師：崩壞實戰指引》為「一個平凡的住院醫師」的原創醫療小說。本作品純屬虛構，故事中的人名、背景、醫院名稱與劇情均為虛構。\n\n雖然故事帶有誇飾與搞笑化，也希望藉由主角們的故事，讓讀者體驗訓練中醫療人員的視角與日常。故事情節與附錄並非個人醫療建議或院內作業規範。\n\n**閱讀與作者權限**\n\n首頁帳號為情境模擬，訪客不需要輸入真實姓名或密碼。讀者只能閱覽已刊載作品。作者工作台使用獨立的真實帳號驗證，只有指定作者帳號可以儲存、編輯、上傳與刊載。\n\n**原創作品使用說明**\n\n© 一個平凡的住院醫師。未經作者同意，請勿複製、重製或轉載作品。閱讀區已限制文字選取、右鍵與一般複製操作；這些措施無法完全防止截圖或技術擷取。\n\n**插圖說明**\n\n依原作說明，作品視覺插圖使用 Gemini Nano Banana 2 生成並以 ibisPaint 繪畫修正。角色圖與章節插圖可由作者上傳。'};
export const AUTHOR_SECTIONS=[{id:'dashboard',label:'值班主控台'},{id:'stories',label:'病程紀錄'},{id:'characters',label:'人員檔案'},{id:'glossary',label:'註釋辭典庫'},{id:'about',label:'系統聲明'},{id:'tour',label:'新進人員教學'}] as const;
export function latestRecords<T extends {id:string;kind:string;order:number;volume:string;chapterType?:string}>(all:T[]){const volume=all.filter(d=>d.kind==='volume').sort((a,b)=>b.order-a.order||b.id.localeCompare(a.id))[0];const chapters=all.filter(d=>d.kind==='chapter'&&d.volume===volume?.id&&d.chapterType!=='appendix'&&!['afterword','music'].includes(d.id)).sort((a,b)=>b.order-a.order||b.id.localeCompare(a.id));return {volume,chapter:chapters[0]};}
export function dutyPortrait(config:DashboardConfig,person?:Pick<NovelDoc,'id'|'image'>){return person?(config.dutyPortraits?.[person.id]||person.image||''):'';}
