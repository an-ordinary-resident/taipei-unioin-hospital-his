declare namespace Cloudflare { interface Env { DB:D1Database; FILES:R2Bucket; AUTHOR_EMAIL?:string; } }
